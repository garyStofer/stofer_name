// WdfpioDevice.h
//
// Requires Compuware's DriverWorks classes DriverStudio 2.6.0 (Build 336)
// Author: Gary Stofer , April 2003 , 
//

#ifndef __WdfpioDevice_h__
#define __WdfpioDevice_h__

typedef  union tagCtrlStat
{
	unsigned char byte_dat;
	struct tag_Control_Reg 		// on write 
	{
			unsigned Mode_S_P 	:1;
			unsigned VPP_on		:1;
			unsigned Jtag_5V 	:1;
			unsigned Max242_On	:1;
			unsigned Smode		:1;
			unsigned DFP_ena   	:1;
			unsigned TRxA_ena	:1;
			unsigned TRxB_ena	:1;
	}Ctrl_bits;		

	struct tag_Status_Reg		// on read
	{
		unsigned Ardy_HS_flag	:1;
		unsigned Brdy_HS_flag	:1;
		unsigned TMR0_stat		:1;
		unsigned TMR1_stat		:1;
		unsigned TMR2_stat		:1;
		unsigned PS_err			:1;
		unsigned Unused			:2;
	} Stat_bits;
} CTRL_STAT;




class WdfpioDevice : public KPnpDevice
{
	// Constructors
public:
	SAFE_DESTRUCTORS;
	WdfpioDevice(PDEVICE_OBJECT Pdo, ULONG Unit, Wdfpio * parent);
	~WdfpioDevice();

	// Member Functions
public:
//	DEVMEMBER_DISPATCHERS						// using only a subset of the disparchers in here
	virtual NTSTATUS OnStartDevice(KIrp I);
	virtual NTSTATUS OnStopDevice(KIrp I);
	virtual NTSTATUS OnRemoveDevice(KIrp I);
	VOID Invalidate(void);
	virtual NTSTATUS DefaultPnp(KIrp I);
	virtual NTSTATUS DefaultPower(KIrp I);
	virtual NTSTATUS OnDevicePowerUp(KIrp I);
	virtual NTSTATUS OnDeviceSleep(KIrp I);
	virtual NTSTATUS SystemControl(KIrp I);			
	
	NTSTATUS MapHwToProcess ( void );
	PVOID GetProcAddr( void );
	VOID UnMapHwToProcess( void );
	VOID SetReadWait( unsigned short  waitStates) ;
	VOID SetControl( int mode , bool Set_clr ) ;

	// Member Data
	USHORT				m_MySlot; 
	USHORT				m_MyDevNo;
	ULONG				m_MyBusNo;


private:
	VOID   WriteRtrDword( unsigned int  EpromConReg, ULONG regval);
	ULONG  ReadRtrDword( unsigned int EpromConReg );
	USHORT EepromReadWord( unsigned int EpromConReg, unsigned int EpromAddr);
	bool   EepromWriteWord(unsigned int EpromConReg, unsigned int EpromAddr, USHORT val);
	bool   EepromClock( unsigned int EpromConReg); 
	bool   EepromSendCmd( unsigned int cmd, unsigned int EpromConReg) ;



protected:
		// Unit number for this device (0-9)
	ULONG				m_Unit;

	CTRL_STAT 			m_CtrlStat; 
	KPnpLowerDevice		m_Lower;

	Wdfpio 	*			m_ParentDriver;	// The Driver opbject that initiated this 
	KMemoryRange		m_MemoryRange0;
	KIoRange			m_IoPortRange1;
	KMemoryToProcessMap* m_ProcMap;			// Warning !! only onne process can have the HW 

};

#endif
