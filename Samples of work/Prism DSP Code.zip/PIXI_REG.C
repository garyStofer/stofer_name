/* File: pixi_reg.c - hardware level register I/O functions used for Debug and Diags 
	$Revision: 1.1 $ 
    Gary Stofer
*/
#ifdef _DEBUG 
#include "prismapi.h"	/* for Communications Buffer definition */ 
#include "pixi_reg.h"	/* for PX_REG_BASE definition */ 

static unsigned *rtddp;	/* register trace data destination ptr */
static unsigned size;	/* register trace data buffer size */

void	/* init register trace data destination ptr & size */
PXinitRegTrace (unsigned *buf, unsigned bufsize)
{
    rtddp = buf;
    size = bufsize;
}

unsigned	/* return the data input */
PXregIn (unsigned offset)
{
    unsigned rv = ((*(PX_REG_BASE+(offset)))&0xffff);

    if (size--)
        *rtddp++ = offset << 16 | rv;
    return rv;
}

unsigned	/* return the data output */
PXregOut (unsigned offset, unsigned data)
{
    if (size--)
        *rtddp++ = offset << 16 | data & 0xffff;

    (*(PX_REG_BASE+(offset)) = data);
}

unsigned	/* return the data output */
PXunsTrace (unsigned data)
{
    if (size--)
        *rtddp++ = data;
}


unsigned	/* return the data output */
PXfltTrace (float data)
{
    if (size--)
        *rtddp++ = *(unsigned *)&data;
}

#endif /* _DEBUG */

