// Copyright (c) 1994, Compuware Corporation All Rights Reserved
//
// vport.h - include file for VPort class
//

#include <vmachine.h>

#ifndef __vport_h_
#define __vport_h_

#define IOPORTTHUNKSIZE 0x14
#define N_IO_PORTS 32

class VPort		 
{
public:
	VPort();
	~VPort();
	BOOL hook( DWORD port);
	BOOL unhookall();
 //	VOID localEnable(VMHANDLE);
 //	VOID localDisable(VMHANDLE);
 //	VOID globalEnable();
 //	VOID globalDisable();
	virtual DWORD handler(VMHANDLE, DWORD port,	CLIENT_STRUCT* pRegs, DWORD iotype, DWORD outdata);
protected:
	DWORD m_port[N_IO_PORTS];
	PVOID m_pFunc;
	BYTE  m_thunk[IOPORTTHUNKSIZE];
};

#endif
