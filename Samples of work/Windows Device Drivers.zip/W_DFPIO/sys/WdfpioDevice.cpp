// WdfpioDevice.cpp
// Implementation of WdfpioDevice device class
//
// Requires Compuware's DriverWorks classes DriverStudio 2.6.0 (Build 336)
// Author: Gary Stofer , April 2003 , 
//

#pragma warning(disable:4065) // Allow switch statement with no cases
		  
#include <vdw.h>
#include "../../../include/Wdfpioioctl.h"
#include "LogicDFPIODevice.h"
#include "Wdfpio.h"
#include "WdfpioDevice.h"

#define PLX_9050_STAT_REG 0x4c
#define PLX_9050_CTRL_REG 0x50
#define PLX_9050_LAS0BRD 0x28
#define PLX_9050SW_RESET_BIT 0x40000000	
#define PLX_9050_INT1_ENA  0x43 

#define EE_ADDR_MASK 0x003f // for combining addresses with instructions  (WORD addresses)
#define EE_CMD_LEN 9		// bits in instructions 
#define EE_READ 0x0180		// 01 1000 0000 read instruction 
#define EE_WRITE 0x0140		// 01 0100 0000 write instruction 
#define EE_WREN 0x0130		// 01 0011 0000 write enable instruction 
#define EE_WDS 0x0100		// 01 0000 0000 write disable instruction 
#define EE_PREN 0x0130		// 01 0011 0000 protect enable instruction 
#define EE_PRCLEAR 0x0177	// 01 1111 1111 clear protect register instr

#define DFPIO_CTRL_STAT_REG		0
#define DFPIO_RESET_STAT_REG	1
#define DFPIO_DAC_LOW_REG		2
#define DFPIO_DAC_HIGH_REG		3
#define DFPIO_AB_AUX_CTRL		8


#pragma hdrstop("Wdfpio.pch")

extern	KDebugOnlyTrace	t;
////////////////////////////////////////////////////////////////////////
//  WdfpioDevice::WdfpioDevice
//
//	Routine Description:
//		This is the constructor for the Functional Device Object, or FDO.
//		It is derived from KPnpDevice, which builds in automatic
//	    dispatching of subfunctions of IRP_MJ_POWER and IRP_MJ_PNP to
//		virtual member functions.
//
//	Parameters:
//		Pdo - Physical Device Object - this is a pointer to a system
//			device object that represents the physical device.
//
//		Unit - Unit number. This is a number to append to the device's
//			base device name to form the Logical Device Object's name
//
//	Return Value:
//		None   
//
//	Comments:
//		The object being constructed contains a data member (m_Lower) of type
//		KPnpLowerDevice. By initializing it, the driver binds the FDO to the
//		PDO and creates an interface to the upper edge of the system class driver.
//

WdfpioDevice::WdfpioDevice(PDEVICE_OBJECT Pdo, ULONG Unit, Wdfpio *parent) : KPnpDevice(Pdo, NULL)
{
	ULONG   propertyAddress, length, BusNumber;

	t << "Entering WdfpioDevice::WdfpioDevice (constructor)\n";

	// Check constructor status
    if ( ! NT_SUCCESS(m_ConstructorStatus) )
	    return;

    m_ParentDriver = parent; 	
	m_Unit = Unit;	   		// Remember our unit number
	m_Lower.Initialize(this, Pdo);	// Initialize the lower device

	SetLowerDevice(&m_Lower);// Inform the base class of the lower edge device object

	SetPnpPolicy();		// Initialize the PnP Policy settings to the "standard" policy

	SetPowerPolicy();	// Initialize the Power Policy settings to the "standard" policy

	// Get the physical bus info -- required to map instances to slots
    IoGetDeviceProperty(Pdo,DevicePropertyBusNumber,sizeof(ULONG),(PVOID)&BusNumber, &length);
	m_MyBusNo = BusNumber;

    IoGetDeviceProperty(Pdo,DevicePropertyAddress,sizeof(ULONG),(PVOID)&propertyAddress,&length);
    // 
    // For PCI, the DevicePropertyAddress has device number 
    // in the high word and the function number in the low word. 
    // 
    m_MyDevNo = (USHORT)(((propertyAddress) >> 16) & 0x0000FFFF);

	t << "My Bus number is " << ((unsigned short)  m_MyBusNo) << EOL;
	t << "My DevNumber is "  << ((unsigned short)  m_MyDevNo)  << EOL;
	
	m_MySlot = 0xff;		// init to illegal value
	m_ProcMap = NULL;
	m_CtrlStat.byte_dat = 0;		

}


////////////////////////////////////////////////////////////////////////
//  WdfpioDevice::~WdfpioDevice
//
//	Routine Description:
//		This is the destructor for the Functional Device Object, or FDO.
//
//	Parameters:
//		None
//
//	Return Value:
//		None
//
//	Comments:
//		None
//

WdfpioDevice::~WdfpioDevice()
{
	t << "Entering WdfpioDevice::~WdfpioDevice() (destructor)\n";

  	if (m_MySlot < DEV_CNT )
  		m_ParentDriver->m_DevMap[m_MySlot].pDevice = NULL;
	
	m_ParentDriver->m_Units--;			// decrement the count of serviced units in the driver 
  
	if (m_ParentDriver->m_Units == 0 )	// when there are no more serviced units the logical driver needs to go
	{
		t << "Deleting logical device \n";
		if ( m_ParentDriver->m_pLogicDevice != NULL)
		{
			delete (m_ParentDriver->m_pLogicDevice);
			m_ParentDriver->m_pLogicDevice = NULL;
		}
	}  

}

////////////////////////////////////////////////////////////////////////
//  PNPMinorFunctionName
//
//	Routine Description:
//		Return a string describing the Plug and Play minor function	
//
//	Parameters:
//		mn - Minor function code
//
//	Return Value:
//		char * - Ascii name of minor function
//
//	Comments:
//		This function is used for tracing the IRPs.  Remove the function,
//		or conditionalize it for debug-only builds, if you want to save
//		space in the driver image.
//
	
char *PNPMinorFunctionName(ULONG mn)
{
	static char* minors[] = {
		"IRP_MN_START_DEVICE",
		"IRP_MN_QUERY_REMOVE_DEVICE",
		"IRP_MN_REMOVE_DEVICE",
		"IRP_MN_CANCEL_REMOVE_DEVICE",
		"IRP_MN_STOP_DEVICE",
		"IRP_MN_QUERY_STOP_DEVICE",
		"IRP_MN_CANCEL_STOP_DEVICE",
		"IRP_MN_QUERY_DEVICE_RELATIONS",
		"IRP_MN_QUERY_INTERFACE",
		"IRP_MN_QUERY_CAPABILITIES",
		"IRP_MN_QUERY_RESOURCES",
		"IRP_MN_QUERY_RESOURCE_REQUIREMENTS",
		"IRP_MN_QUERY_DEVICE_TEXT",
		"IRP_MN_FILTER_RESOURCE_REQUIREMENTS",
		"<unknown minor function>",
		"IRP_MN_READ_CONFIG",
		"IRP_MN_WRITE_CONFIG",
		"IRP_MN_EJECT",
		"IRP_MN_SET_LOCK",
		"IRP_MN_QUERY_ID",
		"IRP_MN_QUERY_PNP_DEVICE_STATE",
		"IRP_MN_QUERY_BUS_INFORMATION",
		"IRP_MN_DEVICE_USAGE_NOTIFICATION",
		"IRP_MN_SURPRISE_REMOVAL"
	};

	if (mn > IRP_MN_SURPRISE_REMOVAL) 
		return "<unknown minor function>";
	else
		return minors[mn];
}

////////////////////////////////////////////////////////////////////////
//  WdfpioDevice::DefaultPnp
//
//	Routine Description:
//		Default handler for IRP_MJ_PNP
//
//	Parameters:
//		I - Current IRP
//
//	Return Value:
//		NTSTATUS - Result returned from lower device
//
//	Comments:
//		This routine just passes the IRP through to the lower device. It is 
//		the default handler for IRP_MJ_PNP. IRPs that correspond to
//		any virtual members of KpnpDevice that handle minor functions of
//		IRP_MJ_PNP and that are not overridden get passed to this routine.
//

NTSTATUS WdfpioDevice::DefaultPnp(KIrp I) 
{
	t << "Entering WdfpioDevice::DefaultPnp with IRP minor function="
	  << PNPMinorFunctionName(I.MinorFunction()) << EOL;

	I.ForceReuseOfCurrentStackLocationInCalldown();
	return m_Lower.PnpCall(this, I);
}


////////////////////////////////////////////////////////////////////////
//  WdfpioDevice::DefaultPower
//
//	Routine Description:
//		Default handler for IRP_MJ_POWER 
//
//	Parameters:
//		I - Current IRP
//
//	Return Value:
//		NTSTATUS - Result returned from lower device
//
//	Comments:
//		This routine just passes the IRP through to the lower device. It is 
//		the default handler for IRP_MJ_POWER.
//

NTSTATUS WdfpioDevice::DefaultPower(KIrp I) 
{
	t << "Entering WdfpioDevice::DefaultPower\n";

	I.IndicatePowerIrpProcessed();
	I.CopyParametersDown();
	return m_Lower.PnpPowerCall(this, I);
}

////////////////////////////////////////////////////////////////////////////////
//  WdfpioDevice::SystemControl
//
//	Routine Description:
//		Default handler for IRP_MJ_SYSTEM_CONTROL
//
//	Parameters:
//		I - Current IRP
//
//	Return Value:
//		NTSTATUS - Result returned from lower device
//
//	Comments:
//		This routine just passes the IRP through to the next device since this driver
//		is not a WMI provider.
//

NTSTATUS WdfpioDevice::SystemControl(KIrp I) 
{
	t << "Entering WdfpioDevice::SystemControl\n";

	I.ForceReuseOfCurrentStackLocationInCalldown();
	return m_Lower.PnpCall(this, I);
}

////////////////////////////////////////////////////////////////////////
//  WdfpioDevice::Invalidate
//
//	Routine Description:
//		Calls Invalidate methods for system resources
//
//	Parameters:
//		None
//
//	Return Value:
//		None
//
//	Comments:
//		This function is called from OnStopDevice, OnRemoveDevice and
//		OnStartDevice (in error conditions).  It calls the Invalidate
//		member funcitons for each resource to free the underlying system
//		resource if allocated.  It is safe to call Invalidate more than
//		once for a resource, or for an uninitialized resource.

VOID WdfpioDevice::Invalidate()
{
	// For each memory mapped region, release the underlying system resoruce.
	m_MemoryRange0.Invalidate();

	// For each I/O port mapped region, release the underlying system resource.
	m_IoPortRange1.Invalidate();
}

////////////////////////////////////////////////////////////////////////
//  WdfpioDevice::OnStartDevice
//
//	Routine Description:
//		Handler for IRP_MJ_PNP subfcn IRP_MN_START_DEVICE
//
//	Parameters:
//		I - Current IRP
//
//	Return Value:
//		NTSTATUS - Result code
//
//	Comments:
//		Initialize the physical device. Typically, the driver initializes
//		physical resources here.  Call I.AllocatedResources() for a list
//		of the raw resources that the system has assigned to the device,
//		or I.TranslatedResources() for the translated resource list.
//

NTSTATUS WdfpioDevice::OnStartDevice(KIrp I)
{
	ULONG bar;
	UCHAR hw_rev;
	ULONG las0brd;
	ULONG pci_ctrl;
	NTSTATUS status = STATUS_SUCCESS;
	
	t << "Entering WdfpioDevice::OnStartDevice\n";

	I.Information() = 0;

	// The default Pnp policy has already cleared the IRP with the lower device
	// Initialize the physical device object.

	// Get the list of raw resources from the IRP
	PCM_RESOURCE_LIST pResListRaw = I.AllocatedResources();
	// Get the list of translated resources from the IRP
	PCM_RESOURCE_LIST pResListTranslated = I.TranslatedResources();

	// Create an instance of KPciConfiguration so we can map Base Address
	// Register indicies to ordinals for memory or I/O port ranges.
	KPciConfiguration PciConfig(m_Lower.TopOfStack());
	if (PciConfig.IsValid() )
	{
		// The following is a workaround for the 9050's chips problems of decoding the local config reg. space
		// when aligned at 0x80. When Configmg provides such an addr. the chip doesn't decode for reads
		// To work around this we allocateed via BAR3 an IO space of 256 bytes which will be allocated on a page
		// boundry. Then we copy the contents of BAR3 to BAR1 and keep the page aligned address 
		// for use by other components of the driver.
		t << "Fixing 9050 BAR1 problem, IO_range needs to be 0xFF alinged\n";
		bar = PciConfig.ReadBaseAddress(3); 
		PciConfig.WriteBaseAddress(1, bar);
	}


	// For each memory mapped region, initialize the memory mapped range
	// using the resources provided by NT. Once initialized, each memory
	// range's base virtual address in system space can be obtained by calling
	// member Base(). Each memory range's physical address in CPU space can
	// obtained by calling CpuPhysicalAddress(). To access the memory mapped
	// range use member functions such as inb/outb, or the array element operator. 
	status = m_MemoryRange0.Initialize(	pResListTranslated,	
										pResListRaw,
										PciConfig.BaseAddressIndexToOrdinal(1) 
									  );
	if (!NT_SUCCESS(status))
	{
		Invalidate();
		return status;		
	}

    t << "MRange0 base address is " << (unsigned long) m_MemoryRange0.Base() <<"\n";
    t << "MRange0 Size  is " << (unsigned long) m_MemoryRange0.Count() <<"\n";
	
	// For each I/O port mapped region, initialize the I/O port range using
	// the resources provided by NT. Once initialized, use member functions such as
	// inb/outb, or the array element operator to access the ports range.

	// this is the page aligned IO address space  
	status = m_IoPortRange1.Initialize(	pResListTranslated,
										pResListRaw,
										PciConfig.BaseAddressIndexToOrdinal(2)
										);
	if (!NT_SUCCESS(status))
	{
		Invalidate();
		return status;		
	}

	t << "IOrange1 base address is " << (unsigned long) m_IoPortRange1.Base() <<"\n";
	t << "IOrange1 Size  is " << (unsigned long) m_IoPortRange1.Count() <<"\n";

	las0brd = m_IoPortRange1.inw( PLX_9050_LAS0BRD );
	t << "The LAs0_BRD Register is " << las0brd << EOL;

	pci_ctrl = m_IoPortRange1.ind( PLX_9050_CTRL_REG );
	// Multiple writes to give extra time
    m_IoPortRange1.outd( PLX_9050_CTRL_REG, pci_ctrl | PLX_9050SW_RESET_BIT);
	m_IoPortRange1.outd( PLX_9050_CTRL_REG, pci_ctrl | PLX_9050SW_RESET_BIT);
	m_IoPortRange1.outd( PLX_9050_CTRL_REG, pci_ctrl | PLX_9050SW_RESET_BIT);
   	m_IoPortRange1.outd( PLX_9050_CTRL_REG, pci_ctrl | PLX_9050SW_RESET_BIT);
   	m_IoPortRange1.outd( PLX_9050_CTRL_REG, pci_ctrl | PLX_9050SW_RESET_BIT);

	// release out of reset
	m_IoPortRange1.outd( PLX_9050_CTRL_REG, pci_ctrl );
 	m_IoPortRange1.outd( PLX_9050_CTRL_REG, pci_ctrl );
	m_IoPortRange1.outd( PLX_9050_CTRL_REG, pci_ctrl );


	hw_rev = m_MemoryRange0.inb(DFPIO_RESET_STAT_REG);
	t << "The HW rev of the 51166 card is (expect 0xa0 or 0xa1): " << hw_rev << EOL;

	
	// Fix up the interrupt enable setting in the EEprom to DISABLE so we don't 
	if (EepromReadWord( PLX_9050_CTRL_REG, 0x2f) != 0)
	{
		t << "Fixing the Interrupt Enable setting in EEPROM\n";
		EepromWriteWord( PLX_9050_CTRL_REG, 0x2f, 0x0);	 
	}
	// fix for complications with some MB/BIOS that will not page align memory blocks
	// Change EEprom so the card requests a 4Kb block instead of the 256bytes 
	// The change becomes effective after power has been disconnected from the adapter  
	if (EepromReadWord( PLX_9050_CTRL_REG, 8) != 0xffff)
	{
		t << "Fixing BAR0 in EEProm\n";
		EepromWriteWord(PLX_9050_CTRL_REG, 8, 0xFFFF);			// correct BAR0 to ask for 4K 	 
	}
	if (EepromReadWord( PLX_9050_CTRL_REG, 9) != 0xf000)
	{
		t << "Fixing BAR0 in EEProm\n";
		EepromWriteWord( PLX_9050_CTRL_REG, 9, 0xF000);	        // == 4K 
	}
/*
#if DBG
	// to print out the EEprom 
	for (int i = 0;i <=0x30 ;i+=2 )
	{
		unsigned short  dta,dta2;
	  	dta = EepromReadWord( PLX_9050_CTRL_REG, i);	
		dta2 = EepromReadWord( PLX_9050_CTRL_REG, i+1);
		t<< "EEPROM addr " << ((USHORT)(i*2)) << " = " << dta <<":" << dta2 <<EOL;
	
	}
#endif
*/
	return status;
}


////////////////////////////////////////////////////////////////////////
//  WdfpioDevice::OnStopDevice
//
//	Routine Description:
//		Handler for IRP_MJ_PNP subfcn IRP_MN_STOP_DEVICE
//
//	Parameters:
//		I - Current IRP
//
//	Return Value:
//		NTSTATUS - Result code
//
//	Comments:
//		The system calls this when the device is stopped.
//		The driver should release any hardware resources
//		in this routine.
//
//		The base class passes the irp to the lower device.
//

NTSTATUS WdfpioDevice::OnStopDevice(KIrp I)
{
	NTSTATUS status = STATUS_SUCCESS;
	ULONG pci_ctrl;

	t << "Entering WdfpioDevice::OnStopDevice\n";

	pci_ctrl = m_IoPortRange1.ind( PLX_9050_CTRL_REG );
    m_IoPortRange1.outd( PLX_9050_CTRL_REG, pci_ctrl | PLX_9050SW_RESET_BIT);
	m_IoPortRange1.outd( PLX_9050_CTRL_REG, pci_ctrl | PLX_9050SW_RESET_BIT);
	m_IoPortRange1.outd( PLX_9050_CTRL_REG, pci_ctrl | PLX_9050SW_RESET_BIT);
	m_IoPortRange1.outd( PLX_9050_CTRL_REG, pci_ctrl | PLX_9050SW_RESET_BIT);
	m_IoPortRange1.outd( PLX_9050_CTRL_REG, pci_ctrl | PLX_9050SW_RESET_BIT);

	m_IoPortRange1.outd( PLX_9050_CTRL_REG, pci_ctrl );
	m_IoPortRange1.outd( PLX_9050_CTRL_REG, pci_ctrl );

	// Device stopped, release the system resources.
	Invalidate();

	return status;
	
	// The following macro simply allows compilation at Warning Level 4
	// If you reference this parameter in the function simply remove the macro.
	UNREFERENCED_PARAMETER(I);
}

////////////////////////////////////////////////////////////////////////
//  WdfpioDevice::OnRemoveDevice
//
//	Routine Description:
//		Handler for IRP_MJ_PNP subfcn IRP_MN_REMOVE_DEVICE
//
//	Parameters:
//		I - Current IRP
//
//	Return Value:
//		NTSTATUS - Result code
//
//	Comments:
//		The system calls this when the device is removed.
//		Our PnP policy will take care of 
//			(1) giving the IRP to the lower device
//			(2) detaching the PDO
//			(3) deleting the device object
//

NTSTATUS WdfpioDevice::OnRemoveDevice(KIrp I)
{
	t << "Entering WdfpioDevice::OnRemoveDevice\n";

	// Device removed, release the system resources.
	Invalidate();

	return STATUS_SUCCESS;

	// The following macro simply allows compilation at Warning Level 4
	// If you reference this parameter in the function simply remove the macro.
	UNREFERENCED_PARAMETER(I);
}

////////////////////////////////////////////////////////////////////////
//  WdfpioDevice::OnDevicePowerUp
//
//	Routine Description:
//		Handler for IRP_MJ_POWER with minor function IRP_MN_SET_POWER
//		for a request to go to power on state from low power state
//
//	Parameters:
//		I - IRP containing POWER request
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//		This routine implements the OnDevicePowerUp function.
//		This function was called by the framework from the completion
//		routine of the IRP_MJ_POWER dispatch handler in KPnpDevice.
//		The bus driver has completed the IRP and this driver can now
//		access the hardware device.  
//		This routine runs at dispatch level.
//	

NTSTATUS WdfpioDevice::OnDevicePowerUp(KIrp I)
{
	NTSTATUS status = STATUS_SUCCESS;

	t << "Entering WdfpioDevice::OnDevicePowerUp\n";

	return status;

	UNREFERENCED_PARAMETER(I);
}

////////////////////////////////////////////////////////////////////////
//  WdfpioDevice::OnDeviceSleep
//
//	Routine Description:
//		Handler for IRP_MJ_POWER with minor function IRP_MN_SET_POWER
//		for a request to go to a low power state from a high power state
//
//	Parameters:
//		I - IRP containing POWER request
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//		This routine implements the OnDeviceSleep function.
//		This function was called by the framework from the IRP_MJ_POWER 
//		dispatch handler in KPnpDevice prior to forwarding to the PDO.
//		The hardware has yet to be powered down and this driver can now
//		access the hardware device.  
//		This routine runs at passive level.
//	

NTSTATUS WdfpioDevice::OnDeviceSleep(KIrp I)
{
	NTSTATUS status = STATUS_SUCCESS;

	t << "Entering WdfpioDevice::OnDeviceSleep\n";

	return status;

	UNREFERENCED_PARAMETER(I);
}

NTSTATUS WdfpioDevice::MapHwToProcess ( void )
{
	NTSTATUS status = STATUS_SUCCESS;
	KMemoryToProcessMap* pMap;
	VOID * user_address;

	if (m_ProcMap == NULL) 
	{
		pMap  = new (NonPagedPool) KMemoryToProcessMap(
					m_MemoryRange0.CpuPhysicalAddress().QuadPart,
					m_MemoryRange0.Count(), (HANDLE) -1 , FALSE, NULL, ViewShare);

 		if ( pMap )
		{   
			if ( NT_SUCCESS( pMap->ConstructorStatus() ) )
			{
				m_ProcMap = pMap;
				user_address  = pMap->ProcessAddress();
				t << "User memory map addr in ring 3 space is " << (ULONG) user_address << "\n";
				status = STATUS_SUCCESS;
			}
			else
			{
				t << "m_UserMemMap failed to construct\n";
				status = STATUS_INVALID_DISPOSITION;
			}
		}
		else
		{   
			t << "m_UserMemMap failed to Allocate in Nonpaged pool\n";
			status = STATUS_INVALID_DISPOSITION;
		}

	}
	return status;
}

VOID * WdfpioDevice::GetProcAddr( void )
{
	if (m_ProcMap != NULL )
		return m_ProcMap->ProcessAddress();
	else 
		return NULL;
}

VOID WdfpioDevice::UnMapHwToProcess( void )
{
	if (m_ProcMap != NULL )
	{
		t << "Unmapping the process map now \n";
		delete ( m_ProcMap );
		m_ProcMap = NULL;
	}
}

VOID WdfpioDevice::SetReadWait( unsigned short  waitStates) 
{
	unsigned long LaS0Brd ;

	t << "IOCTL SetReadWait called with " << waitStates  << " waitstates\n";

	// Wait state control for all reads
	LaS0Brd =  m_IoPortRange1.ind( PLX_9050_LAS0BRD );
	LaS0Brd &= 0xFFFFF83F;      // remove the current NRAD wait states
	waitStates  &= 0x1F;        // NRAD occupies bits 10:6 of the register
	LaS0Brd |= (waitStates << 6);
	m_IoPortRange1.outd( PLX_9050_LAS0BRD,LaS0Brd);
}


VOID WdfpioDevice::SetControl( int mode , bool Set_clr )
{	
	t << "IOCTL called for slot "  << m_MySlot << " ";

 	switch (mode )	
	{

		case MODE_DFP_RESET:
			t << "Mode_Dfp_Reset \n";
			// these things get set by the reset action in the HW  -- Multiple writes to generate slower pulses
			m_CtrlStat.byte_dat = 0;
			m_MemoryRange0.outw(DFPIO_AB_AUX_CTRL, 0xFF33);	// commanding the Direct relays open and AB as inputs
			m_MemoryRange0.outw(DFPIO_AB_AUX_CTRL, 0xFF33);	
			m_MemoryRange0.outw(DFPIO_AB_AUX_CTRL, 0xFF33);	

			m_MemoryRange0.outb(DFPIO_RESET_STAT_REG, SW_RESET_BIT);
			m_MemoryRange0.outb(DFPIO_RESET_STAT_REG, SW_RESET_BIT);
			m_MemoryRange0.outb(DFPIO_RESET_STAT_REG, SW_RESET_BIT);
			m_MemoryRange0.outb(DFPIO_RESET_STAT_REG, SW_RESET_BIT);
			m_MemoryRange0.outb(DFPIO_RESET_STAT_REG, 0);
			m_MemoryRange0.outb(DFPIO_RESET_STAT_REG, 0);
	
			m_MemoryRange0.outb(DFPIO_CTRL_STAT_REG, m_CtrlStat.byte_dat);
			break;

		case MODE_DFP_HSK_RESET:
			t << "MODE_DFP_HSK_RESET \n";
			if (Set_clr)
				m_MemoryRange0.outb(DFPIO_RESET_STAT_REG, PA_HSK_RESET_BIT);
			else 
				m_MemoryRange0.outb(DFPIO_RESET_STAT_REG, PB_HSK_RESET_BIT); 
				break;

	  	case MODE_DFP_VPP_ON:
			m_CtrlStat.Ctrl_bits.VPP_on =	Set_clr;
			t << "MODE_DFP_VPP_ON\n";
			break;
			
		case MODE_SER:
			m_CtrlStat.Ctrl_bits.Mode_S_P = 1;
			m_CtrlStat.Ctrl_bits.Smode = Set_clr;
			t << "MODE_SER \n";
			break;

		case MODE_PAR:
			m_CtrlStat.Ctrl_bits.Mode_S_P = 0;
			m_CtrlStat.Ctrl_bits.Smode = ! Set_clr;
			t << "MODE_PAR \n";
			break;
	  				 	
		case MODE_JTAG_V:
			m_CtrlStat.Ctrl_bits.Jtag_5V = Set_clr;
			t << "MODE_JTAG_V\n";
			break;

		case MODE_MAX242_ENA:
			m_CtrlStat.Ctrl_bits.Max242_On = Set_clr;
			t << "MODE_MAX242_ENA \n";
			break;

		case MODE_DFP_ENA:
			m_CtrlStat.Ctrl_bits.DFP_ena = Set_clr;
			t << "MODE_DFP_ENA\n";
			break;
			
		case MODE_TRxA_INV:
			m_CtrlStat.Ctrl_bits.TRxA_ena = Set_clr;
			t << "MODE_TRxA_INV\n";
			break;
			
		case MODE_TRxB_INV:
			m_CtrlStat.Ctrl_bits.TRxB_ena	= Set_clr;
			t << "MODE_TRxB_INV\n";
			break;		 	

	}
	m_MemoryRange0.outb(DFPIO_CTRL_STAT_REG, m_CtrlStat.byte_dat);
}


// eeprom services from here on down 
//----------------------------------
void WdfpioDevice::WriteRtrDword( unsigned int EpromConReg, ULONG regval)
{
   m_IoPortRange1.outd( (USHORT) EpromConReg, regval );
}


ULONG WdfpioDevice::ReadRtrDword( unsigned int EpromConReg )
{  
	return ( m_IoPortRange1.ind((USHORT)  EpromConReg) );
}	


USHORT WdfpioDevice::EepromReadWord( unsigned int EpromConReg, unsigned int EpromAddr) 	
{ // Return a word from National Semiconductor's NMC93S06/NMC93S46 EEPROM (Word addresses)
	USHORT acc = 0x0; 
	int i; 
	EepromSendCmd( EE_READ | (EpromAddr & EE_ADDR_MASK), EpromConReg); 
	for ( i = 0; i < 16; i++ )
	{ // Get word from EEPROM - one bit at a time 
		acc <<= 1; 
		EepromClock( EpromConReg); 
		if ( ReadRtrDword( EpromConReg) & 0x08000000 ) 
		   acc |= 0x0001; 
	} 
	return acc; 
}


bool WdfpioDevice::EepromWriteWord(unsigned int EpromConReg, unsigned int EpromAddr, unsigned short val)
{ // Write a word to National Semiconductor's NMC93S06/NMC93S46 EEPROM  (WORD addresses ) 

	unsigned int i; 
	unsigned long t_out;
	ULONG regval; 
	
	EepromSendCmd( EE_WREN, EpromConReg); // Write enable 
	EepromSendCmd( EE_WRITE | (EpromAddr & EE_ADDR_MASK), EpromConReg); 
	regval = ReadRtrDword( EpromConReg) & ~0x04000000; // Pre-clear data bit 
	for( i = 16; i ; i-- )
	{ // Write word to EEPROM - one bit at a time 
		WriteRtrDword(EpromConReg, regval|((val & 0x8000)? 0x04000000: 0x0)); 
		EepromClock( EpromConReg); 
		val <<= 1; 
	} 
	// Activate chip's status mechanism: deselect and reselect 
	WriteRtrDword(EpromConReg, regval & ~0x02000000); // Deselect 
	WriteRtrDword(EpromConReg, regval); // Reselect 
	// Poll chip status until write-cycle completes (or times out) 
	// (Timeout counter is uncalibrated and somewhat arbitrary!) 
	for( t_out = 0xfffe; !(ReadRtrDword(EpromConReg) & 0x08000000); t_out-- )
	{ 
		if ( t_out ) 
			continue; 
		// Timeout! 
		t << "EepromWriteWord(): Busy timeout EEPROM at address "<< (USHORT) EpromAddr << EOL;; 
		return FALSE; 
	} 
	EepromSendCmd(EE_WDS, EpromConReg); // Write disable 
	return TRUE; 
}



bool WdfpioDevice::EepromSendCmd( unsigned int cmd, unsigned int EpromConReg) 
{ // Send a command to National Semiconductor's NMC93S06/NMC93S46 EEPROM 
	unsigned int i; 
	ULONG regval; 

	regval = ReadRtrDword(EpromConReg); 
	regval |= 0x02000000; // Chip select TRUE 
	regval &= ~0x05000000; // Clear instruction and clock bits 
	// Toggle EEPROM's chip select (to get it out of Shift Register Mode) 
	WriteRtrDword( EpromConReg, regval & ~0x02000000); // Chip select FALSE 
	WriteRtrDword( EpromConReg, regval); 
	for ( i = 0; i < EE_CMD_LEN; i++ )
	{ // Send instruction - one bit at a time 
		regval &= ~0x04000000; // Pre-clear the instruction bit 
		// Set up one instruction bit 
		regval |= (cmd & (0x01 << (EE_CMD_LEN-1)))? 0x04000000: 0x00000000; 
		WriteRtrDword ( EpromConReg, regval); 
		EepromClock( EpromConReg); 
		cmd <<= 1; // Align next instruction bit 
	} 
	return TRUE; 
}
 

bool WdfpioDevice::EepromClock( unsigned int EpromConReg) 
{ // Send clocking sequence to Nat Sem's NMC93S06/NMC93S46 EEPROM 
	ULONG regval; 
	regval = ReadRtrDword( EpromConReg); 
	WriteRtrDword( EpromConReg, regval & ~0x01000000); // Clock low 
	WriteRtrDword( EpromConReg, regval | 0x01000000); // Clock high 
	return TRUE; 
}


