// Module to contain all Global Variables for the embedded Prism/Pixi DSP code
// Gary Stofer

#include "prismapi.h"
#include "setjmp.h"
#include "setup.h"
#include "execute.h"
#include "wavtable.h"
#include "pixi_glo.e"

//out of execute.h

/* assign local pointer variables that point to the on-chip isr variables
 * must be int if pointer, else compiler does float conversion on the pointer.
 * use: int *loc_var, then loc_var=&isr_var, then *loc_var=(int)&other_var
 * result is isr_var address contains other_var address outside of DP range
 */
struct IsrDacCtrl *Dac0Ctrl;
struct IsrDacCtrl *Dac1Ctrl;

float  s0_pk_factor[AHC_AC1250Hz+1] = { 1,}; 
float  s1_pk_factor[AHC_AC1250Hz+1] = { 1,}; 

/* Vmeas() interface - Vsample is both an Input & Output variable */
float *Vsample;  /* I: base of V result sample array, NULL = none */
/* O: if != NULL, ptr is updated to next location */

/* Vmeas() Inputs */
float *VsampleEnd;  /* ptr to end of communications buffer ram */

/* Vmeas() Outputs */
float maxV;      /* max V result for PEAK and PK-PK calc */
float minV;      /* min V result for PK-PK calc */


// out of wavtable.h

/* Stim DAC interrupt control */
unsigned int *intptr;  /* address of interrupt routine */


/*
 * global hardware setup configuration data
 */   

AHC_COMM_BUF 	  *CB = &comm_buf;  /* typed ptr to dual port comm buffer */
volatile HWREGS   *HW = &hw_regs;  /* typed ptr to the real HW registers */

SETUP        		SwSetup;  		/* setup buffer software */
HWREGS	            HwSetup;         /* setup buffer hardware */    
	
int   g_err;         /* global error num, replace use of 'errno' */
float g_DutI;        /* current applied to the DUT */
int   g_isBase;      /* True = transistor meas node on base */
int   g_isFast;      /* True = do fast mode resistor test */
float g_rampinc0;     /* stim 0 ramp increment for HV DC ramp, %/10us */
int   g_lastondur;    /* last on-time duration for stim duty cycle monitor */
int   g_lastoffdur;   /* last off-time duration for stim duty cycle monitor */
unsigned int   g_dma_dest;  /* destination address to initialize dma */
unsigned int   g_dma_ctr;  /* counter limit to initialize dma */
float g_dvdt;         /* least squares fit to slope */
float g_variance;     /* variance of data in least squares fit */



/* global system parameter data
 */
float g_sysLineFreq;    /* system AC Line Frequency */
float g_sysR;        /* system parasitic R */
float g_sysR3W;      /* system parasitic R used on R3W tests */
float g_sysCbp;      /* system backplane C */
float g_sysL;        /* system parasitic L */ 
long  g_PrismHwRev; /* board Rev. from board rev register */
int	  g_adc_offset;

float g_sin6[AHC_AC16Khz], g_cos6[AHC_AC16Khz]; /* 6 pt sin/cos table for 16.6Khz bridge mode */
float g_stim1_trim;  /* radians, phase trim of stim1 for bridge mode */
float g_stim0_trim; 
int g_adc_delay;  





