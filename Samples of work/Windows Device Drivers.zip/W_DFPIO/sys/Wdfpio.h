// Wdfpio.h
//

#ifndef __Wdfpio_h__
#define __Wdfpio_h__

#define EOL "\n"
#define DEV_CNT 8	// number of supported device instances for this driver


extern KDebugOnlyTrace t;	// Global driver trace object
class WdfpioDevice;			// forward declaration
	
typedef struct tagDevmap	{	
		ULONG			DeviceNo;	// the PCI device number of the enumerated slot
		WdfpioDevice *	pDevice;	// pointer the FDO andling this device
	} DEVmap;

class Wdfpio : public KDriver
{
	SAFE_DESTRUCTORS
public:
	virtual NTSTATUS DriverEntry(PUNICODE_STRING RegistryPath);
	virtual NTSTATUS AddDevice(PDEVICE_OBJECT Pdo);
	virtual void Unload(void);

	void	 LoadRegistryParameters(KRegistryKey &Params);

	int	m_Units;
	LogicDFPIODevice* 	m_pLogicDevice;	   // the Logical device providing the APP interface 

	// The following data members are loaded from the registry during DriverEntry
	ULONG   m_bBreakOnEntry;
	DEVmap	m_DevMap[DEV_CNT];
};

#endif			// __Wdfpio_h__
