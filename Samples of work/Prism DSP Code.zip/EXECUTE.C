/* File: EXECUTE.C, source module of DSP executable file PIXI.X30
 * $Revision: 1.1 $
 * Gary Stofer
 * Teradyne Sherlock project PIXI board DSP execute functions
 *
 */

#include <math.h>       /* for sqrt() and HUGE_VAL */
#include <string.h>     /* for NULL */
#include "prismapi.h"    /* for communications buffer definition */
#include "ahc_bnds.h"   /* for parameter bounds */
#include "pixi_reg.h"   /* for PIXI register definitions */
#include "setup.h"      /* for SETUP structure definition */
#include "tmr.h"        /* for timer definitions */
#include "util.h"       /* for MAX() */
#include "execute.h"    /* for execute defines and variables */
#include "wavtable.h"   /* for wave table definitions */

#include "pixi_glo.e"



/****************************************************
 * HiGuardVosMeas()  - DC stim 0v, DC meas of V offset Vos.
 */

static float
HiGuardVosMeas ( SETUP *su)
{
    int   mtype  = su->MeasType;
    float Rf  = OHM_Rf( HW->RfSelect.dat);
    int   wait   = su->wait;
    float vos;


    su->MeasType = AHC_DC;
    su->wait += (Rf < 100e3) ? 2000 : (Rf < 1e6) ? 5000 : 10000;

    STIM_ISR_NOP();         // turn current stimulus off, leave the dac clocks on
    PX_DAC0_OUT(0.0);       // Null out the Stimulus 
    PX_DAC1_OUT(0.0);       
    vos = Vmeas(su);        /* measure offset voltage */
    STIM_ISR_STIM();        // re-enable the stimulus again

    su->MeasType = mtype;   // restore old values
    su->wait = wait;

    return vos;
}



/*********************************************************************
 * Setup2 setup for second measurement, VDIFX0=Vdut or Vrx */
static int initial_wait =0;
 
static void
Setup2 ( SETUP  *su ,HWREGS *hw)
{
    int dly = 0;
    unsigned  long r;   
    
    initial_wait = su->wait;

    su->wait = TMR_FILTER;   /* just wait for measurement filter to settle */

    /* set VoltMeter scale if different, and delay for relay settling */
    if (hw->MeasRange1.dat  != hw->MeasRange2.dat )
    {
        HW->MeasRange1.dat= hw->MeasRange2.dat;
        dly = TMR_RELAYS;
    }

    // if one of the setups involves a mechanical relay switch
    r = hw->MeasSource1.dat ^ hw->MeasSource2.dat ;

    if ( ((r & 0Xf) >= 4) && ((r & 0xf) <= 9)  || r >= 0xe)
        dly = TMR_RELAYS;

    HW->MeasSource1.dat = hw->MeasSource2.dat;

    if (dly)
        TMR0start (dly);        /* restart global timer */

}


/*********************************************************************
 * Setup1 setup for first measurement again, VDIFF=Vmoa or Vdut
 returns AHC_OK or AHC_ERROR */
static int
Setup1 ( SETUP  *su , HWREGS *hw)
{
    int dly = 0;
    unsigned  long r;

    su->wait = initial_wait;
    if (hw->MeasRange1.dat  != hw->MeasRange2.dat )
    {
    /* reset VoltMeter scale */
        HW->MeasRange1.dat = hw->MeasRange1.dat; 
        dly = TMR_RELAYS;
    }

    // if one of the setups involves a mechanical relay switch
    r = hw->MeasSource1.dat ^ hw->MeasSource2.dat ;
    if (r > 15 || (r & 0XF) < 4 || (r & 0xf) > 9)
        dly = TMR_RELAYS;

    HW->MeasSource1.dat = hw->MeasSource1.dat;

    if (dly)
        TMR0start (dly);        /* restart global timer */
}


/****************************************************
 *>CheckSamplesSettled  check slope of one sample sequence using lsq fit
 * sampls data array assumed float volts scaled to DUT, i.e. *=ScaleAmp
 * this is a post-processing step, data acquisition is not running
 */
static int /* return 0 if settled */
CheckSamplesSettled(int nsamples, float scale, float *sampls, int *isnoisy)
{
    int i;
    float fn, measv, dvdt, mtime, err;
    float sumxf;                /* accum sum(time*volts) */
    float sumx2;                /* accum sum(time^2) */
    float sumx;                 /* accum sum(time) */
    float sumf;                 /* accum sum(volts) */
    float sumf2;                /* accum sum(volts^2) */
    float stime = PIXI_CLK_PER;
    float dvdt1=DVDT_1;   /* relative to DUT, typ 0.3mv/320us = 0.9v/s */

    fn = sumx = sumx2 = sumf = sumf2 = sumxf = mtime = 0.0;
    fn = (float)nsamples;

    for(i=0; i<nsamples; i++)
    {
        mtime += stime;
        sumx += mtime;
        sumx2 += mtime*mtime;
        measv = sampls[i];
        sumf += measv;
        sumf2 += measv*measv;
        sumxf += measv * mtime;
    }

    /* formula for slope of linear least squares fit to data series
     * scaled to volts/sec at DUT    
     */    
    dvdt = (fn*sumxf - sumf*sumx) / (fn*sumx2 - sumx*sumx);

    /* if the slope at the MOA is less than DVDT_1=3mV/320us=9.4V/s
     * then is settled    
     * derived from slope at 0.25% settling with 2V overshoot    
     * and 3mV resolution    
     */    
    dvdt = fabs(dvdt); /* leave relative to DUT volts */

    g_dvdt=dvdt;
    g_variance = (sumf2 - sumf*sumf) / fn; /* AC mean square voltage ??? is this correct */
    g_variance = fabs(g_variance);

    /* if the noise is larger than the slope, then signal is too noisy
     * compare voltage rise over measurement interval to noise    
     */    
    err = fabs(mtime*dvdt);
    err *= err;
    if(err != 0.0)
    {
        err = fabs(g_variance/err);
        *isnoisy = (err > 0.5); /* noise > 50% signal */
    }

    if(dvdt <= dvdt1)
        return 0; /* is settled */
    else
        return 1;  /* not settled */
}




/*********************************************************************
 * TISVmeas, TISV, R, L, and C measurement algorithms
 */
static void
YmodeMeas ( SETUP  *su, AHC_TEST_RESPONSE *rbuf, float *V_dut, float *I_dut)
{
    int nm;
    float Vos = 0.0 ;     
    double i_rslt = 0.0;           /* measured result, accumulated results */
    float real_V_dut;
    float i_dut;                // intermediate current result
    float V_Rf;
    float Rf = OHM_Rf( HW->RfSelect.dat);

    // Setup1 (su);        this needs  to be entered with setup1 
    nm = su->averaging;

    if (su->MeasType == AHC_RMS || su->MeasType == AHC_RMS_AC)
        real_V_dut = *V_dut = su->s0.v_out * 0.707106781;
    else if (su->MeasType == AHC_PKPK )
        real_V_dut = *V_dut = su->s0.v_out * 2.0;
    else
        real_V_dut = *V_dut = su->s0.v_out;

    do
    {

        if (su->MeasOpt.bit.HiGuard)
            Vos = HiGuardVosMeas (su);        /* measure offset voltage */

        V_Rf = Vmeas(su) - Vos;
            
        if(su->MeasOpt.bit.Precise )
        {
            Setup2 (su, &HwSetup); /* sec measurement, across DUT */
            real_V_dut = Vmeas(su); 
            Setup1 (su, &HwSetup);
            /* compensate I_dut for possible stim degregation */
            i_dut = V_Rf /Rf * fabs( *V_dut / real_V_dut );
        }
        else
            i_dut = V_Rf / Rf;  /* first measurement, across Rf */

        i_rslt += i_dut;

    } while (--nm);

    if(!CB->hdr.KeepStim )
        Dac1Ctrl->up = Dac0Ctrl->up = 0;

    if (su->MeasType == AHC_DC)     // correct the fact that vmoa is read inverse
        i_rslt = -i_rslt;

    *I_dut  = i_rslt / su->averaging;


    // copy voltage readings into communications buffer 
    rbuf->vmeas1 = C3XtoIEEE (V_Rf);
    rbuf->vmeas2 = C3XtoIEEE (real_V_dut);

}


/* TVSImeas
 */
static void
ZmodeMeas ( SETUP *su, AHC_TEST_RESPONSE *rbuf, float *Vdut, float *Idut)
{
    int nm ;                    /* number of measurments to average */
    float Vos = 0.0;            /* Offset voltage */
    float v_dut,v_Rx;           /* intermediate  results */
    double v_rslt = 0.0;        /* accumulated results */
    float rslt2 = 0.0;          /* accumulated results */
    float exp_I_dut , real_I_dut;

    nm = su->averaging;

// could be done at setup 
    if (su->MeasType == AHC_RMS || su->MeasType == AHC_RMS_AC)
        exp_I_dut = real_I_dut = su->s0.v_out / OHM_Rs(su->s0.RsNdx) * 0.707106781;
    else if (su->MeasType == AHC_PKPK )
        exp_I_dut = real_I_dut = su->s0.v_out / OHM_Rs(su->s0.RsNdx) * 2.0;
    else
        exp_I_dut = real_I_dut = su->s0.v_out/ OHM_Rs(su->s0.RsNdx);

    do
    {
        // ResetStimPhase(su); /* for AC stim signals, reset phase between averages */

        if (su->MeasOpt.bit.HiGuard)
            Vos = HiGuardVosMeas (su);        /* measure offset voltage */
            
        v_dut = (Vmeas(su) - Vos);  

        if(su->MeasOpt.bit.Precise) 
        {
            Setup2 (su, &HwSetup);

            v_Rx = Vmeas(su); /* second measurement  accorss Rx*/
            real_I_dut = v_Rx / OHM_Rs(su->s0.RsNdx);
            Setup1 (su, &HwSetup);        /* setup for 1st measurement again */

            // compensate V_dut for possible stim degregation
            v_dut = v_dut * ( exp_I_dut / real_I_dut);
        }  

        v_rslt += v_dut;

    } while (--nm);

    if(!CB->hdr.KeepStim )          // Need to switch in squelch so that Vmoa has a linear 
    {                              // Feed back path to discharge Vmoa
        Dac1Ctrl->up = Dac0Ctrl->up = 0;
        HW->SqArm = HW->Squelch = 1;
    } 
    
    *Vdut = v_rslt / su->averaging;
    *Idut = exp_I_dut;


    /* copy results into communications buffer in
     * ieee format for host computer    
     */    
    rbuf->vmeas1 = C3XtoIEEE (*Vdut);
    rbuf->vmeas2 = C3XtoIEEE (v_Rx);
}




#define UP 1
#define DOWN 0
/****************************************************
 * BRIDGEmeas      RC test type dual-stim balanced bridge algorithm
 */
static float
BridgeMeas ( SETUP *su, AHC_TEST_RESPONSE *rbuf )
{
    int ncycles, nm = su->averaging; /* number of measurements to average */
    float rslt = 0.0;    /* measured result, accumulated results */
    float imm, ireal, xc;
    float imm_low, imm_high, imm_mid;
    float sf,yf,v_pk, trim0; 
    float deg,rad0,rad1,rad_L_corr;
    float omega = PI2 * AHC_SF / su->s0.prd;
    float *wt;

    int hold =0;        // a debugging help
    int  j,i;
    float dc, rms;
    float av0;
    float S, C;
    float C_low, C_high;
    int  direction = DOWN;     // 1 == up;
    int dir_change = 0;


    ireal =  su->s1.v_out / su->par_R;

    xc    =  1 / (omega * (su->low_val + su->Cadj)); /* = 1/wC */
    imm_low   =  su->s1.v_out / xc;
    xc    =  1 / (omega * (su->high_val + su->Cadj)); /* = 1/wC */
    imm_high   =  su->s1.v_out / xc;
    // xc    =  1 / (omega * (su->mid_val + su->Cadj)); /* = 1/wC */
    // imm_mid   =  su->s1.v_out / xc;

    rad_L_corr = omega * su->Ladj /su->par_R ;   // the correction for sys-ind

    InitSineTable(&su->s1, Dac1Ctrl, g_stim1_trim);  // init in here for precise phase
    InitSineTable(&su->s0, Dac0Ctrl, g_stim0_trim);  // init in here for precise phase

    // correct for stim setup&hold error and invert phase (neg. sign)
    sf    =  PX_DAC_10V_BITS / STIM_AMP_LOW_GAIN * (-su->s0.pk_factor); 
    yf    =  PI2 / su->s0.prd;

    TMR0wait();     // wait for last relay to settle

    trim0 = g_stim0_trim + rad_L_corr;
    Dac0Ctrl->scale = 1.0;      // The wavetable is already scaled up by sf 
    Dac0Ctrl->offs = DACOFFSf;
    wt = Dac0Ctrl->table;

// not sure how many cycles I need to get a reliable Sine / Co-Sine rsult from BridgeVmeas
    su->samples = 100 * su->s0.prd;

    // check low threshold
    for(i=0; i < su->s1.len; i++)   // create Stim for low threshold
        wt[i] = (ireal * sin(i * yf - trim0) + imm_low * cos(i * yf - trim0))
                        * sf * OHM_Rs(su->s0.RsNdx);
    BridgeVmeas( 4, g_adc_delay,su, &av0, &dc, &rms,&S,&C_low );

    // check high threshold
    for(i=0; i < su->s1.len; i++)   // create stim for high threshold
        wt[i] = (ireal * sin(i * yf - trim0) + imm_high * cos(i * yf - trim0))
                        * sf * OHM_Rs(su->s0.RsNdx);
    BridgeVmeas( 4, g_adc_delay,su, &av0, &dc, &rms,&S,&C_high );


    // from the two points measured above determine the slope and find the imm where the 
    // bridge should be null. A guard situation will de-tune this prediction
    imm = imm_high  + ( C_high * (imm_high - imm_low) / (C_low - C_high));
    for ( j=0; j < 800 ; j++ )
    {
        // recalculate stim0 sine wave from real and imag components
        for(i=0; i < su->s1.len; i++)
            wt[i] = (ireal * sin(i * yf - trim0) + imm * cos(i * yf - trim0))
                            * sf * OHM_Rs(su->s0.RsNdx);

        BridgeVmeas( 4, g_adc_delay,su, &av0, &dc, &rms,&S,&C );

        if (!hold)   // a debugging aid
        {
            if (C > 0.0 )
            {
                imm *=1.001;
                if (direction == DOWN)
                {
                    direction = UP;
                    dir_change++;
                }
            }    
            else
            {
                imm *=0.999;
                if(direction == UP )
                {
                    direction = DOWN;
                    dir_change++;
                }
            }

            if (dir_change > 4 )
                break;
        }
    }

    // Bridge is at minimum, now measure phase of both stims
    // Measure phase of stim0 
    HW->RxSelect.dat = 1;
    HW->RySelect.dat = 0;
    HW->MeasSource1.src.Hi_In=H_FS; 
    TMR0delay (TMR_RELAYS);
    check_phase( su, g_adc_delay, &rad0, &deg, 100 );
    
    // Measure phase of stim1
    HW->RxSelect.dat = 0;
    HW->RySelect.dat = 1;
    HW->MeasSource1.src.Hi_In=H_ES; 
    TMR0delay (TMR_RELAYS);
    check_phase( su, g_adc_delay, &rad1, &deg, 100 );

    rad1 = rad0 - rad1 + rad_L_corr;    // The phase angle of the RC
    rslt = tan(rad1) / (omega * su->par_R);

    // set connection back for a possible repeat case
    HW->RxSelect.dat = HwSetup.RxSelect.dat;
    HW->RySelect.dat = HwSetup.RySelect.dat;
    HW->MeasSource1.src.Hi_In= HwSetup.MeasSource1.src.Hi_In;
    TMR0start (TMR_RELAYS);


    if(rslt < 0.0)
        rslt=0.0;

    // request stim off
    Dac1Ctrl->up = Dac0Ctrl->up = 0;

 if(g_err) /* bridge signal clipped or missing, everything is garbage */
 {
    rslt = 0.0;
    rbuf->pass_fail = AHC_FAIL_UNSTABLE;
 }

    return(rslt);
    
}


/****************************************************
 * BetaRange   change range for autorange Beta test
 *             given new beta threshold su->low_val
 */
static void
BetaRange ( SETUP *su )
{
    float sgn=1.0;

    if(g_isBase) /* measure node is base node */
    {
        if(su->s0.dac_v < 0.0)
            sgn = -1.0;

        su->s0.dac_v = sgn * IstimRx(g_DutI/su->low_val, 3.0, &su->s0.RsNdx);
        HW->RxSelect.dat = su->s0.RsNdx;
        su->wait = TMR_RELAYS;
    }
}




/****************************************************
 * BetaMeas   non-autoranging Beta test dual-stim algorithm
 */
static void
BetaMeas ( SETUP *su, AHC_TEST_RESPONSE *rbuf)
{
    int i;
    int nm = su->averaging;     /* number of measurements to average */
    float rslt = 0.0;           /* measured result, accumulated results */
    float icc, icc0, vramp, vfinal, vfinalabs, vinc, vinc0, xf;
    float v;

    int wt=su->wait;

    if(nm <= 0)
        nm=1;

    TMR0wait();                /* wait for setup reeds to settle */

    su->wait = 0; /* TMR_FILTER*2;   /* ramp to Icc with no wait, then do user wait */

    vfinal = su->s0.dac_v;
    vfinalabs = 9.9; /* allow for out of range, was: fabs(vfinal)+0.8; */

    HW->MoaCmplnc.limit = V_Lim_6v;

    /* averaging loop */
    do
    {
        if(vfinal < 0.0)
            vramp = vinc = vinc0 = -g_rampinc0;
        else
            vramp = vinc = vinc0 = g_rampinc0;

        /* icc ramping loop ,  g_DutI = desired dut Icc */
        for(i=0; i<4000; i++)
        {
            /* set stim to ramp voltage */
            su->s0.dac_v = vramp;
            icc = fabs(Vmeas(su)) / OHM_Rs(su->s1.RsNdx);
            vramp += vinc;

            if(icc>=g_DutI)
                break;

            if(fabs(vramp)>vfinalabs) /* ramp maxed out, check if icc close */
            {
                break;
            }

            if(i==0) /* breakpoint debug */
                i=0;
            else if(i==20)
                icc0=icc;
            else if(i==100)
                /* check if no transistor present, eg icc not changing */
            {
                xf = (icc-icc0)/g_DutI;
                if(xf < 0.02)  /* should have hit at least 5% of g_DutI after 100 */
                {
                    rslt=0.0;
                    goto BETA_EXIT;
                }
            }
            else if(i==400)
                i=400;

            
        }

        /* if have exited loop too soon since icc>g_DutI then out of range
     * if autorange on, increase beta thresh setup        
     */        
        if(i < 20)
        {
            //rbuf->OvrUndR = '<';    /* <logic assuming beta setup is too low */
            rbuf->pass_fail = AHC_FAIL_UNDER;
            rslt=0.0;
            goto BETA_EXIT;
        }

        /* if have hit the end of the loop or the end of the ramp
     * and icc is not within 5% if target, then out of range        
     * if autorange on, decrease beta thresh setup        
     */        
        if(fabs((g_DutI-icc)/g_DutI) > 0.05)
        {
            //rbuf->OvrUndR = '>';    /* >logic assuming Vdiff overranged */
            rbuf->pass_fail = AHC_FAIL_OVER;
            rslt=0.0;
            goto BETA_EXIT;
        }

        /* Icc is now set to desired value
       * apply user wait time (one time only) and then        
       * measure Vdiff for base current,        
       * unless base is already measure node, then know Ib already        
       */        
        if(wt) /* remeas Icc after user wait, if any */
        {
            TMR0delay(wt);
            icc = fabs(Vmeas(su)) / OHM_Rs(su->s1.RsNdx);
            wt=0;
        }

        if(g_isBase)
            rslt += icc / (fabs(su->s0.dac_v)/OHM_Rs(su->s0.RsNdx));
        else
        {
            HW->MeasSource1.dat = PX_HI_VDIFF | PX_LO_AGND;
            TMR0delay(TMR_FILTER); /* meas filter settling after mux change */
            v = fabs(Vmeas(su));
            rslt += icc / (v / OHM_Rf( HW->RfSelect.dat)); /* Beta = Icc/Ib = Icc/(Vdiff/Rf) */
            if(nm>1)
            {
                HW->MeasSource1.dat = PX_HI_VDIFX1 | PX_LO_AGND;
                TMR0delay(TMR_FILTER);
            }
        }

        if(nm>1) /* if averaging, do not allow continuous on */
        {
            PX_DAC0_OUT (0.0);
            TMR0delay(AHB_MIN_BETA_REP_TIME/10);
        }

    } while (--nm);

    if (su->averaging > 1)
        rslt /= su->averaging;

    BETA_EXIT:

    HW->MoaCmplnc.limit = V_Lim_0_7v;


}
/*********************************************************************
 * DCCapDischarge
 * discharge cap after DC charge meas
 */
void
CapDischarge ( SETUP *su)
{
    float volts;
    float scale_gain ;

    scale_gain = ADC_RNG( HW->MeasRange1.dat );

    PX_DAC0_OUT (0.0);             // make sure both stims are at 0
    PX_DAC1_OUT (0.0);            

    TMR0wait();                     // wait for last relay 

    HW->Squelch = SW_ON;           // make sure Squelch is on 

    if ( ! HW->SqArm )
    {
        HW->SqArm = SW_ON;
        TMR0start(TMR_RELAYS); 
    }
    TMR0wait();          
    TMR0start(su->CapDsc);      // setup sets this to 5tau (50Squelch r)

    /* discharge until < 20 mv typ or timeout
   * dont use Vmeas(su) since don't need extra TMRwait or averaging    
   */    
    HW->Listen = SW_ON;
    do
    {
        volts=fabs(scale_gain * ADC_READ());
    } while((volts > 20.0e-3) && !TINT0done);

    TMR0Stop();
    HW->Listen = SW_OFF;

    // signaling an error will cause a program abort in the 18xx -- not good
    // if(volts>AHB_CAP_DISCH_V)
    //    g_err = AER_DC_CAP_DISCHARGE;

}



/*********************************************************************
 * CHARGEmeas  Zmode - C DC Charge Rate measurement algorithm
 * do running estimate of least-squares linear estimation of voltage slope dv/dt
 * with constant current stim I
 * then C = I/(dv/dt)
 * slope estimation math runs in foreground while voltage measurement samples
 * accumulate in background, no need to keep up in real time
 * measurement stops when stability criterion is reached
 */
static float
CHARGEmeas ( SETUP *su, AHC_TEST_RESPONSE *rbuf )
{
    int nm = su->averaging;     /* number of measurments to average */
    float V, I;      /* measured voltage, current */
    float rslt = 0.0;           /* measured result, accumulated results */
    float  mv;

    if(nm <= 0)
        nm=1;

    
    do
    {
        mv = DVDTmeas(su); /* return linear least squares fit to DVDT */
        rslt += mv;
    } while (--nm && mv > 0.0);

    if (su->averaging > 1)
        rslt /= su->averaging;

    if(rslt > 0.0)
        // convert delta-v to Capacitance  C = I / dv/dt
        rslt =((su->s0.dac_v/(OHM_Rs(su->s0.RsNdx)+su->Radj)) / rslt) - su->Cadj;
    else
        rslt = 0.0;

    // discharge DUT to <20mv, fails if times out before 20mv

 if(g_err == AER_DC_CAP_TOO_SMALL)
 {
    g_err = 0; /* just report underrange, no ahc error message */

    rbuf->pass_fail = AHC_FAIL_UNDER;
    rslt = 0.0;
 }
    return(rslt);
    
}

 


/****************************************************
 * BETAmeas   autoranging Beta test dual-stim algorithm
 */
float 
ex_beta( SETUP *su, AHC_TEST_RESPONSE *rbuf)
{
    int i,rs;
    float rslt;           /* measured result, accumulated results */
    float thresh,pkv,RsOhms;

    thresh = su->low_val;
    g_rampinc0 = 0.00244; /* initial setting for base current step */
    rs=su->s0.RsNdx;
    pkv=su->s0.dac_v;
    RsOhms=OHM_Rs(su->s0.RsNdx);


    for(i=0; i<10; i++) /* allow max 10 iterations */
    {
        BetaMeas(su, rbuf);
        rslt = rbuf->result;

        /* not out of range, */
        if( rbuf->OvrUndR==' ')
            break;

        if( rbuf->OvrUndR == '<') /* increase beta thresh setup */
        {
            su->low_val *= 2.0;
            if(su->low_val > AHB_MAX_BETA_GAIN) /* cant go beyond this */
                break;

            if(!g_isBase)
                g_rampinc0 /= 2.0; /* smaller ramp, since dut has large beta */

        } else
        if( rbuf->OvrUndR == '>') /* decrease beta thresh setup */
        {
            su->low_val /= 2.0;
            if(su->low_val < AHB_MIN_BETA_GAIN)
                break;

            if(!g_isBase)
            {
                break;  /* should not ever happen, where emitter is meas node
                   * and desired Icc cannot be reached, since Rs is                
                   * in series with emitter                
                   * unless no dut installed? anyway, no autoranging possible                
                   */                
            }
        }

        BetaRange(su); /* change the resistor setup, based on new beta */
    }


    su->low_val = thresh; /* restore original measurement threshold */
    su->s0.RsNdx=rs;
    su->s0.dac_v=pkv;

    return(rslt);

}


/*********************************************************************
 * R3Wmeas
 * 3 wire R measurement algorithm - APC & Intc & Shorts only
 * no autoranging done
 */
float
ex_loR ( SETUP *su, AHC_TEST_RESPONSE *rbuf)
{
    float I;                            /* measured current */
    float rslt;                         /* measured result */
    float V = su->s0.v_out;         /* Stim0 voltage */
    float Rf = OHM_Rf( HW->RfSelect.dat);

    TMR0delay (TMR_RELAYS); /* interconnects always need relay wait */

    if(su->s0.prd) /* autosettle makes no sense for AC APC, keep for shorts */
    {
        su->wait = TMR_FILTER_FAST;
        ResetStimPhase(su); /* reset phase between calls from APC */
    }
    V *= (su->MeasType == AHC_DC)   ? 1.0 :
    (su->MeasType == AHC_PKPK) ? 2.0 :
    (su->MeasType == AHC_RMS)  ? SQRT2 : 
    (su->MeasType == AHC_RMS_AC)  ? SQRT2 : 1.0;
    I = Vmeas(su) / Rf;
    // !!! ??? why subtract system resistance for shorts measurments !!!! ????
    rslt = fabs(V/I) - su->Radj;
   
    return(rslt);
    
}

float
ex_ind ( SETUP *su, AHC_TEST_RESPONSE *rbuf)
{
    float Vdut, Idut;
    float rslt;

    YmodeMeas( su, rbuf, &Vdut, &Idut);

    /* convert Bulk Impedance measurement to Reactance */
    rslt = fabs( Vdut) / fabs(Idut);
    // remove series resistance parasitic  to get Xl
    rslt = (su->par_R < rslt) ? sqrt(rslt*rslt - su->par_R*su->par_R) : 0.0;

    /* convert Reactance to Inductance */
    rslt = rslt * su->s0.prd / (PI2 * AHC_SF);
    if ( (rslt = fabs(rslt) - su->Ladj) < 0.0 )
    {
        rslt = 0.0;
        rbuf->pass_fail = AHC_FAIL_UNDER;
    }
    return(rslt);
    
}

float
ex_cap ( SETUP *su, AHC_TEST_RESPONSE *rbuf)
{
    float Vdut, Idut;
    float rslt;

    if(su->MeasAlg == SU_YMODE)
    {
        // cap above 100uf to be run trough the discharge sequence
        if (su->CapDsc)
        {
            CapDischarge( su );
            HW->RfSelect.dat = su->RfNdx;
            TMR0start( TMR_RELAYS);
        }

        YmodeMeas( su, rbuf, &Vdut, &Idut);

        // get bulk impedance
        rslt  = fabs( Vdut ) / fabs( Idut);
        /* RC_MODE convert Bulk Impedance to Reactance */        
        if (su->par_R > 0.0)
        {
            rslt = (su->par_R < rslt) ? HUGE_VAL 
                    : 1 / sqrt(1/(rslt*rslt) - 1/(su->par_R * su->par_R));
        }

        /* subtract series 3wire mode resistor */
        if (su->Radj)
        {
            rslt = (rslt * rslt) - (su->Radj * su->Radj);
            if (rslt > 0.0 )
                rslt = sqrt( rslt);
            else
            {
                rbuf->pass_fail = AHC_FAIL_UNDER;
                rslt = 0.01;
            }

        }

        /* convert Reactance to Capacitance */
        rslt = su->s0.prd / (PI2 * AHC_SF * rslt);
    }
    else if(su->MeasAlg == SU_CHARGE)
    {
        CapDischarge( su );
        rslt = CHARGEmeas(su, rbuf);
    }
    else if(su->MeasAlg == SU_BRIDGE)
        rslt = BridgeMeas (su, rbuf);

    if ( (rslt = fabs(rslt) - su->Cadj) < 0.0)
    {
        rslt = 0.0;
        rbuf->pass_fail = AHC_FAIL_UNDER;
    }
    return(rslt);
    
}

float
ex_res ( SETUP *su, AHC_TEST_RESPONSE *rbuf)
{
    float Vdut, Idut;
    float rslt;

    YmodeMeas( su, rbuf, &Vdut, &Idut);

    rslt = fabs( Vdut) / fabs(Idut);
    
    if ((rslt -= su->Radj) < 0.0F )
    {
        rslt = 0.0;
        rbuf->pass_fail = AHC_FAIL_UNDER;
    }

    return(rslt);
}



/****************************************************
 * TV or TVSV measurement algorithm
 */
float
ex_tv ( SETUP *su, AHC_TEST_RESPONSE *rbuf)
{
    int nm = su->averaging;     /* number of measurments to average */
    double  v = 0.0;              /* measured voltage, accumulated results */

    if(nm <= 0)
        nm=1;

    do
    {
        v += Vmeas (su);
    } while (--nm);

    if (su->averaging > 1)
        v /= su->averaging;

    return((float) v);
    
}
float
ex_tvsi ( SETUP *su, AHC_TEST_RESPONSE *rbuf)
{
    float Vdut, Idut;

    ZmodeMeas( su, rbuf, &Vdut, &Idut);

    return(Vdut);
}
float
ex_tisv ( SETUP *su, AHC_TEST_RESPONSE *rbuf)
{
    float Vdut, Idut;

    YmodeMeas( su, rbuf, &Vdut, &Idut);

    return(Idut);
}
  
  
float
ex_dio_V ( SETUP *su, AHC_TEST_RESPONSE *rbuf)
{
    float Vdut, Idut,gain,v_dac, v_compl, Rdut, first_meas_Vdac;  
    int i, first_meas_Rs;
    AHC_DIO_V_PARAMS   *param = &(CB->dat.Su1.param.dioV);   // Note we take reference to the parameter data here in execute
    
     
    ZmodeMeas( su, rbuf, &Vdut, &Idut);
        

    return(fabs(Vdut));
}

float
ex_dio_I ( SETUP *su, AHC_TEST_RESPONSE *rbuf)
{
        return 0.0;
}  

  
/****************************************************
 * Execute - run test algorithm
 * called via host interrupt service routine,
 * after communications buffer is copied
 */
int             /* returns AHC_OK or AHC_ERROR */
Execute(AHC_COMM_BUF *cb, SETUP *su, HWREGS *hw, float *samples, int smplsize )
{
    AHC_TEST_RESPONSE *rbuf = &cb->resp;
    float result,v_peak;
    int autorange = 10;        // 10 range tries


    if(su->MeasOpt.bit.AutoRange)
        autorange = 10;
    else
        autorange = 1;

    while (autorange--)
    {
        StartWaveTable(su);

        /* initialize response portion of communications buffer */
        rbuf->OvrUndR= ' ';
        rbuf->pass_fail = AHC_PASS;
       
        result = su_func[cb->hdr.TestType].exec(su, rbuf);
        
        // if pass_fail  already set in execute func
        if (rbuf->pass_fail != AHC_PASS && rbuf->pass_fail != AHC_REDOO) 
            break;   
       
        if (rbuf->pass_fail == AHC_PASS )
        {
            if(result < su->low_val)
                rbuf->pass_fail = AHC_FAIL_LOW;

            if(result > su->high_val)
                rbuf->pass_fail = AHC_FAIL_HIGH;
                
            if ( su->MeasAlg == SU_TV)
            {   v_peak = MAX(fabs(maxV), fabs(minV));
                if (v_peak < su->rng_btm )
                     rbuf->pass_fail = AHC_FAIL_UNDER;
               
                if (v_peak > su->rng_top)
                    rbuf->pass_fail = AHC_FAIL_OVER;
            }
            else
            {
                if (fabs( result) < su->rng_btm)
                    rbuf->pass_fail = AHC_FAIL_UNDER;

                if (fabs(result) > su->rng_top)
                    rbuf->pass_fail = AHC_FAIL_OVER;
            }
            
            if (autorange == 0)
     		break;
        }
        // need to autorange 
        if (rbuf->pass_fail == AHC_FAIL_OVER ||
            rbuf->pass_fail == AHC_FAIL_UNDER ||
            rbuf->pass_fail == AHC_REDOO)
        {
            su->mid_val = result;  // next setup value for autorange

            if ( Setup(cb , su, hw, 1 ) != AHC_OK)
            {
                // ran into the end of possible ranges
                if (g_err == AER_DUT_VAL_TOO_LOW )
                {
                    rbuf->pass_fail = AHC_FAIL_UNDER;
                    result = su->mid_val;
			        g_err = AHC_OK;
                }
                if (g_err == AER_DUT_VAL_TOO_HIGH )
                {
                    rbuf->pass_fail = AHC_FAIL_OVER;
                    result = su->mid_val;
			        g_err = AHC_OK;
                }
                break;
            }
            continue;       // try next range
        }
        else
            break;
    
        
    }

    rbuf->result = C3XtoIEEE (result);
    rbuf->MeasUnits = su->MeasUnits;

    if(!cb->hdr.KeepStim )
    {
        // wait for the stim isr to signal that the Stim has been shut off ???

        if(su->MeasAlg == SU_R3W)
            TMR0delay(su->sqTime); 
        else 
        {   
 //           HW->Listen = SW_ON;          // Measure probe
            TMR0start(su->sqTime);
 //           HW->Listen = SW_OFF;
        }
           
    }
    
    if(su->MeasOpt.bit.KeepValues)
    //if(su->MeasOpt.bit.KeepSamples)
    {
        // Need to copy and convert the fil_tabl data to the Comm buffer
    }

    return AHC_OK;
}
