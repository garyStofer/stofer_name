// LogicDFPIODevice.h
//
// Requires Compuware's DriverWorks classes DriverStudio 2.6.0 (Build 336)
// Author: Gary Stofer , April 2003 , 
//



#ifndef __LogicDFPIODevice_h__
#define __LogicDFPIODevice_h__

// Forward declaration
class Wdfpio;

class LogicDFPIODevice : public KDevice
{
	// Constructors
public:
	SAFE_DESTRUCTORS;
	LogicDFPIODevice(KDriver * parent);
	~LogicDFPIODevice();

	// Member Functions
public:

//	DEVMEMBER_DISPATCHERS  // -- using discrete declarations since it's a subset only
  	virtual NTSTATUS CleanUp(KIrp I); 		// Clean up before Close
	virtual NTSTATUS Close(KIrp I);			// Close from the Apllication
	virtual NTSTATUS Create(KIrp I); 		// Create from the Application
	virtual NTSTATUS DeviceControl(KIrp I);	// Control from the Application
	
	NTSTATUS IOCTL_WDFP_RD_WAIT_Handler(KIrp I);
	NTSTATUS IOCTL_WDFP_CTRL_Handler(KIrp I);
	NTSTATUS IOCTL_WDFP_GET_MMAP_Handler(KIrp I);
	
	Wdfpio * pDriver;
protected:
	KMemoryToProcessMap* ProcMapOfSlot[8];		// Note: Only one Process can have the HW 
												// Relies on DO_EXCLUSIVE when creating instance to this

};



#endif		// __LogicDFPIODevice_h__
