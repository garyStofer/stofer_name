#define DEVICE_MAIN
#include <vtoolscp.h>
#include "vport.h"
#include "..\..\include\DFPio.h"
Declare_Virtual_Device(DFPIO)
#undef DEVICE_MAIN
	
#define PCI_ENUM_FUNC_GET_DEVICE_INFO   0
#define PCI_ENUM_FUNC_SET_DEVICE_INFO   1

#define PLX_9050_STAT_REG 0x4c
#define PLX_9050_CTRL_REG 0x50
#define PLX_9050_LAS0BRD 0x28
#define PLX_9050SW_RESET_BIT 0x40000000	
#define PLX_9050_INT1_ENA  0x43 


#define PAGENUM(p)  (((ULONG)(p)) >> 12)
#define PAGEOFF(p)  (((ULONG)(p)) & 0xFFF)
#define PAGEBASE(p) (((ULONG)(p)) & ~0xFFF)
#define _NPAGES_(p, k)  ((PAGENUM((char*)p+(k-1)) - PAGENUM(p)) + 1)

#define DRIVER_PORT_A 0x3A8
#define DRIVER_PORT_B 0x3A9


// the EEprom stuff
static WORD EepromReadWord(WORD IoBase, UINT EpromConReg, UINT EpromAddr); 
static BOOL EepromWriteWord(WORD IoBase, UINT EpromConReg, UINT EpromAddr, WORD val); 
static BOOL EepromSendCmd(WORD IoBase, UINT cmd, UINT EpromConReg); 
static BOOL EepromClock(WORD IoBase, UINT EpromConReg);

// Global device context array associating known slots to device contetxes
DEV_CTX * slot_ctx[DEV_CNT]  = {NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL};	
int Slot_VirtIOBase[DEV_CNT] = {0x380, 0x388, 0x390, 0x398, 0x3a0,0,0,0}; // only Slot 0 to 4 can virtualized
// GLOBAL device function to erase device contexts
BOOL 
DeleteDevCtx( DEV_CTX *ctx )
{
	int i;

   	for (i=0;i < DEV_CNT; i++ )
	{
		if (ctx == slot_ctx[i] )
		{	
			dprintf("DFPio: Deleteing slot_ctx %p for Slot %d\n", slot_ctx[i], i);

			delete slot_ctx[i]->p_Vport;	  // unhook and delete all port traps
			delete slot_ctx[i];
			slot_ctx[i] = NULL;
				
			return(TRUE);
		}
	}
	return FALSE;
}
  
DFPioVM::DFPioVM(VMHANDLE hVM) : VVirtualMachine(hVM)  
{ /* Class Constructor 	*/
} 

VOID DFPioVM::OnDestroyVM()
{ 	
	// dprintf("On VM Destroy");
}	
 /*
 BOOL VpcioVM::OnVMCriticalInit() { dprintf	("OnVMCriticalInit"); return TRUE; }
 VOID VpcioVM::OnVMTerminate() {	dprintf("On VM Terminate");	}
 VOID VpcioVM::OnVMSuspend()	  {	dprintf(" OnVMSuspend "); }
 BOOL VpcioVM::OnVMResume()	  {	dprintf(" OnVMResume");	return TRUE; }
 VOID VpcioVM::OnCloseVMNotify(DWORD flags){	dprintf(" OnCloseVMNotify "); }
 VOID VpcioVM::OnVMTerminate2(){	dprintf(" OnVMTerminate2 ");}
 VOID VpcioVM::OnDestroyVM2()  {	dprintf(" OnVMDestroy2 ");}
 VOID VpcioVM::OnCloseVMNotify2(DWORD flags){ dprintf(" OnCloseVMNotify2 ");}
*/

 

 
// --------------------------------------------------------------------------------------------
DFPioThread::DFPioThread(THREADHANDLE hThread) : VThread(hThread) 
{ /* Class Constructor */
}

BOOL 
DFPioDevice::OnCreateVM(VMHANDLE hVM)
{	
   // 	dprintf("on VMCeate hVM = %x", hVM);
	return TRUE;
}

BOOL 
DFPioDevice::OnSysDynamicDeviceInit()
{  	
	int i;

	dprintf("DFPio:In OnSysDynamicDeviceInit()\n");
	dprintf("DFPio:sizeof HW reg struct is %d ", sizeof( DFPIO_HW_REGS));

	// initialize the slot context array used to hold context pointers for card instances per slot
	for (i=0;i < DEV_CNT; i++ )
	  	slot_ctx[i] = NULL;

    p_Drvport = NULL;
	if ( (p_Drvport = new DriverPort( ) ) != NULL )
	{
		 p_Drvport->hook(  DRIVER_PORT_A );	 
		 p_Drvport->hook(  DRIVER_PORT_B );
	}
	  
	
 	return TRUE;
}

BOOL 
DFPioDevice::OnSysDynamicDeviceExit()
{	
	int i;
   	dprintf("DFPio:In OnSysDynamicDeviceExit()\n");
	delete p_Drvport;
	return TRUE;
}				



//********************************************************************************/
//********************************************************************************/
// function:        initialises allocated recources     
// called by:           configuration manager
// return value:        CR_SUCCESS, CR_FAILURE, CR_DEFAULT
DEBUG_CONFIG_NAMES	
 
void  
OnConfigStop (DEVNODE devnode, DEV_CTX * pDevCtx)
{	 
	unsigned long  pci_ctrl;


  	pDevCtx->p_Vport->unhookall();

	// issue a SW reset to the PCI card
	// double writes to give some extra time
	// dprintf("DFPio: -- Issuing SW reset to pcio ");
	
	if (pDevCtx != NULL ) 
	{
		pci_ctrl = _inpd( pDevCtx->IoBase + PLX_9050_CTRL_REG );	
		_outpd( pDevCtx->IoBase + PLX_9050_CTRL_REG, pci_ctrl | PLX_9050SW_RESET_BIT);
		_outpd( pDevCtx->IoBase + PLX_9050_CTRL_REG, pci_ctrl | PLX_9050SW_RESET_BIT);
		_outpd( pDevCtx->IoBase + PLX_9050_CTRL_REG, pci_ctrl );
		// disbale interrupts at the pci interface
		_outpd( pDevCtx->IoBase + PLX_9050_STAT_REG, 0 );

   		if (pDevCtx->MemBaseLinear)
		{
			LinPageUnLock( PAGENUM(pDevCtx->MemBaseLinear),1,0);
			PageDecommit( PAGENUM(pDevCtx->MemBaseLinear),1, 0 );
			pDevCtx->MemBaseLinear = 0;
	 	}
	}	
}


CONFIGRET
OnConfigStart( DEVNODE devnode, DEV_CTX * pDevCtx)
{
	CONFIGRET cr = CR_SUCCESS;
	CMCONFIG config;
	unsigned short DevId;
	unsigned long  pci_ctrl;
	unsigned long dat0;
	unsigned long port;
	unsigned long hw_rev;
	unsigned int  port_hook_failure = 0;

  
	cr = CONFIGMG_Get_Alloc_Log_Conf(&config, devnode, CM_GET_ALLOC_LOG_CONF_ALLOC);

	if ( ! (cr == CR_SUCCESS  || cr == CR_DEFAULT) )
	{
		dprintf("DFPio:failed getAlloc_LogConf");
		return(cr);
	}

	if ( config.wNumIOPorts < 1 || config.wNumMemWindows != 1 )
	{
		dprintf("DFPio:Failing CONFIG_START for DFPIO, did not get expected resources");
		return( CR_FAILURE);
	}

	// Store the instances Devnode for later use in the W32DIOC interface
	pDevCtx->devnode = devnode;
	
	// The following is a workaround for the 9050's chips problems of decoding the local config reg. space
	// when aligned at 0x80. When Configmg proc\vides such an addr. the chip doesn't decode for reads
	// To work around this we allocate via BAR3 a IO space of 256 bytes which will be allocated on a page
	// boundry. Then we copy the contents of BAR3 to BAR1 and keep the page aligned address in the device
	// context for use by other components of the driver.

	CONFIGMG_Call_Enumerator_Function(devnode,
								PCI_ENUM_FUNC_GET_DEVICE_INFO,0x2,&DevId,sizeof(DevId),0);

	if ( config.wIOPortBase[0] & 0x80 && DevId == 0x9050 )	     // the port space is not page aligned, the 9050 
	{	 
		if ( config.wNumIOPorts != 2 )
		{ 
			dprintf("DFPio: Need page aligned IO space for 9050 chip\n");
			return(CR_FAILURE);
		}
		else
		{	 
			// copy BAR3 to BAR1 so that the device does a proper decode
			pDevCtx->IoBase = port = config.wIOPortBase[1];
			CONFIGMG_Call_Enumerator_Function( devnode,
								PCI_ENUM_FUNC_SET_DEVICE_INFO,0x14,&port,sizeof(port),0);
		}
	}
	else
		pDevCtx->IoBase = config.wIOPortBase[0];   
	// end of workaround

	// storing the device resources in the device context
	pDevCtx->MemBase = config.dMemBase[0];
	pDevCtx->MemSize = config.dMemLength[0]; 

    dprintf("DFPio:IOBASE  : %3.3Xh IOSize : %3.3Xh",pDevCtx->IoBase,config.wIOPortLength[0]);	 
	dprintf("DFPio:MemBase : %x Memlenght : %x",pDevCtx->MemBase,pDevCtx->MemSize);
    hw_rev = _inpw(pDevCtx->IoBase + PLX_9050_LAS0BRD);
	dprintf("DFPio:The LAS0BRD Rgister is 0x%d \n", hw_rev);

	// mapping the hardware addres to global W32 space
	pDevCtx->MemBaseLinear = (ULONG) PageReserve( PR_SYSTEM, 1, PR_FIXED );
	PageCommitPhys(	PAGENUM(pDevCtx->MemBaseLinear), 1, PAGENUM(pDevCtx->MemBase),PC_INCR|PC_WRITEABLE|PC_USER);		
	LinPageLock(PAGENUM(pDevCtx->MemBaseLinear), 1, 0);
	dprintf("DFPio: Physical memory %p mapped to linear addr %lx\n",pDevCtx->MemBase,pDevCtx->MemBaseLinear);

   // Fix up the interrupt enable setting in the EEprom to DISABLE so we don't 
	// get interrupts on power up of the board
    if (EepromReadWord(pDevCtx->IoBase, PLX_9050_CTRL_REG, 0x2f) != 0)
		EepromWriteWord(pDevCtx->IoBase, PLX_9050_CTRL_REG, 0x2f, 0x0);	 
   
   // fix for complications with some MB/BIOS that will not page align memory blocks
   // Change EEprom so the card requests a 4Kb block instead of the 256bytes 
   // The change becomes effective after power has been disconnected from the adapter  
   	EepromWriteWord(pDevCtx->IoBase, PLX_9050_CTRL_REG, 8, 0xFFFF);			// correct BAR0 to ask for 4K 	 
    EepromWriteWord(pDevCtx->IoBase, PLX_9050_CTRL_REG, 9, 0xF000);	        // == 4K 
   
	   
	// issue a SW reset to the PCI card
	// double writes to give some extra time
	dprintf("DFPio:Issuing SW reset to DFPio ");
	pci_ctrl = _inpd( pDevCtx->IoBase + PLX_9050_CTRL_REG );	
	_outpd( pDevCtx->IoBase + PLX_9050_CTRL_REG, pci_ctrl | PLX_9050SW_RESET_BIT);
	_outpd( pDevCtx->IoBase + PLX_9050_CTRL_REG, pci_ctrl | PLX_9050SW_RESET_BIT);
    _outpd( pDevCtx->IoBase + PLX_9050_CTRL_REG, pci_ctrl | PLX_9050SW_RESET_BIT);
    _outpd( pDevCtx->IoBase + PLX_9050_CTRL_REG, pci_ctrl ); 
	
	pDevCtx->HWregs =(DFPIO_HW_REGS *) (pDevCtx->MemBaseLinear );  

	/*	Enable this to print out the eeprom contents of the board
	WORD dta,dta2;
	int i;
	  										               
	for (i = 0;i <=0x30 ;i+=2 )
	{
	  	dta = EepromReadWord(pDevCtx->IoBase, PLX_9050_CTRL_REG, i);	
		dta2 = EepromReadWord(pDevCtx->IoBase, PLX_9050_CTRL_REG, i+1);
		dprintf( "DFPio:EEPROM addr %2.2x = %4.4x:%4.4x \n", i*2, dta,dta2);	
	}
	*/

	hw_rev = pDevCtx->HWregs->CtrlStat.Reset_byte;
	dprintf("DFPio:The HW rev of the 51166 card is 0x%X (expect 0zA0 or 0xA1)\n", hw_rev);


    //  
    if (pDevCtx->VirtIoBase == 0)
		return(cr);
	// trapping the ports for all VM's 
	
   	dprintf("DFPIO Hooking port (base) address 0x%x\n", pDevCtx->VirtIoBase);
	unsigned int Block, Offset;
	for (Block = 0; Block < 0x8000 ;Block+= 0x1000 )
	{
		for (Offset = 0 ;Offset < 7 ;Offset+=2 )
		{
			if ( ! pDevCtx->p_Vport->hook(pDevCtx->VirtIoBase + Block + Offset) )
				{
					dprintf("DFPIO.vxd could not hook Port address %x\n",pDevCtx->VirtIoBase );
					port_hook_failure = 1;
					break;
				}
		 }

		 if (port_hook_failure)		// Don't fail the install of the driver instance because we 
									// cant get the legacy interface, Still leave the Win32 interface
		 {
			pDevCtx->p_Vport->unhookall();
		 	break;
		 }
	}
//dprintf("The DS adddress range base is %p", pDevCtx->HWregs);
//dprintf("The address of reg 0 is %p", & pDevCtx->HWregs->CtrlStat.Ctrl_Stat_byte);
//dprintf("The address of reg DacVal is %p", & pDevCtx->HWregs->PortCctl.dword_dat);
//dprintf("The CtrlStat is  %p",  pDevCtx->HWregs->CtrlStat.Ctrl_Stat_byte);

	return(cr);
}

CONFIGRET CM_HANDLER 
OnConfigure(CONFIGFUNC cf, SUBCONFIGFUNC scf, DEVNODE devnode, DWORD refdata, ULONG flags)
{		

	DEV_CTX *pDevCtx = (DEV_CTX *) refdata;  
	

	if ( cf < NUM_CONFIG_COMMANDS )
		dprintf("DFPIO: Config_handler msg %d: %s for Device CTX %x", cf, lpszConfigName[cf], refdata);
	else
		dprintf("DFPIO: OnConfig called invalid msg number %d\n", cf);	
 
	switch ( cf )
	{
		case CONFIG_START:
   			return OnConfigStart( devnode, (DEV_CTX *) refdata);
			break;

		case CONFIG_TEST:
			return(CR_SUCCESS);
			break;

		case CONFIG_STOP:
		{	 
			OnConfigStop(devnode, (DEV_CTX *) refdata);
           	return CR_SUCCESS;  
		} 
		
		case CONFIG_REMOVE:
		{	 
			OnConfigStop(devnode, (DEV_CTX *) refdata);
        	DeleteDevCtx((DEV_CTX*) refdata);
			return CR_SUCCESS;  
		} 
		
		default:
			return CR_DEFAULT;
	}

	return( CR_FAILURE);	
}
						   						   
CONFIGRET 
DFPioDevice::OnPnpNewDevnode(DEVNODE devNode, DWORD loadType)
{

	char 		buf[100];
	UCHAR 		SlotDevnum;
	int	 		SlotIndex = -1;
   	DWORD 		size = 1;
   	UCHAR 		MyDevNum;
	int 		i;
	CMBUSTYPE 	busType;
	struct      PCIAccess_s pci_info;
	DWORD 		pci_info_sz = sizeof(struct PCIAccess_s);	

	VRegistryKey *p_Vreg = NULL;

	dprintf("DFPio:OnPnP new devnode : %xi - Loadtype %d", devNode, loadType);
   	
	 
	if ( loadType == DLVXD_LOAD_DEVLOADER )
	{

	   	if ( CONFIGMG_Get_Bus_Info(devNode, &busType, &pci_info_sz, &pci_info, 0) != CR_SUCCESS )
	   	{
			dprintf("DFPio:Could not get Bus Info for devnode 0x%x -- failing devloader\n", devNode);
	   		return CR_FAILURE;
	   		
	   	}

		MyDevNum = pci_info.DevFuncNo >> 3;

		// A card on the motherboard defaults to slot 7	 (0 based)
 		if (pci_info.BusNo == 0 && slot_ctx[7] == NULL ) // A card on the motherboard
		{
			SlotIndex = 7;
	 	}
	 	else 	   	// Read the registry to find the Slot to devNumber association, This is how we can correlate the
		{ 			// individual CCC's with the DR2p slot's 

		  	if ( CONFIGMG_Get_DevNode_Key(devNode, NULL, buf, 100, CM_REGISTRY_SOFTWARE) == CR_SUCCESS )
		  	{
				p_Vreg = new VRegistryKey(PRK_LOCAL_MACHINE, buf);
				for (i=0; i < DEV_CNT ; i++ )
				{
					sprintf(buf,"Slot%dDevnum", i);
					if ( p_Vreg->getValue( buf, &SlotDevnum , &size, NULL) == FALSE )
						SlotDevnum = 0;
					
					// match up this instances device number with the "know" slots 
					// only devices inserted into known slots can be used since only then do 
					// we know the relationship to the DR2p card 
					if ( MyDevNum == SlotDevnum )
					{
						SlotIndex = i;
						break;
					}	 
				}
		  		delete p_Vreg;
			}
		}
	 
		if ( SlotIndex >= 0 && SlotIndex < DEV_CNT )		
		{
			
			if (slot_ctx[SlotIndex] == NULL )  // just making sure it is not already allocated 
			{
				if ( (slot_ctx[SlotIndex] = new  DEV_CTX) == NULL )
					return(CR_FAILURE);	  
			}
			dprintf("New device context is %p for DevNum %d in Slot %d\n", slot_ctx[SlotIndex],MyDevNum, SlotIndex);
			
			// All Context initialization goes here !! 
			slot_ctx[SlotIndex]->MemBaseLinear = NULL;
			slot_ctx[SlotIndex]->VirtIoBase = Slot_VirtIOBase[SlotIndex]; 
			slot_ctx[SlotIndex]->V_data.addr.counter = 0;
			slot_ctx[SlotIndex]->V_data.ctr_dir = 0;
   			slot_ctx[SlotIndex]->V_data.CtrlStat.byte_dat = 0;
			slot_ctx[SlotIndex]->V_data.vpp_rng_100mv = 0;

			if ( ( slot_ctx[SlotIndex]->p_Vport = new DFPioPort(slot_ctx[SlotIndex])  )== NULL )
			{
				dprintf("Could not allocate V_port class");
 				return(FALSE);
 		   	}

		   			    		   			
			// This is the normal way out of here 
			return CONFIGMG_Register_Device_Driver(devNode,	OnConfigure, 
					(unsigned long)slot_ctx[SlotIndex], CM_REGISTER_DEVICE_DRIVER_REMOVABLE | CM_REGISTER_DEVICE_DRIVER_DISABLEABLE);
		}
		else
		{
			dprintf("DFPio:Could not locate slot for DevNum %d -- failing devloader", MyDevNum);
			return CR_FAILURE;		
		}
	}
 	return CR_DEFAULT;
}

DWORD 
DFPioDevice::OnW32DeviceIoControl(PIOCTLPARAMS p)
{
	CONFIGRET status = DEVIOCTL_NOERROR; 
	DFP_IO_CTRL *p_ctrl;
	DEV_CTX * ctx;
	unsigned long LaS0Brd;

   	*p->dioc_bytesret = 0;	 // returns are done via the p->dioc_Inbuf

	switch ( p->dioc_IOCtlCode )
	{		 									  
 	   	case IOCTL_DFP_GET_MMAP:
		case IOCTL_DFP_CTRL:
		case IOCTL_DFP_RD_WAIT:
			// perform error check 
   			if ( p->dioc_cbInBuf < sizeof( DFP_IO_CTRL) )
   				return DEVIOCTL_ERROR_INVALID_ARG;
  			
  			p_ctrl = (DFP_IO_CTRL * ) (p->dioc_InBuf);
			
			if ( p_ctrl->SlotIndex >= 0 && p_ctrl->SlotIndex < DEV_CNT )		
			{	
				if (slot_ctx[p_ctrl->SlotIndex] == NULL )  //Slot  is NOT installed  
				{
			   		p_ctrl->BaseAddr =  NULL;
					dprintf("No DFPIO for slot %d\n",p_ctrl->SlotIndex); 
					return(DEVIOCTL_ERROR_NO_SLOT);
				}
		   	}
			else
				return DEVIOCTL_ERROR_INVALID_ARG;

			ctx = slot_ctx[p_ctrl->SlotIndex];

			// No input error -- proceed
			if (p->dioc_IOCtlCode == IOCTL_DFP_GET_MMAP)
			{
				p_ctrl->BaseAddr =  (void *) ctx->MemBaseLinear;
				break;
			}
			
			if (p->dioc_IOCtlCode == IOCTL_DFP_RD_WAIT)
			{
				// Wait state control for all reads
				LaS0Brd = _inpd( ctx->IoBase + PLX_9050_LAS0BRD );
				LaS0Brd &= 0xFFFFF83F;      // remove the current NRAD wait states
				p_ctrl->val &= 0x1F;        // NRAD occupies bits 10:6 of the register
				LaS0Brd |= (p_ctrl->val << 6);
				_outpd(  ctx->IoBase + PLX_9050_LAS0BRD, LaS0Brd);
				break;
		  	}

			if (p->dioc_IOCtlCode == IOCTL_DFP_CTRL )
			{
				switch (p_ctrl->mode )	
				{
					case MODE_DFP_RESET:
						// these things get set by the reset action in the HW
						ctx->V_data.CtrlStat.byte_dat = 0;
						ctx->V_data.ctr_dir = 0;
						ctx->V_data.vpp_rng_100mv =0;
						ctx->HWregs->PortABC_Ctl.words.AB_AUX_ctrl = 0xff33;  // commanding the Direct relaus open and AB as inputs
						ctx->HWregs->CtrlStat.Reset_byte = SW_RESET_BIT; 
						break;

					case MODE_DFP_HSK_RESET:
						if (p_ctrl->Set_clr)
							ctx->HWregs->CtrlStat.Reset_byte = PA_HSK_RESET_BIT;
						else 
							ctx->HWregs->CtrlStat.Reset_byte = PB_HSK_RESET_BIT; 
		 				break;

				  	case MODE_DFP_VPP_ON:
						ctx->V_data.CtrlStat.Ctrl_bits.VPP_on =	p_ctrl->Set_clr;
						break;
						
					case MODE_SER:
						ctx->V_data.CtrlStat.Ctrl_bits.Mode_S_P = 1;
						ctx->V_data.CtrlStat.Ctrl_bits.Smode = p_ctrl->Set_clr;
						break;
			
					case MODE_PAR:
						ctx->V_data.CtrlStat.Ctrl_bits.Mode_S_P = 0;
						ctx->V_data.CtrlStat.Ctrl_bits.Smode = ! p_ctrl->Set_clr;
						break;
				  				 	
					case MODE_JTAG_V:
						ctx->V_data.CtrlStat.Ctrl_bits.Jtag_5V = p_ctrl->Set_clr;

						break;
					case MODE_MAX242_ENA:
						ctx->V_data.CtrlStat.Ctrl_bits.Max242_On = p_ctrl->Set_clr;
						break;

					case MODE_DFP_ENA:
						ctx->V_data.CtrlStat.Ctrl_bits.DFP_ena = p_ctrl->Set_clr;
						break;
						
					case MODE_TRxA_INV:
						ctx->V_data.CtrlStat.Ctrl_bits.TRxA_ena = p_ctrl->Set_clr;
						break;
						
					case MODE_TRxB_INV:
						ctx->V_data.CtrlStat.Ctrl_bits.TRxB_ena	= p_ctrl->Set_clr;						break;
						break;		 	

					  				}
				// send to HW
				ctx->HWregs->CtrlStat.Ctrl_Stat_byte = 	ctx->V_data.CtrlStat.byte_dat;
			   	break;
			}
		
	   		default:
				dprintf("DFPio:W32DIOC IO_CTRL called %ld but not handled\n",p->dioc_IOCtlCode);
	 } 
	return status;
}


DFPioPort::DFPioPort( DEV_CTX * ctx) : VPort()
{
    // keep the device context with the V_IO_port instance so we can get back
	// at it when the handler is activated
	m_Ctx = ctx; 
	// initialize other class members, if any
}

	  
DWORD
DFPioPort::port_write(WORD block, WORD offset, unsigned short w_data16, BOOL WordWrite)
{
	union Misc_Reg_legacy Rmisc;

	unsigned int dac_tmp;
	unsigned long LaS0Brd;

	// unsigned char  w_data8 = w_data16 & 0xFF;
	unsigned short w_data8 = w_data16 ;

	
	// Address counter prime/load/update/increment
	if (block == 0 ) 
	{	
		if ( offset == 0)
		{	dprintf("Write Address ctr  offset %d --  0x%x", offset, w_data16 );
	 		m_Ctx->V_data.addr.I[0] = w_data16;	
		}

	   	if ( offset == 2)
		{	dprintf("Write Address ctr  offset %d --  0x%x", offset, w_data8 );
			m_Ctx->V_data.addr.B[2] = w_data8;			
		}

		if ( offset == 4)
	   	{	dprintf("Write Address ctr  offset %d --  0x%x", offset, w_data16 );
	   		m_Ctx->V_data.addr.I[0] = w_data16;	
	   	}
	   		
	   	if ( offset == 6)
	   	{	
	   		if(m_Ctx->V_data.ctr_dir) 
	   			m_Ctx->V_data.addr.counter++;
	   		else
		 		m_Ctx->V_data.addr.counter--;
		}

		if (offset == 2 || offset == 4 || offset == 6 )
		{
		 	dprintf("         Updating addr ctr = 0x%x\n", m_Ctx->V_data.addr.counter);
			// writing all 23 bits onto the HW	-- Side effect emulation of ISA card
			m_Ctx->HWregs->DR2p.dword_dat = m_Ctx->V_data.addr.counter;

		}	
	}

	// Port C control (15..23),A/B/Aux Control (0..15), Port A/B handshake (0..7)
	if (block == 1)	
	{
		dprintf("Write Port Control  offset %d --  0x%x",offset, w_data16 );
	
		if (offset == 0)
		 	m_Ctx->HWregs->PortABC_Ctl.bytes.C_ctrl = w_data8;	
		
		if (offset == 2)
			m_Ctx->HWregs->PortABC_Ctl.words.AB_AUX_ctrl = w_data16; 	
		
		if (offset == 4)
		   m_Ctx->HWregs->CtrlStat.Reset_byte = PA_HSK_RESET_BIT;
		
		if (offset == 6)
			m_Ctx->HWregs->CtrlStat.Reset_byte = PB_HSK_RESET_BIT;
	}
 
 	// Gate Array instructions (0..15)
	if (block ==2 )
	{
		dprintf("Write GA instructions offset %d --  0x%x",offset, w_data16 );
	
		if (offset == 0)
		 	m_Ctx->HWregs->GA_Inst.words.Instr = w_data16;	
		
		if (offset == 2)
			m_Ctx->HWregs->GA_en.words.Enables = w_data16; 	
		
		if (offset == 4)
		   m_Ctx->HWregs->GA_dat.words.Data = w_data16;
		
		if (offset == 6)
			m_Ctx->HWregs->GA_Gc.words.GrayCode = w_data16;
	}
	
	// Port A data, Port B data (on 8..15), Port C data, Port A&B data (0..15)
	if (block == 3)
	{
		if ( offset == 0 )
		{
			dprintf("Sending Port A data 0x%x", w_data8);
		 	m_Ctx->V_data.addr.B[0] = w_data8;	// emulating Side effect 	
			m_Ctx->HWregs->DR2p.bytes.PA = w_data8;
		}	

		if (offset == 2)
		{
			dprintf("Sending Port B data 0x%x", w_data16 & 0xFF00);
			m_Ctx->V_data.addr.B[1] = (unsigned char) ((w_data16 & 0xFF00) >> 8);	// emulating Side effect 	
			m_Ctx->HWregs->DR2p.bytes.PB = w_data16 >> 8;
		}


		if (offset == 4)
		{
			dprintf("Sending Port C data 0x%x", w_data8 );
			m_Ctx->V_data.addr.B[2] = w_data8;	// emulating Side effect 	
			m_Ctx->HWregs->DR2p.bytes.PC = w_data8;
		}

		if (offset == 6)
		{
			dprintf("Sending Port A&B data 0x%x", w_data16 );
			m_Ctx->V_data.addr.I[0] = w_data16;	// emulating Side effect 	
			m_Ctx->HWregs->DR2p.words.PAB = w_data16;
		}
	}

	// CtrTmr0 (0..15), CtrTmr1 (0..15)	, CtrTmr2 (0..15), Ctr_tmr mode (0..7)
	if (block == 4)
	{
		if (offset == 0)
		{
			dprintf("setting counter 0 to 0x%x", w_data16);
			m_Ctx->HWregs->CTC0.bytes.data = w_data8;
			m_Ctx->HWregs->CTC0.bytes.data = (w_data16 >> 8);
		}

		if (offset == 4)	// This was miswired in the ISA card, so now we have to bend it here
		{
			dprintf("setting counter 2 to 0x%x", w_data16);
			m_Ctx->HWregs->CTC1.bytes.data = w_data8;
			m_Ctx->HWregs->CTC1.bytes.data = (w_data16 >> 8);
		}

		if (offset == 2)  // This was miswired in the ISA card, so now we have to bend it here
		{
			dprintf("setting counter 1 to 0x%x", w_data16);
			m_Ctx->HWregs->CTC2.bytes.data = w_data8;
			m_Ctx->HWregs->CTC2.bytes.data = (w_data16 >> 8);
		}

		if (offset == 6)
		{
			dprintf("Setting CTRtmr mode to 0x%x", w_data8);
			m_Ctx->HWregs->CTCMode.bytes.Mode = w_data8;
		}
	}

	// SIO B cmd (0..7), SIO B Data(0..7), SIO A  cmd (0..7), SIO A  Data (0..7)
	if (block == 5)
	{
		if (offset == 0)
		{
			dprintf("SIO B command 0x%x", w_data8);
			m_Ctx->HWregs->SioBcmd.bytes.cmd = w_data8;
		}

		if (offset == 2)
		{
			dprintf("SIO B data 0x%x", w_data8);
			m_Ctx->HWregs->SioBdta.bytes.data = w_data8;
		}

		if (offset == 4)
		{
			dprintf("SIO A command 0x%x", w_data8);
			m_Ctx->HWregs->SioAcmd.bytes.cmd = w_data8;
		}

		if (offset == 6)
		{
			dprintf("SIO A data 0x%x", w_data8);
			m_Ctx->HWregs->SioAdta.bytes.data = w_data8;
		}
	}

	// Software Reset (0..7), Vpp Data (0..7), Misc Reg(0..7) 
	if ( block == 6)
	{
		if (offset == 0)  // NEW!! JTAG signals	 and wait state control
		{
		    if (WordWrite == FALSE)
		    {
		    	// TDI, TMS and RdClk are Sent to the Hardware
	   			dprintf("Setting JTAG signals to %x", w_data8 );
		   		m_Ctx->HWregs->JT_IO.bytes.io_byte = w_data8;
		   	}
		   	else
		   	{
		   		// Wait state control for all reads
		   		LaS0Brd = _inpd( m_Ctx->IoBase + PLX_9050_LAS0BRD );
		   		LaS0Brd &= 0xFFFFF83F;  // remove the current NRAD wait states
				w_data8 &= 0x1F;        // NRAD occupies bits 10:6 of the register
				LaS0Brd |= (w_data8 << 6);
				_outpd(  m_Ctx->IoBase + PLX_9050_LAS0BRD, LaS0Brd);
			   		 
		   	}
		}
	

		if (offset == 2)  // SW Reset
		{
			dprintf("Sw reset executed");
			// these things get set by the reset action in the HW
			m_Ctx->V_data.CtrlStat.byte_dat = 0;
			m_Ctx->V_data.ctr_dir = 0;
			m_Ctx->V_data.vpp_rng_100mv = 0;
			m_Ctx->HWregs->PortABC_Ctl.words.AB_AUX_ctrl = 0xff33;  // commanding the Direct relaus open and AB as inputs
			m_Ctx->HWregs->CtrlStat.Reset_byte = SW_RESET_BIT | 0x10;
			m_Ctx->HWregs->JT_IO.bytes.ctrl_byte = 0;
		   	// mode	 = Parallel;
			// VPP_ena = 0;
			// Rs232_ena = 0;
			// DFP_ena = 0;
			// ChA_Inv =0;
			// ChB_Inv = 0; 
			// Jtag signals = 3V
			// Jtag speed == SLOW
		}

		if (offset == 4)
		{
			dprintf(" Vpp set to 0x%x in range %d", w_data8, m_Ctx->V_data.vpp_rng_100mv);
			//the 8562 dac and following Op_amp have a bit weight of 6.25mv which 
			//works out to be 50mv at bit 3 and 100mv at bit 4,
			dac_tmp = ( m_Ctx->V_data.vpp_rng_100mv ) ? (w_data8 << 4)  : (w_data8  << 3) ;
	   		m_Ctx->HWregs->CtrlStat.Dac_val = dac_tmp;
	   		dprintf(" Dac value set to 0x%x ", dac_tmp);
		}

		if (offset == 6)  // Misc Register
		{	
			Rmisc.control = w_data8;
			dprintf("Misc Register set to 0x%x", w_data8);
			m_Ctx->V_data.ctr_dir = Rmisc.bits.ctr_dir;	   // Up down 
			// retain the Jtag3V bit -- overwrite the rest 	
			Rmisc.bits.ctr_dir = m_Ctx->V_data.CtrlStat.Ctrl_bits.Jtag_5V;
			m_Ctx->V_data.CtrlStat.byte_dat = Rmisc.control;
			// output to card
			m_Ctx->HWregs->CtrlStat.Ctrl_Stat_byte = m_Ctx->V_data.CtrlStat.byte_dat; 					
		}
	}
	
	// Trigger Timer 0,1,2,Vpp Range
	if (block == 7)
	{
		if (offset == 0)
		{
			dprintf("trigger Tmr0");
			m_Ctx->HWregs->CTC0.bytes.trigger = 0; // data doesn't matter
		}

		if (offset == 2)
		{
			dprintf("trigger Tmr1");
			m_Ctx->HWregs->CTC1.bytes.trigger = 0; // data doesn't matter
		}

		if (offset == 4)
		{
			dprintf("trigger Tmr2");
			m_Ctx->HWregs->CTC2.bytes.trigger = 0; // data doesn't matter
		}

		if (offset == 6)
		{
			m_Ctx->V_data.vpp_rng_100mv = w_data8 & 0x1;
			dprintf("Setting Vpp range to %d", 	m_Ctx->V_data.vpp_rng_100mv);
			// NEW! Jtag 3/5V control on bit 2	
			m_Ctx->V_data.CtrlStat.Ctrl_bits.Jtag_5V =  (w_data8 & 0x2 )? 1 : 0;
			dprintf("Setting JTAG signalling to %x 1=5V, 0=3V ", m_Ctx->V_data.CtrlStat.Ctrl_bits.Jtag_5V);
  		   	m_Ctx->HWregs->CtrlStat.Ctrl_Stat_byte = m_Ctx->V_data.CtrlStat.byte_dat; 
		}
	}

	return(0);
}

DWORD 
DFPioPort::port_read(WORD block, WORD offset )
{
	union Stat_Reg_legacy Status;	 
	unsigned short tmp;
	static unsigned int index = 0;

	Status.val =0;
	if (block == 0 )
	{
		if (offset == 0 || offset == 4)
		{
			Status.val = m_Ctx->V_data.addr.counter & 0xFFFF; 
			dprintf("reading address ctr 0..15 0x%x", Status.val); 	
		}

		if (offset == 2 )
		{  
		    Status.val = (m_Ctx->V_data.addr.counter >> 16)  & 0xF | (m_Ctx->V_data.addr.counter >> 12) & 0xf00; 
			dprintf("reading address ctr 16..23 on 0..7 0x%x", Status.val); 				
		}
	}

	if (block == 3 	)
	{
		if (offset == 0)
		{
			Status.val = m_Ctx->HWregs->DR2p.bytes.PA;
			dprintf("Reading Port A data 0x%x", Status.val );				
		}

		if (offset == 2)
		{
			Status.bytes[1] = m_Ctx->HWregs->DR2p.bytes.PB;
			dprintf("Reading Port B data 0x%x", Status.val);				
		}

		if (offset == 4)
		{
			tmp =  m_Ctx->HWregs->DR2p.bytes.PC;
			Status.val = ((tmp << 4) & 0xF00 )| tmp & 0xF;
		   	dprintf("Reading Port C data 0x%x (real_value = %x)\n", Status.val, tmp);				
		}

		if (offset == 6)
		{
			Status.val = m_Ctx->HWregs->DR2p.words.PAB;
		   	dprintf("Reading Port A&B data 0x%x", Status.val);				
		}
	}		

	if (block == 4)
	{
		if (offset == 0)
		{
			Status.bytes[0] = m_Ctx->HWregs->CTC0.bytes.data;
			Status.bytes[1] = m_Ctx->HWregs->CTC0.bytes.data;
			dprintf("Reading CtrTmr 0 0x%x", Status.val);
		}

		if (offset == 4) // This was miswired in the ISA card, so now we have to bend it here
		{
			Status.bytes[0] = m_Ctx->HWregs->CTC1.bytes.data;
			Status.bytes[1] = m_Ctx->HWregs->CTC1.bytes.data;
			dprintf("Reading CtrTmr 2 0x%x", Status.val);
		}

		if (offset == 2) // This was miswired in the ISA card, so now we have to bend it here 
		{
			Status.bytes[0] = m_Ctx->HWregs->CTC2.bytes.data;
			Status.bytes[1] = m_Ctx->HWregs->CTC2.bytes.data;
		   	dprintf("Reading CtrTmr 1 0x%x", Status.val);
		}
	}

	if (block == 5)
	{
		if (offset == 0)
		{
			Status.val = m_Ctx->HWregs->SioBcmd.bytes.cmd;
			dprintf("Reading SIOB cmd = 0x%x", Status.val); 
		}

		if (offset == 2)
		{
			Status.val = m_Ctx->HWregs->SioBdta.bytes.data;
			dprintf("Reading SIOB data = 0x%x", Status.val); 
		}

		if (offset == 4)
		{
			Status.val = m_Ctx->HWregs->SioAcmd.bytes.cmd;
			dprintf("Reading SIOA cmd = 0x%x", Status.val); 
		}

		if (offset == 6 )
		{
			Status.val = m_Ctx->HWregs->SioAdta.bytes.data;
			dprintf("Reading SIOA data = 0x%x", Status.val); 
		}
	}

	if (block == 6)
	{
	    if( offset == 0)
		{
			Status.val = m_Ctx->HWregs->CtrlStat.Ctrl_Stat_byte;	
			Status.bits.Ctr_dir =  (m_Ctx->V_data.ctr_dir) ? 3 : 0;	

			dprintf("Reading Card Status = 0x%x", Status.val);
		}

		if (offset == 2)  // NEW !	 JTAG signal read
		{
   			Status.val = m_Ctx->HWregs->JT_IO.bytes.io_byte;
   			dprintf("Reading Jtag signals 0x%x", Status.val);	// never automatically create a TCK
		}

	  	// offset 4 and 6 are unused 
	 
	}

	if (block == 7 && offset == 6)		// The ISA way of reading the card type
	{  	
		index = 0;	
	    dprintf("Reading legacy Card type 0x2");
		Status.val = 0x2;				// Signature of PCI  DFP io card	
	}
	
					
	// all read returns go trough here
 	return(Status.val);
}


DWORD 
DFPioPort::handler(VMHANDLE hVM,DWORD port,CLIENT_STRUCT* pRegs,DWORD iotype,DWORD outdata)
{  
	int block, offset;
    
	
	block = ( port & 0xf000 ) >> 12;  	 // the legacy addressing scheme of blocks and offsets 
	offset = port & 0x6;

	switch (iotype)
	{
		case BYTE_OUTPUT:
			return (port_write( block, offset, (outdata & 0xff), FALSE));
			break;

		case WORD_OUTPUT:
			return (port_write(block, offset, (outdata & 0xffff), TRUE));
			break;
	
		case BYTE_INPUT:
		case WORD_INPUT:
			return(port_read(block, offset ));
			break;
	
	
		default:
			dprintf("DFPIO: Porthandler got called with unsupported io_type\n");
			break;
				  	
	}
	return(0);
}
	
// This class handles the port trapping for the driver (not device) interface.
DriverPort::DriverPort( ) : VPort()
{
	// initialize other class members, if any
}

DWORD 
DriverPort::handler(VMHANDLE hVM,DWORD port,CLIENT_STRUCT* pRegs,DWORD iotype,DWORD outdata)
{  
	static unsigned int index = 0;
	unsigned char devices = 0; 		// bit field for active devices
	unsigned long pci_ctrl;

	switch (iotype)
	{
	   	case BYTE_OUTPUT:
			if ( port == DRIVER_PORT_A )
			{
				if (outdata < DEV_CNT )
				{
					index = outdata;
			 						
					if (slot_ctx[index] != NULL)
					{
						dprintf("Resetting idividual DFPIO slot %d and attached DR card \n", index);
						
					   	slot_ctx[index]->V_data.CtrlStat.byte_dat = 0;
						slot_ctx[index]->V_data.ctr_dir = 0;
						slot_ctx[index]->V_data.vpp_rng_100mv = 0;

					    slot_ctx[index]->HWregs->CtrlStat.Ctrl_Stat_byte  = 0x20; // enable DFP
						slot_ctx[index]->HWregs->GA_Inst.words.Instr  = 1; // clear relays
						slot_ctx[index]->HWregs->PortABC_Ctl.words.AB_AUX_ctrl = 0xff33;   //commanding the Direct relaus open and AB as inputs
						slot_ctx[index]->HWregs->CtrlStat.Reset_byte = SW_RESET_BIT | 0x10;
						slot_ctx[index]->HWregs->JT_IO.bytes.ctrl_byte = 0;

					   	// mode	 = Parallel;
						// VPP_ena = 0;
						// Rs232_ena = 0;
						// DFP_ena = 0;
						// ChA_Inv =0;
						// ChB_Inv = 0; 
						// Jtag signals = 3V
						// Jtag speed == SLOW
				   	}
				}
			}
	   
			break;

	   	case WORD_OUTPUT:	 // controling the cards via the control register
		   	if ( port == DRIVER_PORT_A )
			{	// uses the upper word bits as indicators for slots
			    // the lower word as data for the slot control register0
				
				for (index = 0 ;index < DEV_CNT ;index++ )
				{
					if ((outdata &  (0x100 << index)) && slot_ctx[index] != NULL)
					{
				  		dprintf("Setting DFPIO slot %d Control register with 0x%x \n", index, outdata &0xff);
						slot_ctx[index]->HWregs->CtrlStat.Ctrl_Stat_byte = (outdata & 0xff); // DFP Enable					}
					}
				}
			}
			break;

		case WORD_INPUT: 
			if ( port == DRIVER_PORT_A )
			{
				dprintf("Resetting all DFPIO slots and attached DR cards at once \n");
				for (index = 0 ;index < DEV_CNT ;index++ )
				{
					if ( slot_ctx[index] != NULL)
					{
					   	slot_ctx[index]->V_data.CtrlStat.byte_dat = 0;
						slot_ctx[index]->V_data.ctr_dir = 0;
						slot_ctx[index]->V_data.vpp_rng_100mv = 0;
					   
											
						slot_ctx[index]->HWregs->CtrlStat.Ctrl_Stat_byte  = 0x20; 	// enable DFP
						slot_ctx[index]->HWregs->GA_Inst.words.Instr  = 1; 			// clear relays
						slot_ctx[index]->HWregs->PortABC_Ctl.words.AB_AUX_ctrl = 0xff33;   //commanding the Direct relaus open and AB as inputs
						slot_ctx[index]->HWregs->CtrlStat.Reset_byte = SW_RESET_BIT | 0x10;
						slot_ctx[index]->HWregs->JT_IO.bytes.ctrl_byte = 0;
					}
			 	}
				index = 0;	// reset index so it this call can be used to setup for getting the driver name 

			}
			break;

		case BYTE_INPUT:
	   		if ( port == DRIVER_PORT_A )
			{	
			
				dprintf("DFPio:Getting slot instances \n");

				for( index = 0; index < DEV_CNT; index++)
				{
					if (slot_ctx[index] != NULL)
						devices |= (1 << index);
				}
				dprintf("Devices = 0x%x \n", devices);
				index = 0;  // reset index so it this call can be used to setup for getting the driver name 				return(devices);
				return( devices);
											  
			}
		   	
			if ( port == DRIVER_PORT_B )   // get device driver name, releas on a reset above to start at 0 
			{
				dprintf("DFPio:Reading device driver name \n");
				if (index > strlen(DFPIO_DEVNAME))
					index = 0;
				return ( (char) DFPIO_DEVNAME[index++]); 
			}
			break;
	
		default:
			dprintf("DFPIO: DEVICE Porthandler got called with unsupported io_type\n");
			break;
				  	
	}
	return(0);
}

///////////////////////////////////  eeprom stuff   //////////////

 // EEPROM constant 
#define EE_ADDR_MASK 0x003f // for combining addresses with instructions  (WORD addresses)
#define EE_CMD_LEN 9 // bits in instructions 
#define EE_READ 0x0180 // 01 1000 0000 read instruction 
#define EE_WRITE 0x0140 // 01 0100 0000 write instruction 
#define EE_WREN 0x0130 // 01 0011 0000 write enable instruction 
#define EE_WDS 0x0100 // 01 0000 0000 write disable instruction 
#define EE_PREN 0x0130 // 01 0011 0000 protect enable instruction 
#define EE_PRCLEAR 0x0177 // 01 1111 1111 clear protect register instr
// EEPROM Functions 
		  
 
void
WriteRtrDword(WORD IoBase, UINT EpromConReg, DWORD regval)
{
   _outpd( IoBase+ EpromConReg, regval );
}

DWORD
ReadRtrDword(WORD IoBase, UINT EpromConReg )
{  
	return ( _inpd (IoBase+ EpromConReg) );
}	


///////////////////////////////////////////////////////////////////////////// 
static WORD 
EepromReadWord(WORD IoBase, UINT EpromConReg, UINT EpromAddr) 	// (Word addresses)
{ // Return a word from National Semiconductor's NMC93S06/NMC93S46 EEPROM 
	WORD acc = 0x0; 
	UINT i; 
	EepromSendCmd(IoBase, EE_READ | (EpromAddr & EE_ADDR_MASK), EpromConReg); 
	for ( i = 0; i < 16; i++ )
	{ // Get word from EEPROM - one bit at a time 
		acc <<= 1; 
		EepromClock(IoBase, EpromConReg); 
		if ( ReadRtrDword(IoBase, EpromConReg) & 0x08000000 ) 
		   acc |= 0x0001; 
	} 
	return acc; 
}
////////////////////////////////////////////////////////////////////////// 
static BOOL 
EepromWriteWord(WORD IoBase,UINT EpromConReg, UINT EpromAddr, WORD val)  // (WORD addresses )  
{ // Write a word to National Semiconductor's NMC93S06/NMC93S46 EEPROM 
	UINT i; 
	DWORD regval; 
	EepromSendCmd(IoBase, EE_WREN, EpromConReg); // Write enable 
	EepromSendCmd(IoBase, EE_WRITE | (EpromAddr & EE_ADDR_MASK), EpromConReg); 
	regval = ReadRtrDword(IoBase, EpromConReg) & ~0x04000000; // Pre-clear data bit 
	for( i = 16; i ; i-- )
	{ // Write word to EEPROM - one bit at a time 
		WriteRtrDword(IoBase,EpromConReg, regval|((val & 0x8000)? 0x04000000: 0x0)); 
		EepromClock(IoBase, EpromConReg); 
		val <<= 1; 
	} 
	// Activate chip's status mechanism: deselect and reselect 
	WriteRtrDword(IoBase,EpromConReg, regval & ~0x02000000); // Deselect 
	WriteRtrDword(IoBase,EpromConReg, regval); // Reselect 
	// Poll chip status until write-cycle completes (or times out) 
	// (Timeout counter is uncalibrated and somewhat arbitrary!) 
	for( i = 8000; !(ReadRtrDword(IoBase,EpromConReg) & 0x08000000); i-- )
	{ 
		if ( i ) 
			continue; 
		// Timeout! 
		dprintf("EepromWriteWord(): Busy timeout EEPROM addr:0x%2.2x\n", 
			EpromAddr); 
		return FALSE; 
	} 
	EepromSendCmd(IoBase,EE_WDS, EpromConReg); // Write disable 
	return TRUE; 
}
///////////////////////////////////////////////////////////////////////////// 
static BOOL 
EepromSendCmd(WORD IoBase, UINT cmd, UINT EpromConReg) 
{ // Send a command to National Semiconductor's NMC93S06/NMC93S46 EEPROM 
	UINT i; 
	DWORD regval; 
	regval = ReadRtrDword(IoBase,EpromConReg); 
	regval |= 0x02000000; // Chip select TRUE 
	regval &= ~0x05000000; // Clear instruction and clock bits 
	// Toggle EEPROM's chip select (to get it out of Shift Register Mode) 
	WriteRtrDword(IoBase, EpromConReg, regval & ~0x02000000); // Chip select FALSE 
	WriteRtrDword(IoBase, EpromConReg, regval); 
	for ( i = 0; i < EE_CMD_LEN; i++ )
	{ // Send instruction - one bit at a time 
		regval &= ~0x04000000; // Pre-clear the instruction bit 
		// Set up one instruction bit 
		regval |= (cmd & (0x01 << (EE_CMD_LEN-1)))? 0x04000000: 0x00000000; 
		WriteRtrDword (IoBase, EpromConReg, regval); 
		EepromClock(IoBase, EpromConReg); 
		cmd <<= 1; // Align next instruction bit 
	} 
	return TRUE; 
}
///////////////////////////////////////////////////////////////////////////// 
static BOOL 
EepromClock(WORD IoBase, UINT EpromConReg) 
{ // Send clocking sequence to Nat Sem's NMC93S06/NMC93S46 EEPROM 
	DWORD regval; 
	regval = ReadRtrDword(IoBase, EpromConReg); 
	WriteRtrDword(IoBase, EpromConReg, regval & ~0x01000000); // Clock low 
	WriteRtrDword(IoBase, EpromConReg, regval | 0x01000000); // Clock high 
	return TRUE; 
}
