/* File: tmr.c
 * $Revision: 1.1 $
 * Gary Stofer
 * PIXI Timer functions for timed delay
 * Miscellaneous support functions for Setup()
 */

#include "prismapi.h"    /* for communications buffer definition */
#include "ahc_bnds.h"   /* for parameter bounds */
#include "pixi_reg.h"   /* for PIXI register definitions */
#include "setup.h"      /* for SETUP structure definition */
#include "tmr.h"        /* for timer definitions */
#include "util.h"       /* for MAX() */
#include "wavtable.h"   /* for cont_stims */
#include "int3.h"       /* for timer ISR interface definitions */

#include "pixi_glo.e"
 /*> start timer #0 running and return immediately */
void   /* time in 10 us units */
TMR0start ( unsigned int t   )
{
    *TMR0cntrl = TMR_MODE;              /* stop the timer */
    *TMR0prd = t;                       /* external TCLK period = t * 10us */

    TINT0done = 0;      /* reset the ISR flag */
    asm (" OR 0100h, IE; Enable CPU TINT0");

    *TMR0cntrl = TMR_MODE | TMR_GO;     /* start the timer */
}

void 
TMR0Stop ( void )
{
    *TMR0cntrl = TMR_MODE;              /* stop the timer */
    TINT0done = 1;                      /* reset the ISR flag */
}

/*> start timer #0 running and wait ; time in 10 us units */
void
TMR0delay  ( unsigned int t )
{
    *TMR0cntrl = TMR_MODE;              /* stop the timer */
    *TMR0prd = t;       /* external TCLK period = t * 10us */

    TINT0done = 0;      /* reset the ISR flag */
    asm (" OR 0100h, IE; Enable CPU TINT0");

    *TMR0cntrl = TMR_MODE | TMR_GO;     /* start the timer */
    while (!TINT0done)
        /* wait */;
    *TMR0cntrl = TMR_MODE;
}


void TMR0wait(void)     /*> wait if timer was already started */
{
    asm (" OR 0100h, IE; Enable CPU TINT0");
    while (!TINT0done)
        ;
    *TMR0cntrl = TMR_MODE;
}

/*> start timer #1 running and return immediately */
void
TMR1start  ( unsigned int t )
{
    *TMR1cntrl = TMR_MODE;              /* stop the timer */
    *TMR1prd = t;
    *TMR1cntrl = TMR_MODE | TMR_GO;     /* start the timer */
}


/******************************************************************
 * Miscellaneous support functions and data strucures for Setup() :
 */




/*> sets stim1 freq so that DUT Z >= 1ohm */
/* given the min Capacitance */
/* and period of the AC test frequency */
/* and sets stim freq + squelch & measure types */

float
CtoFcapscan( float Cprog,int ACprd, SETUP *su )
{
    float sv, Xc;      /* C reactance */

    su->s1.prd = (ACprd==AHC_DEFAULT) ? AHC_AC1250Hz : ACprd;

    Xc = su->s1.prd / (2*PI*AHC_SF*Cprog);

    if(ACprd==AHC_DEFAULT) /* pick highest stim freq so that Xc>1.0 */
    {
        if(Xc < 1.0)
        {
            su->s1.prd = AHC_AC16Hz;
            Xc = su->s1.prd / (2*PI*AHC_SF*Cprog);
        }

        if(Xc < 1.0)
        {
            su->s1.prd = AHC_AC166Hz;
            Xc = su->s1.prd / (2*PI*AHC_SF*Cprog);
        }
    }

    su->s0.prd = su->s1.prd;

    if (Cprog > 9.5e-3)
        g_err = AER_CAP_TOO_BIG;
    else if (Xc < 1.0)
        g_err = AER_AC_CAP_FREQ_TOO_HIGH;
    else if (su->s1.prd > AHC_AC166Hz)
        g_err = AER_AC_CAP_FREQ_TOO_LOW;

    return AHC_LC_STIM_V;
}

/*> determines number of samples to take for an AC waveform */
/* AC period in number of 10us samples */
/* Sampling parameter value (#cycles to sample) */

int    /* returns number of samples */
ACsamples ( int acprd, int Sampling )
{
    int nc, ns;        /* number of ac cycles, samples */

    if(!acprd) /* should not happen, would be infinite loop */
    {
        g_err = AER_INVALID_SAMPLES;
        return 0;
    }

    /* return a minimum of 80 samples in the case of AC */
    for (nc = 1, ns = acprd; ns < 80; nc++, ns += acprd);

    if ((Sampling -= nc) > 0)
        ns += acprd * Sampling;

    return ns;
}



int     /* returns PIXI Volt Meter scale register value */
TVscale (float MeasV)  /*> given the max measurement voltage at scale amp input */
{
    MeasV = fabs (MeasV);

    return  (MeasV <  0.29) ? PX_300MV :
    (MeasV <  2.9) ? PX_3V :
    (MeasV < 29.0) ? PX_30V : PX_100V;
}


float   /* return multiplier for PX_ADC_VOLTS() reading */
ScaleMult (int vmscale)  /*> based on the VoltMeter scale */
{
    return  (vmscale == 0        ) ?   0.0 :
    (vmscale == PX_300MV ) ?   0.1 :
    (vmscale == PX_3V    ) ?   1.0 :
    (vmscale == PX_30V   ) ?  10.0 :
    (vmscale == PX_100V  ) ? 100.0 : 0.0;
}



