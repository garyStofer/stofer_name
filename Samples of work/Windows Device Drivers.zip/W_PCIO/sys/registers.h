// This file contains the register definitions for the PCIO card. It contains the same defines as the 
// VXD driver already exposed through it files to the rest of the OS. 

// offsets for PCI - Pcio internal registers  (Char * address ) 

#define	PCIO_INT_SEL_C		0x100*2	/* PC I/O (write) interrupt select latch */
#define	PCIO_CONFIG_C		0x100*2	/* PC I/O (read) configuration latch */
#define	PCIO_INT_READ_C		0x101*2	/* PC I/O (read) interrupt latch */
#define PCIO_STRB_CTRL_C	0x101*2
#define	TMR_BASE_LSW_C		0x104*2	// Low  word for tmr1
#define	TMR_BASE_MSW_C		0x107*2	// upper word for tmr1
#define TMR_BASE_CTRL_C		0x10a*2 // RESET, RUN
#define TMR1_CTRL_C			0x10a*2   
#define TMR2_CTRL_C			0x10b*2  
#define TMR3_CTRL_C		    0x10c*2  
#define PCIO_RESET_C		0x111*2  // reset the THC and everything on thye pci io card

// The same as above but for use with short * as in:  USHORT * io_map[PCIO_RESET]
#define	PCIO_INT_SEL	0x100	/* PC I/O (write) interrupt select latch */
#define	PCIO_CONFIG		0x100	/* PC I/O (read) configuration latch */
#define	PCIO_INT_READ	0x101	/* PC I/O (read) interrupt latch */
#define PCIO_STRB_CTRL  0x101
#define	TMR_BASE_LSW	0x104	// Low  word for tmr1
#define	TMR_BASE_MSW	0x107	// upper word for tmr1
#define TMR_BASE_CTRL   0x10a	// RESET, RUN
#define PCIO_RESET		0x111  // reset the THC and everything on thye pci io card

// Index defines for timer LSW, MSW and CTRL_BASE
#define TMR1			0
#define TMR2			1
#define TMR3			2
#define TMR1_CTRL      TMR_CTRL_BASE + TMR1   
#define TMR2_CTRL      TMR_CTRL_BASE + TMR2 
#define TMR3_CTRL      TMR_CTRL_BASE + TMR3

// these two go along with TMRn_CTRL
#define TMR_CTRL_RESET  0x1    // Resets Counter (stops counting, removes interrupt
#define TMR_CTRL_RUN    0x2    // Starts counter 


// for reg PCIO_INT_SEL
#define CABLE_INT_EN	0x80
#define ALL_INT_DIS		0x10    /* Disables interrupts and forces IRQ low */
#define DS_HS_ENABL		0x08
#define DIAG_ADDR_TST   0x20
#define DIAG_CH_BSY_TST 0x40

// FOR PCIO_INT_READ
#define INT_TMR_BITS 0x7
#define INT_Tmr1	0x1
#define INT_Tmr2	0x2
#define INT_Tmr3	0x4
#define INT_2us		0x08
#define INT_Dig		0x10
#define INT_Ana		0x20
#define INT_Ext		0x40

/* PCIO_RESET output port data definitions */
#define RST_IO		1	/* bit #0 = 1 resets the I/O board */
#define RST_CABL	2	/* bit #1 = 1 resets the VP board */
#define RST_ALL		0xff


// defines for PCIO_STRB_CTRL 
#define A_STRB		0x40
#define D_STRB		0x00	
