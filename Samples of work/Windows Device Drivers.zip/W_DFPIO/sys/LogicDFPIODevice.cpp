// NT_DFPIODevice.cpp
// Implementation of LogicDFPIODevice device class
//
// Requires Compuware's DriverWorks classes DriverStudio 2.6.0 (Build 336)
// Author: Gary Stofer , April 2003  
//

#include <vdw.h>
#include "LogicDFPIODevice.h"
#include "Wdfpio.h"
#include "WdfpioDevice.h"
#include "../../../include/Wdfpioioctl.h"

#pragma hdrstop("Wdfpio.pch")


#pragma warning(disable:4065) // Allow switch statement with no cases
#pragma warning(disable:4800) // Cast to bool
extern	KDebugOnlyTrace	t;


////////////////////////////////////////////////////////////////////////
// LogicDFPIODevice::~LogicDFPIODevice
//
//	Routine Description:
//		This is the destructor for the LogicDFPIODevice
//
//	Parameters:
//		None
//
//	Return Value:
//		None
//
//	Comments:
//		Disconnect and release resources here.
//
//		Although the use of SAFE_DESTRUCTORS in the class definition cures
//		improper emission of the destructor into the INIT section most of the
//		time, certain rare cases can still cause improper behavior.  To avoid
//		these cases, the destructor	must preceed the INIT section, causing it
//		to be referenced first by the default compiler section.
//

LogicDFPIODevice::~LogicDFPIODevice()
{
	t << "Logical device Destructed\n";
}


////////////////////////////////////////////////////////////////////////////////
//  LogicDFPIODevice::LogicDFPIODevice
//
//	Routine Description:
//		The device constructor is typically responsible for allocating
//		any physical resources that are associated with the device.
//
//	Parameters:
//		Unit - Unit number. This is a number to append to the device's
//			base device name to distinguish multiple units of this
//			device type.
//
//	Return Value:
//		None
//
//	Comments:
//		The device constructor often reads the registry to setup
//		various configurable parameters.

LogicDFPIODevice::LogicDFPIODevice( KDriver * parent) :	KDevice()
{
	if ( ! NT_SUCCESS(m_ConstructorStatus) )
	{
		t << "Failed to create device LogicDFPIODevice status:" << (ULONG) m_ConstructorStatus << EOL;
		return;
	}
	pDriver = (Wdfpio *) parent;
	t<< "Logical DFPIO device  contstructed \n";

}




////////////////////////////////////////////////////////////////////////
//  LogicDFPIODevice::DeviceControl
//
//	Routine Description:
//		Handler for IRP_MJ_DEVICE_CONTROL
//
//	Parameters:
//		I - Current IRP
// 
//	Return Value:
//		NTSTATUS - Result code
//
//	Comments:
//		This routine is the first handler for Device Control requests.
//
//		Some function codes may be handled immediately, 
//		while others may be serialized.
//		

NTSTATUS LogicDFPIODevice::DeviceControl(KIrp I) 
{
	NTSTATUS status = STATUS_INVALID_PARAMETER;

	t << "Entering LogicDFPIODevice::Device Control, " << I;

	switch (I.IoctlCode())
	{
		case IOCTL_WDFP_GET_MMAP:
			status = IOCTL_WDFP_GET_MMAP_Handler(I);
			break;

		case IOCTL_WDFP_CTRL:	  
			status = IOCTL_WDFP_CTRL_Handler(I);
			break;

		case IOCTL_WDFP_RD_WAIT:
		    status = IOCTL_WDFP_RD_WAIT_Handler(I);
			break;
		default:
			// Unrecognized IOCTL request
			break;
	}

	if (status == STATUS_PENDING)
		return status;
	else
		return I.Complete(status);


}


NTSTATUS LogicDFPIODevice::CleanUp(KIrp I)
{
	t << "Entering LogicDFPIODevice CleanUp, " << I;
	I.Information() = 0;

	for (int i = 0; i < DEV_CNT; i++ )
	{
		if (pDriver->m_DevMap[i].pDevice != NULL) 
		{
			pDriver->m_DevMap[i].pDevice->UnMapHwToProcess() ;
		}
	}

	return I.Complete(STATUS_SUCCESS);
}


////////////////////////////////////////////////////////////////////////
//  LogicDFPIODevice::Create
//
//	Routine Description:
//		Handler for IRP_MJ_CREATE
//
//	Parameters:
//		I - Current IRP
//
//	Return Value:
//		NTSTATUS - Result code
//
//	Comments:
//

NTSTATUS LogicDFPIODevice::Create(KIrp I)
{
	NTSTATUS status = STATUS_SUCCESS;

	t << "Entering LogicDFPIODevice Create, " << I;

	// Only one Process can get the HW -- This is enforced by DO_EXCLUSIVE, ;
	// Map all the devices memory map through to the calling process
	for (int i=0; i < DEV_CNT; i++ )
	{
		if (pDriver->m_DevMap[i].pDevice != NULL) 
		{
			if ( pDriver->m_DevMap[i].pDevice->MapHwToProcess() != STATUS_SUCCESS )
				status = STATUS_INVALID_DISPOSITION;
		}
	}
	     
 
	I.Information() = 0;
	return I.Complete(status);
}

////////////////////////////////////////////////////////////////////////
//  LogicDFPIODevice::Close
//
//	Routine Description:
//		Handler for IRP_MJ_CLOSE
//
//	Parameters:
//		I - Current IRP
//
//	Return Value:
//		NTSTATUS - Result code
//
//	Comments:
//

NTSTATUS LogicDFPIODevice::Close(KIrp I)
{
	t << "Entering LogicDFPIODevice Close, " << I;

	I.Information() = 0;
	return I.Complete(STATUS_SUCCESS);
}


   ////////////////////////////////////////////////////////////////////////
//  LogicDFPIODevice::IOCTL_WDFP_GET_MMAP_Handler
//
//	Routine Description:
//		Handler for IO Control Code IOCTL_WDFP_GET_MMAP
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//		This routine implements the IOCTL_WDFP_GET_MMAP function.
//		This routine runs at passive level.
//

NTSTATUS LogicDFPIODevice::IOCTL_WDFP_GET_MMAP_Handler(KIrp I)
{
	int  	slot;
	PVOID   user_address = NULL;
	WDFP_GET_MMAP * ioCtrl; 
	
	I.Information() = 0;

	if (I.IoctlInputBufferSize() <  sizeof(WDFP_GET_MMAP ) ||
		I.IoctlOutputBufferSize() <  sizeof(WDFP_GET_MMAP ))
	{	
	    t << "in Get Hw io buffers too small \n ";
		return STATUS_BUFFER_TOO_SMALL;
	}

    ioCtrl  = (WDFP_GET_MMAP *) I.IoctlBuffer();
	slot  =  ioCtrl->SlotIndex;
	
	if (slot < 0 || slot >= DEV_CNT ||  pDriver->m_DevMap[slot].pDevice == NULL)
	{
		t << "Invalid Slot requested \n";
		return STATUS_INVALID_DISPOSITION;
	}

 	user_address =  pDriver->m_DevMap[slot].pDevice->GetProcAddr(); 	

	I.Information() = sizeof( WDFP_GET_MMAP);	// copy everything back
	t << "Get mem map adress for slot " << (USHORT) slot  << " returned " << ( ULONG) user_address  << EOL;
	ioCtrl->BaseAddr =  user_address;

	return STATUS_SUCCESS;
}



NTSTATUS LogicDFPIODevice::IOCTL_WDFP_RD_WAIT_Handler(KIrp I)
{
	int	slot;
	WDFP_RD_WAIT * ioCtrl; 
	
	I.Information() = 0;	// nothing to return 

	if (I.IoctlInputBufferSize() <  sizeof(WDFP_RD_WAIT ) )
	{	
		t << "IOCTL_WDFP_RD_WAIT io buffers too small \n ";
		return STATUS_BUFFER_TOO_SMALL;
	}
    
    ioCtrl  = (WDFP_RD_WAIT *) I.IoctlBuffer();
	slot  = ioCtrl->SlotIndex;

	if (slot < 0 || slot >= DEV_CNT ||  pDriver->m_DevMap[slot].pDevice == NULL)
	{
		t << "Invalid Slot requested \n";
		return STATUS_INVALID_DISPOSITION;
	}

	pDriver->m_DevMap[slot].pDevice->SetReadWait(ioCtrl->WaitStates); 	

	return STATUS_SUCCESS;
}





NTSTATUS LogicDFPIODevice::IOCTL_WDFP_CTRL_Handler(KIrp I)
{
	int 	slot;
	WDFP_CTRL * ioCtrl; 
	NTSTATUS status = STATUS_SUCCESS;

	
	I.Information() = 0;	// nothing to return

	if (I.IoctlInputBufferSize() <  sizeof(WDFP_CTRL ) )
	{	
	    t << "IOCTL_WDFP_CTRL io buffers too small \n ";
		return STATUS_BUFFER_TOO_SMALL ;
	}

    ioCtrl  = (WDFP_CTRL *) I.IoctlBuffer();
	slot  = ioCtrl->SlotIndex;

	if (slot < 0 || slot >= DEV_CNT ||  pDriver->m_DevMap[slot].pDevice == NULL)
	{
		t << "Invalid Slot requested \n";
		return STATUS_INVALID_DISPOSITION;
	}

  	pDriver->m_DevMap[slot].pDevice->SetControl( ioCtrl->mode , ioCtrl->Set_clr );
	return STATUS_SUCCESS;
}



