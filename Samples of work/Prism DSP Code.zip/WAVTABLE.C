/* File: WAVTABLE.C source module of DSP executable file PIXI.X30
 * $Revision: 1.1 $
  * Gary Stofer

 * sine wave table synthesis algorithm
 * Teradyne ATWC Sherlock project, Analog Hardware Control subproject
 * NOTE: do not use optimize flag -o on this file
 * functions in this file:
 * MOVE TO ON CHIP    move isr code to on-chip ram,
 * ISR LOAD ON CHIP   move isr code to on-chip ram,
 * InitSineTable     fill stim sine table with data
 * StartWaveTable     Get data from PC and init stim AC signals
 * ResetStimPhase     for AC signals, resync table index to initial
 * DVDTmeas           return measured DVDT estimated via linear least squares
 * BridgeVmeas        Bridge measurement, do n cycle peak measurement
 * Vmeas              core measure routine, for most test types, DC and AC
 * vmeas              innermost measure loop, waits on interrupt, non-dma
 * VmeasDmaDigFil     Vmeas using DMA for ADC reading, with LP digital filter
 */

#undef _DEBUG           /* force small version of pixi_reg.h regout macro */
#include <math.h>       /* for sqrt() and HUGE_VAL */
#include <string.h>     /* for NULL */
#include <bus30.h>      /* for on-chip misc register definitions */
#include <dma30.h>      /* for on-chip DMA register defintions */
#include "prismapi.h"    /* for communications buffer definition */
#include "ahc_bnds.h"   /* for LINEREJ_O_THRESH */
#include "pixi_reg.h"   /* for PIXI register definitions */
#include "setup.h"      /* for SETUP structure definition */
#include "tmr.h"        /* for timer definitions */
#include "util.h"       /* for MAX() */
#define WAVTABLE_VARS 1 /* control allocation of variables in file wavtable.h */
#include "wavtable.h"   /* for wave table definitions */
#undef WAVTABLE_VARS
#include "execute.h"    /* for wave table definitions */


#include "pixi_glo.e"

/*****************************************************************************
 *>MOVE TO ON CHIP  move isr code to on-chip ram,
 * using section 'on_chip' defined in .cmd file
 * see pg. 8-30 in assem manual for example
 */

void
MoveToOnChip(unsigned int *cstart, unsigned int *cend, unsigned int *cdest)
{
    unsigned int *start_, *end_, *dest_;

    start_ = cstart;        /* address of code block to be moved */
    end_ = cend;            /* end address of code block to be moved */
    dest_ = cdest;          /* address of on-chip ram block destination */

    while(start_ <= end_) /* move function code block */
        *dest_++ = *start_++;
}


/***************************************************************************
 *>ISR LOAD ON CHIP  move isr code to on-chip ram,
 * using section 'on_chip' defined in .cmd file
 * see pg. 8-30 in assem manual for example
 * also init values of some global local and external variables
 * called only once on power-up from Main()
 */
void
ISRLoadOnChip(void)
{
    intptr = &int01_ptr;  /* isr vector address */

    /* init addresses of on-chip variables used by ISR
  * assign local pointer variables that point to the on-chip isr variables    
  * done this way to avoid going to large memory model (slower)    
  * use: int *loc_var, then loc_var=&isr_var, then *loc_var=(int)&other_var    
  * result is isr_var address contains other_var address outside of DP range    
  * NOTE: must be int if pointer, else compiler does float conversion on ptr.    
  */    


    Dac0Ctrl = (void *) &isr_dac0tblp;
    Dac1Ctrl = (void *) &isr_dac1tblp;

    /* init values of on-chip variables used by ISR
   */    
    Dac0Ctrl->table = Dac1Ctrl->table = wav_tabl_A;
    Dac0Ctrl->offs = Dac1Ctrl->offs = DACOFFSf;/* dac offset, + int roundoff */
    Dac0Ctrl->delta = Dac1Ctrl->delta = 0; 


    {
        extern unsigned int         /* reference global asm symbols */
        reloc1_start, reloc1_end, on_chip_code1, /* code to be relocated begin and end src addr */
        reloc2_start, reloc2_end, on_chip_code2; /* code to be relocated begin and end src addr */


        MoveToOnChip(&reloc1_start, &reloc1_end, (unsigned int *)BridgeVmeas);

        /* move asm isr functions */
        MoveToOnChip(&reloc2_start, &reloc2_end, &on_chip_code2);

    }
}


/*************************************************************************
 *> InitSineTable0  fill stim0 sine table with data
 *  called from StartWaveTable once per swSetup() only if AC signals on

 */
// This function should not be called while stims are on.. It modifies the 
// asm vars loc_...
void
InitSineTable( STIM  *st, struct IsrDacCtrl *DacCtrl, float phase_trim)
{
    float   *w_tabl;
    register int i;
    register float xf, yf, sf;

    *intptr = (unsigned int) &int01_scaled;

    switch (st->func)
    {
        case ST_DC_SLOW:
            w_tabl = (DacCtrl == Dac0Ctrl) ? wav_tabl_0 : wav_tabl_1;
            // use sine slope to turn DC on
            xf = 0.174532;  // 10Deg in radians for 2.77Khz sine ramp
            yf = 0.0;
            for (i = 0 ;i < 9 ;i++ )    // 0 to 90 deg
            {
                w_tabl[i] =  sin(yf) * PX_DAC_10V_BITS;
                yf+=xf;
            }
            w_tabl[i] = PX_DAC_10V_BITS ;
            DacCtrl->index  = 0;
            DacCtrl->lenght = 9; 
            DacCtrl->reload = 9;    // hold at max voltage     
            DacCtrl->delta = 1;
            DacCtrl->offs = DACOFFSf;
            DacCtrl->scale = st->dac_v;
            DacCtrl->up = 1;
            break;

        case ST_DC:
            w_tabl = (DacCtrl == Dac0Ctrl) ? wav_tabl_0 : wav_tabl_1;
            w_tabl[0] = 0.0;
            w_tabl[1] = PX_DAC_10V_BITS;
            DacCtrl->lenght = 2;  
            DacCtrl->reload = 1;
            DacCtrl->delta  = 1;
            DacCtrl->index   = 0;
            DacCtrl->offs = DACOFFSf;
            DacCtrl->scale = st->dac_v;
            DacCtrl->up = 1;
            break;

        case ST_SINE:
            DacCtrl->reload = 0;
            DacCtrl->index = 0;  
            DacCtrl->offs = DACOFFSf - st->dcoffs; 
            DacCtrl->scale = st->dac_v;
            DacCtrl->up = 1;

            // figure out when to use the precomputed wavetables
            // only fundamental and no reminder, and no phase_trim 
            if (st->cyc == 1 &&  phase_trim == 0.0 && AHC_AC12Hz % st->len == 0 )
            {
                w_tabl = wav_tabl_A;        // Pre comp 8000pt
                DacCtrl->lenght = AHC_AC12Hz;
                DacCtrl->delta = AHC_AC12Hz / st->len;
            }
            else if (st->cyc == 1 &&  phase_trim == 0.0 && AHC_AC16Hz % st->len == 0 )
            {
                w_tabl = wav_tabl_B;        // Pre comp 6000pt
                DacCtrl->lenght = AHC_AC16Hz;
                DacCtrl->delta = AHC_AC16Hz / st->len;
            }
            else    // create the waveform on the fly
            {
                w_tabl = (DacCtrl == Dac0Ctrl) ? wav_tabl_0 : wav_tabl_1;
                DacCtrl->lenght = st->len;
                DacCtrl->delta = 1;

                yf = -phase_trim;
                xf = PI2 / st->prd;

                // make the wave table
                for(i=0; i < DacCtrl->lenght; i++)
                {
                    w_tabl[i] =  PX_DAC_10V_BITS * sin(yf);
                    yf+=xf;
                }
            }
            break;

        default:                // NO STIM -- Zero Volts
            w_tabl = (DacCtrl == Dac0Ctrl) ? wav_tabl_0 : wav_tabl_1;
            w_tabl[0] = 0.0;            // 0.0 V
            DacCtrl->table = w_tabl;   // the address of dac data table
            DacCtrl->index = 0;        // The starting indx in the table
            DacCtrl->lenght = 1;       // the lenght of a periode
            DacCtrl->delta = 0;        // the step size trough data (0 for no stim)
            DacCtrl->reload = 0;       // the reload point after 1 per
            DacCtrl->offs = DACOFFSf;
            DacCtrl->scale = 1.0;
            DacCtrl->up =1;  
            break;
    }

    DacCtrl->table = w_tabl;
}




/*************************************************************************
 * StartWaveTable  Get data from PC and init stim AC signals */
void
StartWaveTable( SETUP  *su )    /* setup buffer ptr */
{

    if (su->MeasAlg == SU_CHARGE)   /* no AC stim */
    {
        STIM_ISR_NOP(); /* set dummy isr function, no AC signal */
        return; // DC caps don't use vmeas, Stim is dealt with in DVDTmeas()
    }

// should wait here for stim terminating at 0V if DacxCtrl->up is set to off
    STIM_ISR_OFF();     // Make sure stims are not running while modifying stim vars

    // always call both stims so that inactive stim gets set to DC 0V
    InitSineTable(&su->s0, Dac0Ctrl, 0.0);             /* prepare wave table */
    InitSineTable(&su->s1, Dac1Ctrl, 0.0);
}


/*************************************************************************
 *> ResetStimPhase  for AC signals, resync table index to initial table index
 */
void
ResetStimPhase(SETUP *su)
{

    if ( su->s0.func == ST_SINE ) 
        Dac0Ctrl->index = 0;

    if ( su->s1.func == ST_SINE )
        Dac1Ctrl->index = 0;
}


/***************************************************************************
 *> DVDTmeas    return measured DVDT estimated via linear least squares
 */
float
DVDTmeas ( SETUP *su  /* setup buffer ptr */ )
{
    int prevctr;
    float measv, dvdt, dvdtavg, mtime;
    register int  *isample = adc_tabl; // integer ADC values
    register float *vsample = fil_tabl;// float voltage values
    int fn;

    float sumxf;                /* accum sum(time*volts) */
    float sumx2;                /* accum sum(time^2) */
    float sumx;                 /* accum sum(time) */
    float sumf;                 /* accum sum(volts) */
    float sumfsumx;             /* accum sum(time)*sum(volts) */
    float Dac0v1;
    float stime = PIXI_CLK_PER;
    float stime2= PIXI_CLK_PER*PIXI_CLK_PER;
    float scale_gain;


    // ADC bit weight times scale multiplier
    scale_gain = PX_ADC_3V_MULT * ADC_RNG(HW->MeasRange1.dat);

    asm(" AND  @IE_alloff, IE");// turn off all interrupts (internal & external 
    asm(" OR   0008h, IE");     // reEnable INT3 to respond to cancel INT

    mtime = dvdtavg = measv = 0.0;
    minV=99999.9; /* init to large # for correct comparison */
    maxV=-minV;

    sumx = sumx2 = sumf = sumxf = 0.0;
    fn = 0;
    /* set up DMA control so reads from ADC and writes to memory array
     * inc write dest addr, read ADC on irq    
     */    
    DMA_ADDR->_gctrl._intval = INCDST | SYNC1 | TC;
    DMA_ADDR->source = (unsigned int)(PX_REG_BASE+PX_ADC);
    DMA_ADDR->destination = (unsigned int)(adc_tabl);
    DMA_ADDR->transfer_counter =  prevctr = MAX_ADC_DVDT_DMA;
    DMA_ADDR->_gctrl._intval |= START3;

    HW->Squelch = SW_OFF;
    HW->Listen = SW_ON;

    // enable external ADC busy DMA interrupts
    asm(" AND  03F0h, IF");     // Clear all pending external interrupts
    asm(" OR  @IE_DMA_INT1,IE");    // Enable DMA interrupt     EINT1  (ADC_busyn)

    //  ************************* measure loop start ***********************    
    PX_DAC0_OUT(su->s0.dac_v);
    do
    {
        // wait for new sample, if loop time faster than sample time
        while(prevctr <= DMA_ADDR->transfer_counter)
        ;
        // convert to scaled float value
        // need to shift << then >> to sign extend 16Bit adc value to 32bit int
        measv = *vsample++ = scale_gain *  (( *isample++ <<16)>>16);
        fn++;

        // if vmoa railed then abort compute dvdt from the elapsed time and exit
        if (fabs(measv) > 0.29 )
        {
            dvdt = 0.29 /(fn * 10e-6);    
            goto dvdt_exit;
        }

        mtime += stime;
        sumx += mtime;
        sumx2 += mtime*mtime;
        sumf += measv;
        sumxf += measv * mtime;

        // formula for slope of linear least squares fit to data series
        dvdt = (fn*sumxf - sumf*sumx) / (fn*sumx2 - sumx*sumx);
        dvdt = fabs(dvdt);

        // compute 200pt (2ms) moving average of slope estimate
        dvdtavg = 0.995*dvdtavg + 0.005*dvdt;

        // if dvdt sampled for minimum of 2ms=200 samples,
        // then monitor min/max of dvdt measure        
        if(DMA_ADDR->transfer_counter < (MAX_ADC_DMA-200))
        {
            if(dvdt > maxV)
                maxV = dvdt;
            if(dvdt < minV)
                minV = dvdt;
        }
        // exit after 10ms of sampling if stability of the result is better then 1%
        if (DMA_ADDR->transfer_counter < (MAX_ADC_DVDT_DMA - 1000))
        {
            if(fabs((dvdtavg - dvdt)/ dvdtavg) < 0.01)
                break;
        }
    } while(--prevctr);

dvdt_exit:
    // run the slope down by inverting the stim polarity and wait until Vdiff
    // shows < 1mv . No data is stored doing this, DMA is used since it's already
    // set up.
    DMA_ADDR->_gctrl._intval = SYNC1 | TC ;
    DMA_ADDR->destination = (unsigned int)(adc_tabl);
    DMA_ADDR->transfer_counter =  fn * 1.2;   // allow 1.2 the charge up time for timeout
    DMA_ADDR->_gctrl._intval |= START3;

    PX_DAC0_OUT(-su->s0.dac_v);             // invert slope to discharge
    while( DMA_ADDR->transfer_counter)      // discharge down to 0mv    
    {
        if ( scale_gain *  (( *adc_tabl <<16)>>16) < 0.0)
            break;
    }

    PX_DAC0_OUT(0.0);       // Hold stim at 0 now 
    HW->Squelch = SW_ON;
    asm("     AND   @IE_allDMAoff, IE ");
    DMA_ADDR->_gctrl._intval = 0; /* disable DMA */
    HW->Listen = SW_OFF;

    return dvdt;

} /* end of DVDTmeas routine */



/***************************************************************************
 *>BridgeVmeas  Bridge measurement, do n cycle peak measurement at fixed phase
 *              i.e. take one sample per cycle, remove DC bias
 *              average and return signed value
 */





/* offsi = sample# (<=period) relative to time 0 to start measure
to compensate for filter delay, typically =~3 
measi = sample# (<=period) relative to start of stim0 at which to measure
used to pick phase point at which sampling should occur
ncycles = # cycles to average 
imag = imaginary (cos) component of balance current 
ireal = real (sin) part of balance current 
setup buffer ptr */

// these vars have to be  !!NOT!! on chip since DP is not pointing to Internal Ram Page under C
// Need variables since there is no immediate word size move instruction
asm("IE_DMA_INT0      .word  00010000h ;Enable external DMA EINT0");
asm("IE_DMA_INT1      .word  00020000h ;Enable external DMA EINT1");
asm("IE_CPU_INT0      .word  00000001h ;Enable external CPU EINT0");
asm("IE_CPU_INT1      .word  00000002h ;Enable external CPU EINT1");
asm("IE_CPU_INT2      .word  00000004h ;Enable external CPU EINT2");
asm("IE_CPU_INT3      .word  00000008h ;Enable external CPU EINT3");
asm("IE_CPU_DINT      .word  00000400h ;Enable external CPU EDINT");
asm("IE_alloff    .word  00000000h ");
asm("IE_allDMAoff .word  00000FFFFh ;Disable external DMA ints");
asm("IE_INT0off   .word ~00000001h ;Disable external INT0 ");


/* move isr code to on-chip ram, using section 'on_chip' defined in .cmd file
 * see pg. 8-30 in assem manual for example
 */
asm("  .sect  \".on_chip\"");  /* must match .cmd file label, locates address */
asm("  .global _reloc1_start "); /* pointer to unrelocated address */
asm("  .label _reloc1_start ");

int
BridgeVmeas(int stim_delay, int m_delay, SETUP *su,
         float *av0, float *dc, float *rms, float *S, float *C)
{
    register int  *isample = adc_tabl; // integer ADC values
    register float *vsample = fil_tabl;// float voltage values
    register float scale_gain;
    register int startctr = 0;
    register int phase = 0;
    int stim_prd;
    int use_sin6 = 0;
    int m_delay10us;
    int m_delay30ns;
    float  yf;

    HW->AdcClk = SW_OFF;

    if (( stim_prd = su->s0.prd) == 6)
        use_sin6 = 1;

    m_delay30ns = m_delay % DELAY10us;
    m_delay10us = m_delay / DELAY10us;

    HW->MeasClk.dat =  m_delay30ns ;

    // rough delay in 10us increments 
    // fine delay is done via ADC strobe delay 
    // plus 1 clock for stim DAC register lag
    m_delay10us =  stim_delay * stim_prd + m_delay10us + 1;

    *S = *C = *dc = *av0 = *rms = 0.0;

    // ADC bit weight times scale multiplier
    scale_gain = PX_ADC_3V_MULT * ADC_RNG(HW->MeasRange1.dat);

    // to protect from overfilling the DMA buffer as defined in the link file
    if ( (startctr = su->samples) > 12000 )
    {
        g_err = AER_ADC_DMA_OVERFLOW;
        return g_err;
    }


    /* set up DMA control so reads from ADC and writes to memory array
    * inc write dest addr, read ADC on irq, stop on transfer ctr = 0    
    */    
    asm(" AND  @IE_alloff, IE"); // turn off all interrupts (internal & external 

    // Start Stim(s) at 0 deg.
    Dac0Ctrl->index = 0;
    Dac1Ctrl->index = 0;

    DMA_ADDR->_gctrl._intval = INCDST | SYNC1 | TC;
    DMA_ADDR->source = (unsigned int)(PX_REG_BASE+PX_ADC);
    DMA_ADDR->destination = (unsigned int)(adc_tabl);
    DMA_ADDR->transfer_counter =  startctr;
    DMA_ADDR->_gctrl._intval |= START3;

    asm(" AND 03F0h, IF");  // Clear all pending external interrupts
    asm(" OR  @IE_CPU_INT3, IE");  // reEnable CPU EINT3 to respond to pc i/o
    asm(" OR  @IE_DMA_INT1, IE");  // Enable DMA interrupt     EINT1  (ADC_busy)
    asm(" OR  @IE_CPU_INT0, IE");  // Enable Stim interrrupt   EINT0 

    do   // wait the 10us delays 
       asm("          IDLE           "); 
    while (m_delay10us--);

    // enable  ADC clocks in the next 10us tick, ADC starts sampling DMA picks up
    HW->AdcClk = SW_ON;

    // position the Listen envelope rougly at 0 deg measure phase
    asm("          IDLE           "); 
    HW->Listen = SW_ON;
    // Give DMA a head start so the loop below will run behind DMA data
    asm("          IDLE           "); 

    // measurment data processing
    yf = PI2/stim_prd;
    while(  startctr-- ) 
    {
       // don't let this loop overtake the DMA 
       asm("          IDLE           "); 

        // convert to scaled float value and keep running sum
        // need to shift << then >> to sign extend 16Bit adc value to 32bit int
       *dc += *vsample = scale_gain *  (( *isample++ <<16)>>16);

        *rms += *vsample * *vsample;
        // default Bridge frequency -- use precalculated sine/cos for speed
        if (use_sin6)
        {
            *S += *vsample * g_sin6[phase];
            *C += *vsample * g_cos6[phase];
        }
        else
        {
            *S += *vsample * sin(phase * yf);
            *C += *vsample * cos(phase * yf);
        }

        if (++phase >= stim_prd)
            phase = 0;

        vsample++;

    }
    DMA_ADDR->_gctrl._intval = 0; /* disable DMA */
    HW->Listen = SW_OFF;
    HW->AdcClk = SW_OFF;
    asm("   AND    @IE_allDMAoff, IE; turn off DMA interrupt enable ");
    asm (" OR 0108h, IE; reEnable CPU INT3 (pc i/o), CPU TINT0");
    
    // This is to detect that there was no DMA to adc_tabl due to HW faults
    if ( DMA_ADDR->transfer_counter != 0 )
    {
        g_err = AER_NO_DMA_ADC_CLK;
        return g_err;
    }

    *S /= su->samples;
    *C /= su->samples;
    

    *dc /= su->samples;

    *rms = sqrt(*rms/su->samples) - *dc;

    return 0;

} /* end of BridgeVmeas */


/***************************************************************************
 *>Vmeas  core measure routine, for most test types, DC and AC
 *  The purpose of Vmeas() is to
 *      1. Apply, not apply, or continue to apply the stimulus to the DUT.
 *      2. Delay for a specified Wait time.
 *      3. Measure the DUT voltage (Peak, Pk-Pk, or RMS).
 * polls interrupt flag to check for interrupt done
 * checks setup flag to determine measurement type
 *
 *  The stim/measure loop does the following:
 *      1. if DAC0 is used - output next V sample to DAC0.
 *         if DC is used - output V sample from Dac0v.
 *         if AC is used - output V sample from wave table.
 *      2. if DAC1 is used - output next V sample to DAC1.
 *         if DC is used - output V sample from Dac1v.
 *         if AC is used - output V sample from wave table.
 *      3. if ADC  is used - input next V sample from ADC and
 *         if DC  is used - measV += V
 *         if RMS  is used - measV += V * V
 *         if PEAK or PK-PK is used - if (V > maxV) maxV = V
 *                                      if (V < minV) minV = V
 *         if Vsample != NULL - Vsample[mSn++] = V
 *      4. Sychronize with the main thread of execution
 *
 * Vmeas is ON-CHIP CODE, put asm .sect directive to switch code location
 * c_int10= interrupt # decimal 10, = timer 1 isr
 * c_int01= interrupt # decimal  1, = ADAM 100 khz clk
 *
 * move isr code to on-chip ram, using section 'on_chip' defined in .cmd file
 * see pg. 8-30 in assem manual for example
 */





/***************************************************************************
 *>vmeas  -  innermost measure loop, waits on interrupt, non-dma
 */
int  samples;
float               /* return measured volts */
Vmeas( SETUP *su )  /* setup buffer ptr */
{
	register int adc_offset = g_adc_offset;
    register int  *isample = adc_tabl; // integer ADC values
    register float *vsample = fil_tabl;// float voltage values
    register float scale_gain;
    float measv,measv1, measv2;
    float Vsum;
    float Vsum2;
    int  samples;
    int  fil_settle;
    Type2pDfCoeff *df;
    float sec1, sec1_1=0.0, sec1_2=0.0;
    float sec2, sec2_1=0.0, sec2_2=0.0;
    float sec3, sec3_1=0.0, sec3_2=0.0;

    if ((df = su->DigFil) != NULL )
        fil_settle = su->DigFil->Settle_time;
	else
		fil_settle = 0;

    samples = su->samples + fil_settle;
    // to protect from overfilling the DMA buffer as defined in the link file
    if ( samples > MAX_ADC_DMA )
    {
       // un-init the Dac control since we are not going to start the ISR
       Dac0Ctrl->up=Dac1Ctrl->up=Dac0Ctrl->delta = Dac1Ctrl->delta = 0;
       return(-1);
        
    }

    // ADC bit weight times scale multiplier
    scale_gain = PX_ADC_3V_MULT * ADC_RNG(HW->MeasRange1.dat);
      
    minV=9999e20; /* init to large # for correct comparison */
    maxV=-9999e20;

    Vsum = Vsum2 = measv = measv1 = measv2= 0.0;     
    
//    HW->Listen = SW_ON;       // measurment probe
    TMR0wait();   /* wait for setup reeds to settle */
//    HW->Listen = SW_OFF;
                               // measurment probe
    HW->Squelch = SW_OFF;
    // SQ-ARM off
    // Nothing to do for Z-mode, FD at 0V, or  Vmode SqArm never turned on 
    if ( su->MeasAlg ==SU_YMODE && (HW->RfSelect.dat >= PX_R1M) && HW->SqArm)
    {
        HW->SqArm = SW_OFF;
        TMR0delay(TMR_RELAYS); 
    }

    /* set up DMA control so reads from ADC and writes to memory array
       inc write dest addr, read ADC on irq, stop on transfer ctr = 0    */    
    asm(" AND  @IE_alloff, IE"); // turn off all interrupts (internal & external 
    DMA_ADDR->_gctrl._intval = INCDST | SYNC1 | TC;
    DMA_ADDR->source = (unsigned int)(PX_REG_BASE+PX_ADC);
    DMA_ADDR->destination = (unsigned int)(adc_tabl);
    DMA_ADDR->transfer_counter = samples ;
    DMA_ADDR->_gctrl._intval |= START3;

    asm(" AND 03F0h, IF");  // Clear all pending external interrupts
    asm(" OR  @IE_CPU_INT3, IE");  // reEnable CPU EINT3 to respond to pc i/o
    asm(" OR  @IE_CPU_INT0, IE");  // Enable Stim interrrupt EINT0  (turns stim on)
    
//     HW->Listen = SW_ON;        // measurment probe
    TMR0delay( su->wait);
//    HW->Listen = SW_OFF;
//    HW->Listen = SW_OFF;  // multiple offs so we can see it in the scope
//    HW->Listen = SW_OFF;
//    HW->Listen = SW_OFF;

    // open the quick charge path (100K) impedance
    if (  HW->AcCoupleDsc )
    {
        HW->AcCoupleDsc = 0;
        TMR0delay(TMR_RELAYS);
        
    }

    HW->Listen = SW_ON;
    asm(" OR  @IE_DMA_INT0, IE");  // Enable DMA interrupt     EINT0
    do
    {
        // wait for new sample, if loop time faster than sample time
        while(samples <= DMA_ADDR->transfer_counter)
        ;
        

        // convert to scaled float value
        // need to shift << then >> to sign extend 16Bit adc value to 32bit int
        measv = *vsample++ = scale_gain *  ( (( *isample++ <<16)>>16) - adc_offset );


        if (df)
        {
            /* C digital filter */        
            sec1  = df->sec0.a0*measv +  df->sec0.a1*measv1 + \
            df->sec0.a2*measv2 -  df->sec0.b1*sec1_1 - \
            df->sec0.b2*sec1_2;

            sec2  = df->sec1.a0*sec1  +  df->sec1.a1*sec1_1 + \
            df->sec1.a2*sec1_2 -  df->sec1.b1*sec2_1 - \
            df->sec1.b2*sec2_2;

            sec3  = df->sec2.a0*sec2  +  df->sec2.a1*sec2_1 + \
            df->sec2.a2*sec2_2 -  df->sec2.b1*sec3_1 - \
            df->sec2.b2*sec3_2;

            measv2 = measv1;
            measv1 = measv;

            sec1_2 = sec1_1;
            sec1_1 = sec1;

            sec2_2 = sec2_1;
            sec2_1 = sec2;

            sec3_2 = sec3_1;
            sec3_1 = sec3;

            measv = sec3; /* final filtered value */

            if (fil_settle-- > 0 )  // let the filter settle without taking results
    			continue;

        } 

        if(measv > maxV)
            maxV = measv;

        if(measv < minV)
            minV = measv;

        Vsum2 += measv*measv;  /* accum sum of squares */
        Vsum += measv;         /* accum liner avg */

    } while ( --samples);

    // Clean up DMA
    DMA_ADDR->_gctrl._intval = 0; /* disable DMA */
    asm("   AND    @IE_allDMAoff, IE; turn off DMA interrupt enable ");
    HW->Listen = SW_OFF;

    // Calculate DC component of measurment
    measv1 = Vsum / su->samples;
    measv2 = Vsum2 / su->samples;

    /* compute measured period of AC signal */
    if( su->MeasType == AHC_DC )                  // Linear average (DC)
        measv =  measv1;
    else if( su->MeasType == AHC_RMS ||  su->MeasType == AHC_RMS_AC)     // Sync RMS 
        measv = sqrt( measv2 );
    else if( su->MeasType == AHC_PEAK)           // Largest magnitude
        measv = MAX(fabs(maxV), fabs(minV));
    else if( su->MeasType == AHC_PKPK )
        measv = maxV-minV; /* always positive */


    return measv;

} /* end of vmeas routine */




asm("  .global _reloc1_end ");
asm("  .label _reloc1_end ");

/* end of ON-CHIP CODE, resume normal C code
 *******************************************/
asm("  .sect  \".text\"");  /* must match .cmd file label, locates address */

