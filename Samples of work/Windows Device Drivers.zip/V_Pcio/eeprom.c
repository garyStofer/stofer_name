// EEPROM constant 
#define EE_ADDR_MASK 0x003f // for combining addresses with instructions 
#define EE_CMD_LEN 9 // bits in instructions 
#define EE_READ 0x0180 // 01 1000 0000 read instruction 
#define EE_WRITE 0x0140 // 01 0100 0000 write instruction 
#define EE_WREN 0x0130 // 01 0011 0000 write enable instruction 
#define EE_WDS 0x0100 // 01 0000 0000 write disable instruction 
#define EE_PREN 0x0130 // 01 0011 0000 protect enable instruction 
#define EE_PRCLEAR 0x0177 // 01 1111 1111 clear protect register instr
// EEPROM Functions 
static BOOL EepromReadBuf(UINT EpromConReg, WORD * dest, UINT wcount); 
static WORD EepromReadWord(UINT EpromConReg, UINT EpromAddr); 
static BOOL EepromWriteBuf(UINT EpromConReg, WORD * src, UINT wcount); 
static BOOL EepromWriteWord(UINT EpromConReg, UINT EpromAddr, WORD val); 
static BOOL EepromSendCmd(UINT cmd, UINT EpromConReg); 
static BOOL EepromClock(UINT EpromConReg);
 
extern void WriteRtrDword(UNIT EpromConReg, DWORD regval);
extern DWORD ReadRtrDword(UNIT EpromConReg );

///////////////////////////////////////////////////////////////////////////// 
static BOOL 
EepromReadBuf(UINT EpromConReg, WORD * dest, UINT wcount) 
{ // Read words from EEPROM into buffer 
	UINT i; 
	for ( i = 0; i < wcount; i++ ) 
		dest[i] = EepromReadWord(EpromConReg, i); 
	return TRUE; 
}
///////////////////////////////////////////////////////////////////////////// 
static WORD 
EepromReadWord(UINT EpromConReg, UINT EpromAddr) 
{ // Return a word from National Semiconductor's NMC93S06/NMC93S46 EEPROM 
	WORD acc = 0x0; 
	UINT i; 
	EepromSendCmd(EE_READ | (EpromAddr & EE_ADDR_MASK), EpromConReg); 
	for ( i = 0; i < 16; i++ )
	{ // Get word from EEPROM - one bit at a time 
		acc <<= 1; 
		EepromClock(EpromConReg); 
		if ( ReadRtrDword(EpromConReg) & 0x08000000 ) 
			acc |= 0x0001; 
	} 
	return acc; 
}
///////////////////////////////////////////////////////////////////////////// 
////////////////////////////////////////////////////////////////////////// 
static BOOL 
EepromWriteBuf(UINT EpromConReg, WORD * src, UINT wcount) 
{ // Read words from EEPROM into buffer 
	UINT i; 
	for ( i = 0; i < wcount; i++ ) 
		if ( !(EepromWriteWord(EpromConReg, i, src[i])) ) 
			return FALSE; 
		return TRUE; 
}
///////////////////////////////////////////////////////////////////////////// 
static BOOL 
EepromWriteWord(UINT EpromConReg, UINT EpromAddr, WORD val) 
{ // Write a word to National Semiconductor's NMC93S06/NMC93S46 EEPROM 
	UINT i; 
	DWORD regval; 
	EepromSendCmd(EE_WREN, EpromConReg); // Write enable 
	EepromSendCmd(EE_WRITE | (EpromAddr & EE_ADDR_MASK), EpromConReg); 
	regval = ReadRtrDword(EpromConReg) & ~0x04000000; // Pre-clear data bit 
	for( i = 16; i ; i-- )
	{ // Write word to EEPROM - one bit at a time 
		WriteRtrDword(EpromConReg, regval|((val & 0x8000)? 0x04000000: 0x0)); 
		EepromClock(EpromConReg); 
		val <<= 1; 
	} 
	// Activate chip's status mechanism: deselect and reselect 
	WriteRtrDword(EpromConReg, regval & ~0x02000000); // Deselect 
	WriteRtrDword(EpromConReg, regval); // Reselect 
	// Poll chip status until write-cycle completes (or times out) 
	// (Timeout counter is uncalibrated and somewhat arbitrary!) 
	for( i = 2000; !(ReadRtrDword(EpromConReg) & 0x08000000); i-- )
	{ 
		if ( i ) 
			continue; 
		// Timeout! 
		printf("EepromWriteWord(): Busy timeout EEPROM addr:0x%2.2x\n", 
			EpromAddr); 
		return FALSE; 
	} 
	EepromSendCmd(EE_WDS, EpromConReg); // Write disable 
	returnTRUE; 
}
///////////////////////////////////////////////////////////////////////////// 
static BOOL 
EepromSendCmd(UINT cmd, UINT EpromConReg) 
{ // Send a command to National Semiconductor's NMC93S06/NMC93S46 EEPROM 
	UINT i; 
	DWORD regval; 
	regval = ReadRtrDword(EpromConReg); 
	regval |= 0x02000000; // Chip select TRUE 
	regval &= ~0x05000000; // Clear instruction and clock bits 
	// Toggle EEPROM's chip select (to get it out of Shift Register Mode) 
	WriteRtrDword(EpromConReg, regval & ~0x02000000); // Chip select FALSE 
	WriteRtrDword(EpromConReg, regval); 
	for ( i = 0; i < EE_CMD_LEN; i++ )
	{ // Send instruction - one bit at a time 
		regval &= ~0x04000000; // Pre-clear the instruction bit 
		// Set up one instruction bit 
		regval |= (cmd & (0x01 << (EE_CMD_LEN-1)))? 0x04000000: 0x00000000; 
		WriteRtrDword (EpromConReg, regval); 
		EepromClock(EpromConReg); 
		cmd <<= 1; // Align next instruction bit 
	} 
	return TRUE; 
}
///////////////////////////////////////////////////////////////////////////// 
static BOOL 
EepromClock(UINT EpromConReg) 
{ // Send clocking sequence to Nat Sem's NMC93S06/NMC93S46 EEPROM 
	DWORD regval; 
	regval = ReadRtrDword(EpromConReg); 
	WriteRtrDword(EpromConReg, regval & ~0x01000000); // Clock low 
	WriteRtrDword(EpromConReg, regval | 0x01000000); // Clock high 
	returnTRUE; 
}
