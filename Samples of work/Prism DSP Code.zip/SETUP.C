/*
 * $Revision: 1.4 $
 * Test parameters hardware/software setup functions.
 * Gary Stofer
 */ 
#include <string.h>     /* for NULL */
#include "prismapi.h"    /* for communications buffer definition */
#include "ahc_bnds.h"   /* for parameter bounds */
#include "pixi_reg.h"   /* for PIXI register definitions */
#include "setup.h"      /* for SETUP structure definition */
#include "tmr.h"        /* for timer definitions */
#include "util.h"       /* for MAX() */
#include "wavtable.h"   /* for cont_stims */
#include "execute.p"   // function prototypes
#include "pixi_glo.e"
extern void MemSet( void *, int, int);    // From IEEE.asm  -- faster then lib function
extern void MemCpy( void *, void *, int); // From IEEE.asm  -- faster then lib function

/* 6 pole, 3 section, 2.0khz fc, Butterworth IIR LP digital filter coefficients
 * designed using Mathcad v5 Signal Processing Pack filter design module
 * per section: y(n) = a0*x(n) + a1*x(n-1) + a2*x(n-2) - b1*y(n-1) - b2*y(n-2)
 */
Type2pDfCoeff LpDf6p2kHzTable=
{
    /* for stim freq = AC1_7 = 1.25khz
     * 2.0 khz fc 6 pole IIR lowpass, 3 biquad sections, fs=100khz    
     * gain = 0.9982 @ 1.25kHz    
     *   a0           a1          a2        b1         b2    
     */    
    { 0.0038188,  0.0076375, 0.0038188, -1.9218861, 0.9371612},
    { 0.0036217,  0.0072434, 0.0036217, -1.8226949, 0.8371817},
    { 0.0035169,  0.0070338, 0.0035169, -1.7699541, 0.7840217},
    { 150 },
};

/* 6 pole, 3 section, 100hz fc, Butterworth IIR LP digital filter coefficients
 * for use with line reject on
 */
Type2pDfCoeff LpDf6p100HzTable=
{
    { 9.8535e-6,  1.9707e-5, 9.8535e-6, -1.9967135, 0.9967529},
    { 9.8259e-6,  1.9652e-5, 9.8259e-6, -1.9911143, 0.9911536},
    { 9.8100e-6,  1.9620e-5, 9.8100e-6, -1.9878959, 0.9879351},
    { 3000 },
};

/* 6 pole, 3 section, 200hz fc, Butterworth IIR LP digital filter
   coefficients for use with high guard on
*/
Type2pDfCoeff LpDf6p200HzTable=
{
    { 3.9349919e-5,  7.8699838e-5, 3.9349919e-5, -1.9933590, 0.9935164},
    { 3.9130205e-5,  7.8260411e-5, 3.9130205e-5, -1.9822289, 0.9823855},
    { 3.9004467e-5,  7.8008934e-5, 3.9004467e-5, -1.9758594, 0.9760154},
    { 1500 },
};


/* 6 pole, 3 section, 20hz fc, Butterworth IIR LP digital filter
   coefficients for use with high guard on
 */
Type2pDfCoeff LpDf6p20HzTable =
{
    { 3.9465577e-7,  7.8931153e-7, 3.9465577e-7, -1.9993481, 0.9993497},
    { 3.9443364e-7,  7.8886728e-7, 3.9443364e-7, -1.9982228, 0.9982244},
    { 3.9430551e-7,  7.8861102e-7, 3.9430551e-7, -1.9975737, 0.9975753},
    { 15000 },
};



float ADC_Scale[] =    // multiplier for measure range selection
{
    0.0,    // Open input                   x10 Gain off
    100.0,  // 300V range .     atten 0.01  x10 gain off
    10.0,   // 30V range ..     atten 0.1   x10 gain off
    1.0,    // 3V range ..      atten 1.0   x10 gain off
    0.0,    // Open input ..                x10 Gain ON
    10.0,   // Differential 30V range  atten 0.01  x10 Gain ON
    1.0,    // Differential 3V range   atten 0.1   x10 Gain ON
    0.1     // 0.3V range       atten  1.0   x10 Gain ON
};


float rfTable[] =    /* MOA feedback resistor values indexed by resistor number */
{
    HUGE_VAL,  /* n = 0 = PX_ROPEN */
    1.0,   /* n = 1 = PX_R0  */
    1e1,   /* n = 2 = PX_R10   */
    1e2,   /* n = 3 = PX_R100  */
    1e3,   /* n = 4 = PX_R1K   */
    1e4,   /* n = 5 = PX_R10K  */
    1e5,   /* n = 6 = PX_R100K */
    1e6,   /* n = 7 = PX_R1M   */
    1e7,   /* n = 8 = PX_R10M  */
    1e8,   /* n = 9 = PX_R100M (Rf only) */
    HUGE_VAL   /* n = 10 = beyond the end of the table */
};

/* Stim 0 series resistor values indexed by resistor number
 * same value as register setting for Rx SELECT @ port 0x11
 * Stim 1 series resistor is a subest of Stim 0 Resistors ( 0,10,100,1K,10K)
 * Hv Stim series resistor is a subset of stim 0 Resistors ( O, 1k, 10k)
 */
float rsTable[] =
{
    HUGE_VAL,  /* n = 0 = PX_ROPEN */
    0.0,   /* n = 1 = PX_R0  */
    1e1,   /* n = 2 = PX_R10   */
    1e2,   /* n = 3 = PX_R100  */
    1e3,   /* n = 4 = PX_R1K   */
    1e4,   /* n = 5 = PX_R10K  */
    1e5,   /* n = 6 = PX_R100K */
    1e6,   /* n = 7 = PX_R1M   */
    1e7,   /* n = 8 = PX_R10M  */
    HUGE_VAL,   /* n = 9 */
    21.5,  /* n = 10 = PXR21_5  */
    46.4,  /* n = 11 = PXR46_4  */
    215.0, /* n = 12 = PXR215   */
    464.0, /* n = 13 = PXR215   */
    2.15e3,/* n = 14 = PXR2_15K */
    4.64e3,/* n = 15 = PXR4_64K */
    21.5e3,/* n = 16 = PXR21_5K */
    46.4e3,/* n = 17 = PXR46_4K */
    215.0e3,/* n = 18 = PXR215K */
    HUGE_VAL    /* n = 19 = beyond the end of the table */
};



// This function determines the required Stim resistor and Stim output voltage
// to create the requested I stim for Zmode tests                            */ 
float 
IstimRx( float I, float Vstim_max, int *Rx)
{
    int rn ;
    float i ;       

    i = fabs(I);
    Vstim_max = fabs( Vstim_max);

        if (Vstim_max > AHC_HV_THRESH)
            Vstim_max = AHC_HV_THRESH;

    for (rn = PX_R10M; rn >= PX_R10 ; rn-- )
    {
            if (i < Vstim_max / OHM_Rs(rn))
                break;
    }

        if (i > Vstim_max / OHM_Rs(rn))
            g_err = AER_STIM_I_TOO_HIGH;

        *Rx = rn;
        return( I * OHM_Rs(rn) );      // the needed Stim output voltage
}	


// same as above but for the  second stim 
static float
IstimRy( float I, float Vstim_max, int *Ry)
{
    int rn ;
    float i ;       

    i = fabs(I);
    Vstim_max = fabs( Vstim_max);

        if (Vstim_max > AHC_HV_THRESH)
            Vstim_max = AHC_HV_THRESH;

    for (rn = PX_R10M; rn >= PX_R10 ; rn-- )
    {
            if (i < Vstim_max / OHM_Rs(rn))
        break;
    }

        if (i > Vstim_max / OHM_Rs(rn))
            g_err = AER_STIM_I_TOO_HIGH;

        return( I * OHM_Rs(rn) );      // the needed Stim output voltage
}	



/* Determines the Y-mode MOA feedback resistor depending on Dut impeadance
   and maximum allowable gain 
   This function sets the Setup Rfn  and returns worst case gain in MOA
*/
static float
SetRfn( float dut_Z_min, float max_gain, unsigned long *rf )
{
    int Rfn ;
    float gain;

    for ( Rfn = PX_R100M; Rfn >= PX_R0 ; Rfn-- )
    {
        if ( ( gain = (OHM_Rf(Rfn) / dut_Z_min) ) <= max_gain )
            break;
    }

    if (Rfn < PX_R0)
        Rfn = PX_R0;

    *rf = Rfn;
    return gain;
}


struct tagLacTableYmode
{
    float top_rng;   /* max L value for the range */
    int  ACprd;        /* stim period */
}
LacTableYmode[] =     /* Inductor AC ranges */
{
    // Henries, Stim Period
    { 50e-6,    AHC_AC20Khz, },    // ????? 
    { 5e-3,     AHC_AC16Khz, },
    { 500e-3,   AHC_AC1667Hz, },
    { 50.0,     AHC_AC166Hz, },
    { HUGE_VAL, -1, }
};


struct tagCacTableYmode
{
    float top_rng;   /* max Cap value for the range */
    int  ACprd;    /* stim period */
}

CacTableYmode[] =  /* Cap AC ranges, entry value is max of range */
{
/*  { 42.43e-12, AHC_AC12Khz,  },  Min Xc=300.0e3,Max Xc=12.7e6 */
    { 424.3e-12, AHC_AC12Khz,  }, /* Min Xc=30.0e3,Max Xc=1.27e6 */
    { 4.243e-6,  AHC_AC1250Hz, }, /* Min Xc=30.0,  Max Xc=3.0e6  */	
    { 424.3e-6,  AHC_AC125Hz,  }, /* Min Xc=3.0,   Max Xc=300.0  */
    { 2121.5e-6, AHC_AC25Hz,   }, /* Min Xc=3.0,   Max Xc=15.0  */
    { AHB_MAX_C, AHC_DC,       },
    { HUGE_VAL,  -1,  	       }
};

#define TAN38 0.7841

/*> converts AC Cap to Voltage & Resistor number */
/* given the setup Capacitance */
/* and period of the AC  */
/* returns series resistor number */
/* and sets stim freq */


#define SU_NO_TEST 0


/*> compares high & low limits to bounds & sets limits */


struct tagCbrRxTable CbrRxTable[NUM_BR_RX] =       /* RC Bridge series resistors */
{
    // limit,   Rx,       n_cycles
    { 13.68,    PX_R10   , 5},
    { 29.4,     PX_R21_5 , 5},
    { 63.47,    PX_R46_4 , 5},
    { 136.8,    PX_R100  , 5},
    { 294.12,   PX_R215  , 5}, /* eg for dut impedance 136-294 */
    { 634.75,   PX_R464  , 5}, /* eg for dut impedance 294-634 */
    { 1.368e3,  PX_R1K   , 5},
    { 2.94e3,   PX_R2_15K, 5},
    { 6.347e3,  PX_R4_64K, 5},
    { 13.68e3,  PX_R10K  , 5},
    { 29.4e3,   PX_R21_5K, 50},
    { 63.47e3,  PX_R46_4K, 50},
    { 136.8e3,  PX_R100K , 50},
    { 294e3,    PX_R215K , 110}
};


/*> converts Bridge RC Cap to Voltage & Resistor number */
/* given the min Capacitance */
/* and period of the AC test frequency */
/* returns series resistor number */
/* and feedback resistor number */
/* and sets stim, squelch, & measure types */

static void
CtoVRbr( float Cprog,SETUP *su)

{
    int entry = 0;
    float  Z, Xc;  /* RC impedance, C reactance */
    

    Xc = su->s0.prd / (2*PI*AHC_SF*Cprog);
    if(su->par_R > 0.0)
        Z = su->par_R*Xc / sqrt(su->par_R*su->par_R + Xc*Xc);
    else
        Z = 1.0;

    for (entry = 0; entry < NUM_BR_RX; entry++ )
    {
        if (Z < CbrRxTable[entry].limit )
            break;
    }

    su->s0.RsNdx = CbrRxTable[entry].Rx;
    // use RfNdx here for index into Bridge resistor arry
    su->RfNdx = entry;

    return ; 
}




static float  /* returns max voltage for setting measurement scale */
/*> sets high & low voltage limits */
TV_limits ( SETUP *su, float high,float low   )
{
    float v;                   /* Voltage for setting measurement scale */

    v = MAX( fabs(high), fabs(low));

    if (su->MeasType == AHC_RMS || su->MeasType == AHC_RMS_AC)
        v *= SQRT2;
    else if (su->MeasType == AHC_PKPK)
        v /= 2.0;

    return v;
}




/* Return AC compensated DAC voltage */
/* find stim range multiplier, and AC correction factor */
//Inputs  : su->nStims, su->sx.v_out and su->sx.prd filled in 
// Output : su->HV_in_use, sx.dac_v hw->StimxVolrRng.attenx20
static void 
SVrange ( SETUP *su, HWREGS *hw)
{
    float stim_v;
    float pk_factor;
    float *pkf_tbl;
    int num_stim;

    STIM *stim;
    /* First, adjust amplitude based on the AC frequency
     * sinx/x compensation for reconstruction filter sample/hold effects    
     */    
    for (num_stim = su->nStims; num_stim ; num_stim-- )
    {
        if (num_stim == 2 )
        {
            stim = &su->s1;
            pkf_tbl = s1_pk_factor;
        }
        else
        {
            stim = &su->s0;
            pkf_tbl = s0_pk_factor;
        }

        stim_v   = fabs(stim->v_out);
        pk_factor = 1.0; 


        if (stim->func == ST_SINE)
        {
            int ACper = stim->prd;

            // apply the pk_factor correction out of prev. learned table
            if (ACper <= 80 )
                pk_factor = pkf_tbl[ACper];    
        }

        stim->pk_factor = pk_factor;
        stim->dac_v = stim->v_out * pk_factor;
        stim_v *= pk_factor;


        if (stim_v  < PX_STIM_500MV_FS)  // below 0.5v run the dac 20times higher
        {
        	stim->dac_v  *= 20;
            if( num_stim == 2)
                hw->Stim1VoltRng.Attenx20 = SW_ON;
            else
                hw->Stim0VoltRng.Attenx20 = SW_ON;
        }

        if ( num_stim == 1 )    // stim0 uses the x10 amplifier (Ymode)
        {
            if ( su->Hv_in_use = (stim_v > AHC_HV_THRESH) ? 1 : 0)
            {
            	stim->dac_v /= HIGHV_GAIN;

                if (su->s0.func == ST_DC)
                    su->s0.func = ST_DC_SLOW;
            }
        }

        if (stim->dac_v  > AHC_HV_THRESH )
        {
           // return Setup error indicating requested voltage can not be provided 
           g_err = AER_MAX_STIMV_EXCEED;
           stim->dac_v = AHC_HV_THRESH;
        }
    }
}

static void
stimVMode (AHC_POLE_CONN *pole,SETUP *su, HWREGS *hw)
{
    SVrange( su, hw);

    if (!su->Hv_in_use) /* stim<10.0V */
    {
        hw->RxSelect.dat = su->s0.RsNdx;

        // If a remote sense forced, doesn't make much sense for stim R >0.0
        if( su->nStims==1 && pole->StimSense==AHC_AT_DUT_SENSE)
            hw->Stim0_OutSel.dat = PX_S0_Ed | PX_S0_RMT;  // REMOTE sense
        else    /* local Stim 0 sense */
            hw->Stim0_OutSel.dat = PX_S0_Ed | PX_S0_LOC;


    }
    else    /* high voltage stim */
    {
        if (su->s0.RsNdx == PX_R0 || su->s0.RsNdx == PX_R1K || su->s0.RsNdx == PX_R10K)
            hw->RzSelect.dat = su->s0.RsNdx;
	else
	{
            // error indicating wrong HV stim resistor selected
            g_err = AER_INVALID_HV_R;
            hw->RzSelect.dat = PX_R10K;
	}


        hw->Stim0_OutSel.dat = PX_S0HV_Ed | PX_S0_LOC;
    }

    if (su->s1.func != ST_NONE )
    {
        hw->RySelect.dat = su->s1.RsNdx;
        hw->Stim1_OutSel.dat =  PX_S1_Es;
    }
}


static void
measVMode( unsigned Meas_In, float Common_modeV, SETUP *su, HWREGS *hw)
{
   float Scale_V;   
   
   hw->MoaConnect.dat = PX_NO_MOA;

    // nodefinder or external input 
    switch( Meas_In )
    {
        case MEAS_IN_EPOLE:
            hw->MeasSource1.dat = PX_HI_ED | PX_LO_AGND;
            break;
        case MEAS_IN_FPOLE:
            hw->MeasSource1.dat = PX_HI_FD | PX_LO_AGND;
            break;
        case MEAS_IN_FPOLE_FLOAT:
            hw->MeasSource1.dat = PX_HI_FD | PX_LO_GS;
            break;
        case MEAS_IN_EXTERN:
            hw->MeasSource1.dat = PX_HI_LineFreq | PX_LO_AGND;
            break;
    }	
    
                                                      
    if ( Meas_In == MEAS_IN_FPOLE_FLOAT )
    {   // need to separate between common mode scaling and diff amp scaling
        Scale_V = MAX( fabs(Common_modeV), su->Vmoa_pk); // input scaling so that it fits in the rails   
        hw->MeasRange1.dat = TVscale (Scale_V);
                                                             
        if ( hw->MeasRange1.scale.atten )   //divide 0 precation
        {   
            if (su->Vmoa_pk / ADC_RNG(hw->MeasRange1.scale.atten ) < 0.29 ) // measV scaling, Gain up for small diff volage 
                hw->MeasRange1.scale.gain_10 = 1; 
        }
        
        switch (hw->MeasRange1.dat )
        {               
            case PX_300MV:
                su->rng_top = 0.29;
                su->rng_btm = 0.0;
                break;
		    case PX_3V: 
                su->rng_top = 2.9;
                su->rng_btm = 0.29;
                break; 
            case PX_3V_DIF: 
                su->rng_top = 2.9;
                su->rng_btm = 0.0;
                break;    
		    case PX_30V:
                su->rng_top = 29.0;
                su->rng_btm = 2.9;
                break;
            case PX_30V_DIF:
                su->rng_top = 29.0;
                su->rng_btm = 0.0;
                break;
		    default:
                su->rng_top = 300.0;
                su->rng_btm = 0.0;
          }
    }   
    else
    {
        hw->MeasRange1.dat = TVscale (su->Vmoa_pk);     
        
        switch (hw->MeasRange1.dat )
        {               
            case PX_300MV:
                su->rng_top = 0.29;
                su->rng_btm = 0.0;
                break;
		    case PX_3V: 
                su->rng_top = 2.9;
                su->rng_btm = 0.29;
                break;
		    case PX_30V:
                su->rng_top = 29.0;
                su->rng_btm = 2.9;
                break;

		    default:
                su->rng_top = 300.0;
                su->rng_btm = 29.0;
        }
    }    
    
    

}

static void
Ymode( AHC_POLE_CONN *pole, SETUP *su, HWREGS *hw )
{
    // needed for squelch  
    hw->SqArm = SW_ON;         // will possibly get turned off later  
    hw->Squelch= SW_ON;        // will get turned off during measurment

    hw->MeasSource1.src.Hi_In = H_VDIFF;
    hw->MeasSource1.src.Lo_In = L_AGND;

    SVrange( su, hw);

    hw->MoaConnect.bit.ImoaFD = SW_ON;

    if ( pole->MeasSense == AHC_AT_PRISM_SENSE)
    {
        hw->MoaConnect.bit.Moa_n_In = M_n_FD;
        hw->Stim0_OutSel.bit.VdiffIn = X0_VDIFF_FD;
    }
    else
    {
        hw->MoaConnect.bit.Moa_n_In = M_n_FS;
        hw->Stim0_OutSel.bit.VdiffIn = X0_VDIFF_FS;
    }

    if(pole->GuardSense != AHC_AT_PRISM_SENSE)
    {
        hw->MoaConnect.bit.Moa_p_In = M_p_GS;
        hw->MoaConnect.bit.GdAgnd = SW_ON;
    }
    else
        hw->MoaConnect.bit.Moa_p_In = M_p_AGND;

    hw->MoaConnect.bit.FDgAgnd = SW_ON;

    if ( su->nStims == 1  && !su->Hv_in_use && pole->StimSense != AHC_AT_PRISM_SENSE)
        hw->Stim0_OutSel.bit.Stim_remote_sense = SW_ON;

    if (su->s1.func != ST_NONE )
    {
        hw->RySelect.dat = su->s1.RsNdx;
        hw->Stim1_OutSel.dat =  PX_S1_Es;
    }

    if (! su->Hv_in_use)
    {
        hw->Stim0V.direct_ED = SW_ON;
        hw->MeasSource2.src.Hi_In = H_VDIFX0;
        hw->MeasSource2.src.Lo_In = L_AGND;
    }
    else    /* high voltage stim */
    {
        hw->Stim0_OutSel.bit.Stim_route = S0_ED_X10;
        hw->MeasSource2.src.Hi_In = H_ES;
        hw->MeasSource2.src.Lo_In = L_FS;
    }


    hw->MeasRange1.dat = TVscale (su->Vmoa_pk);
    hw->MeasRange2.dat = TVscale (su->s0.v_out);

    // The Validate resistors accross Ed - Fd 
    if ( su->R_ef )
        hw->Stim0_OutSel.bit.Stim_to_FD = SW_ON;

    
    // bandwith limit with comp cap
    if ( su->s0.prd == AHC_DC)
    {              
        if ( su->MeasOpt.bit.MoaBWlimit )
        {
            su->wait += 200; // add extra wait for slow comp  
            
            hw->MoaCompSlow = SW_ON;   
            
            if (su->MeasOpt.bit.Fast)
            	hw->CfSelect.cap.C_1Nf = SW_ON;
            else
                hw->CfSelect.cap.C_100Nf = SW_ON;
                            
        }
        else if (!su->MeasOpt.bit.Fast)
           	hw->CfSelect.cap.C_1Nf = SW_ON;
   
    }


    hw->RfSelect.dat = su->RfNdx;
    hw->RxSelect.dat = su->R_ef;
    hw->RySelect.dat = su->s1.RsNdx;
    hw->Cef.dat = su->C_ef;  /* Parallel validate components */


    if (fabs( su->Vmoa_pk ) < COMPLY_07V )
        hw->MoaCmplnc.limit =V_Lim_0_7v;
    else if (fabs( su->Vmoa_pk ) < COMPLY_6V )
        hw->MoaCmplnc.limit =V_Lim_6v;
    else
        hw->MoaCmplnc.limit =V_Lim_11v;

}


static void
Zmode( AHC_POLE_CONN *pole , SETUP *su , HWREGS *hw)
{
    // needed for squelch 
    hw->SqArm = SW_ON;         // will possibly get turned off later  
    hw->Squelch= SW_ON;        // will get turned off during measurment

    // hw->Stim0_OutSel.dat = PX_S0_Fd | PX_VDIFX0_RxRx;
    hw->Stim0_OutSel.bit.VdiffIn = X0_VDIFF_RX_LOCAL;
    hw->Stim0_OutSel.bit.Stim_to_FD = SW_ON;

    hw->RxSelect.dat = su->s0.RsNdx;

    if (su->s1.func )
    {
        hw->RySelect.dat = su->s1.RsNdx;
        hw->Stim1_OutSel.dat =  PX_S1_Es;   
        hw->MeasSource1.src.Hi_In = H_ED;
    } 
    else
        hw->MeasSource1.src.Hi_In = H_ES;
    
    // always use the Scale amp as diff-amp in order to free up the usage of Rfset
    // of resistors for Current limiting resistors for Vmoa. 
    // For dual stim pick up at Ed - FS for single stim ES-Fs

    hw->MeasSource1.src.Lo_In = L_FS;  

    SVrange( su, hw);

    su->Hv_in_use = (fabs (su->Vmoa_pk) > AHC_HV_THRESH) ? 1 : 0;

    if (! su->Hv_in_use)
    {
        hw->MoaConnect.bit.VmoaED = SW_ON;  

        if (fabs(su->Vmoa_pk) < COMPLY_07V)
            hw->MoaCmplnc.limit =V_Lim_0_7v;
        else if (fabs(su->Vmoa_pk) < COMPLY_6V )
            hw->MoaCmplnc.limit =V_Lim_6v;
        else 
            hw->MoaCmplnc.limit =V_Lim_11v;

    }
    else  
    {
        hw->MoaCompSlow = SW_ON;                // always use slow comp
        hw->MoaConnect.bit.VmoaEDx10 = SW_ON;
        hw->RzSelect.dat = PX_R0;

        if (fabs(su->Vmoa_pk) < COMPLY_6V * HIGHV_GAIN)
            hw->MoaCmplnc.limit =V_Lim_6v;
        else
            hw->MoaCmplnc.limit =V_Lim_11v;

    } 
    
    // This is used in diode test Zmode to limit gain when DUT is missing and therefore provide 
    // a software compliance 
    if ( su->RfNdx )
    {
        hw->RfSelect.dat = su->RfNdx;
        hw->MoaConnect.bit.ImoaFD = SW_ON;
    }
    
    if (su->s0.func == ST_DC)      // always ramp up the STIm at 2.7Khz since we
        su->s0.func = ST_DC_SLOW;  // Don't know abou the DUT imp and type

    
    if ( su->MeasOpt.bit.MoaBWlimit )
        hw->MoaCompSlow = SW_ON;

    hw->MoaConnect.bit.FDgAgnd = SW_ON;

    if(pole->GuardSense != AHC_AT_PRISM_SENSE)
    {
        hw->MoaConnect.bit.Moa_p_In = M_p_GS;
        hw->MoaConnect.bit.GdAgnd = SW_ON;
    }
    else
        hw->MoaConnect.bit.Moa_p_In = M_p_AGND;

    if(pole->MeasSense == AHC_AT_PRISM_SENSE)
        hw->MoaConnect.bit.Moa_n_In = M_n_FD;
    else
        hw->MoaConnect.bit.Moa_n_In = M_n_FS;

    hw->MeasSource2.src.Hi_In = H_VDIFX0;
    hw->MeasSource2.src.Lo_In = L_AGND; 

    hw->MeasRange1.dat = TVscale (su->Vmoa_pk);
    hw->MeasRange2.dat = TVscale (su->s0.v_out);

    switch (hw->MeasRange1.dat)
    {
        case PX_300MV:
            su->rng_top = 0.29;
            su->rng_btm = 0.0;
            break;
		case PX_3V:
            su->rng_top = 2.9;
            su->rng_btm = 0.29;
            break;
		case PX_30V:
            su->rng_top = 29.0;
            su->rng_btm = 2.9;
            break;

		default:
            su->rng_top = 300.0;
            su->rng_btm = 29.0;
    }
}    

static void
BridgeMode( AHC_POLE_CONN *pole,int ACprd, SETUP *su, HWREGS *hw)
{
// This defeats the autorange for Bridge mode
// Autorange limits depend on the stim0 resistor and on the min and max amplitude
// out of Stim0
su->rng_top = 99999.99;
su->rng_btm = 0.0;
    su->MeasAlg = SU_BRIDGE;
    su->MeasType= AHC_RMS;
    su->s1.v_out = su->s0.v_out = AHC_LC_STIM_V;
    su->nStims = 2;
    su->s1.len = su->s0.len = ACprd;
    su->s1.cyc = su->s0.cyc = 1;
    su->s1.prd = su->s0.prd = (float) su->s0.len /  (float) su->s0.cyc;
    su->s0.func = su->s1.func = ST_SINE;

    CtoVRbr (su->mid_val + su->Cadj,su);
    su->s1.RsNdx = PX_R0;
    SVrange(su, hw);

    /* VMscale left at default 300 mv */            
    hw->MeasRange1.scale.atten = ATTEN_1;
    hw->MeasRange1.scale.gain_10 = SW_ON;

    hw->RxSelect.dat = su->s0.RsNdx;
    hw->RySelect.dat = su->s1.RsNdx;
    hw->Stim0_OutSel.dat = PX_S0_Fd | PX_S0_LOC;
    hw->Stim1_OutSel.bit.Ed = SW_ON;
    hw->Stim1_OutSel.bit.Es = SW_ON; // to halve the inductance in the stim side
    hw->MoaConnect.dat = PX_Gd_AGND | PX_FSHLD_ACT;

    hw->MeasSource1.src.Hi_In = H_FS;
    if(pole->GuardSense != AHC_AT_PRISM_SENSE)
        hw->MeasSource1.src.Lo_In = L_GS;
    else
        hw->MeasSource1.src.Lo_In = L_AGND;

    // Run Stims at fast slew rate
    hw->Stim0HfComp230Khz = SW_OFF;
    hw->Stim1HfComp230Khz = SW_OFF;

    hw->Cef.dat = su->C_ef;  /* Parallel validate components */

}



static int              /* returns MOA voltage amplitude */
CapSetup( int ACprd, float Cprog, float Stim_v, SETUP *su, HWREGS *hw )
{
    struct tagCacTableYmode *entry;
    float Xc;      /* C reactance */
    float Z;      /* C and par R impedance */
    float gain;
    float i_stim;
    int	gone_down = 0;
    int	gone_up = 0;
    int	found_ac = 0;
    int i;


    if(ACprd==AHC_DEFAULT)
    {
        entry = CacTableYmode;
        while (Cprog > entry->top_rng )
            entry++;

        if (entry->ACprd < 0 ) 
        {
            g_err = AER_CAP_TOO_BIG;
            return SU_NO_TEST;
        }

        if ( su->par_R > 0.0   && entry->ACprd != AHC_DC )
        {

            /* while within the table */
            while( entry >= CacTableYmode  && entry->ACprd > AHC_DC )
            {
                /* Can't fit between 3 and 300Ko with phase angle >38 deg */
                if ( gone_up && gone_down )
                    break;

                Xc = entry->ACprd / (PI2 * AHC_SF * Cprog );
                Z = su->par_R * Xc / sqrt(su->par_R * su->par_R + Xc * Xc);

                if(( Z > 300.09e3) || (su->par_R < TAN38*Xc))
                {
                    entry--;
                    gone_down++;
                    continue;
                }
                if ( Z < 3.0 )
                {
                    entry++;
                    gone_up++;
                    continue;
                }

                found_ac++;
                break;
            } 

            if ( ! found_ac)
            {
                g_err = AER_NO_RC_MODE_SETUP;
                return SU_NO_TEST;
            }
        }


        ACprd = entry->ACprd;
    }

    if ( ACprd != AHC_DC )
    {
     
        Xc = ACprd / ( 2 * PI * AHC_SF * Cprog );

        if ( su->par_R > 0.0 )	// If an RC test 
        {
            Z = su->par_R * Xc / sqrt(su->par_R * su->par_R + Xc * Xc);
            su->MeasOpt.bit.Precise = 1;   // force precise mode for imp RC test
        }
        else
            Z = Xc;


        gain = SetRfn( Z, MOA_AC_GAIN, &su->RfNdx);

        if ( gain > MOA_AC_GAIN )
            g_err = AER_AC_CAP_FREQ_TOO_HIGH;

        // Figure the range-end Z
        // RNG_HEADROMM defines the overlap  (bootom and top ) of ranges 
        // result is bulk imp if RC or Xc if plain C
        su->rng_top = OHM_Rf(su->RfNdx) / (MOA_AC_GAIN * RNG_HEADROOM);
        su->rng_btm = OHM_Rf(su->RfNdx) /(MOA_AC_GAIN /10 / RNG_HEADROOM); 
 
        // Figure the range-end XC
        if (su->par_R > 0.0)
        {
            su->rng_btm = 1 / sqrt(1/(su->rng_btm * su->rng_btm) - 1/(su->par_R * su->par_R));
            su->rng_top = 1 / sqrt(1/(su->rng_top * su->rng_top) - 1/(su->par_R * su->par_R));
        }

        // Convert range-end Xc to capacitor (C) values
        su->rng_btm =  ACprd / ( PI2 * AHC_SF * su->rng_btm );
        su->rng_top =  ACprd / ( PI2 * AHC_SF * su->rng_top );

        su->MeasAlg = SU_YMODE;
        su->s0.cyc = 1;         // only fundamentals supported
        su->s0.len = ACprd;
        su->s0.prd = ACprd;
        su->s0.func = ST_SINE;
        su->nStims = 1;
        su->MeasType = AHC_RMS;
        if (Stim_v != 0.0 )
            su->s0.v_out = Stim_v;
        else
            su->s0.v_out = AHC_LC_STIM_V;

        su->Vmoa_pk = su->s0.v_out * gain * RNG_HEADROOM;
    }
    else // Large DC charge up methode 
    {
    	// if RC mode is indicated need to cause an error since not supported
        if ( su->par_R > 0.0 )
        {
            g_err = AER_NO_DC_RC_MODE;
            return SU_NO_TEST;
        }


        if (Cprog < AHB_MIN_C_DC)
        {
            g_err = AER_DC_CAP_TOO_SMALL;
            return SU_NO_TEST;
        }
        su->MeasAlg = SU_CHARGE;
        su->s0.prd = AHC_DC;
        su->s0.func - ST_DC;
        su->MeasType = AHC_DC;
        su->nStims = 1;

        i_stim = Cprog * (AHC_LC_STIM_V /AHC_DC_CAP_TIME);
        su->s0.v_out = IstimRx (i_stim, 9.99999, &su->s0.RsNdx);

        su->Vmoa_pk = 0.2;
        su->rng_btm = i_stim *( AHC_DC_CAP_TIME / 0.29 );
        su->rng_top = i_stim *( AHC_DC_CAP_TIME / 0.018 );
    }

    return 1;

}

/*************************************************************************************************
*
* All subsequent functions 

*  starting with _su_xxx are setup functions for the particular measure type
* each function distills information from the commincations buffer (cb) into the two data 
* structures SETUP (su)  and HWREGS (hw). The information in su is later used to guide the
* execution of the test while the info in *hw is the software representation of the hardware registers 
* (relay positions) which will be copied onto the actual hardware upon execution of the setup function
*  See external document for theory of operation and further details
**************************************************************************************************/ 

int
su_Lo_R ( AHC_COMM_BUF *cb, SETUP *su , HWREGS *hw)
{
    AHC_TEST_PARAMS *p = &cb->dat.Su1.param;
    float R;

    su->MeasAlg = SU_R3W;
    su->mid_val = p->values.Value + g_sysR3W;

/* select Rf, keeping the MOA Voltage Gain Rf/R <= MAX */
//  this should be called with the low_val to get worst case gain

    su->s0.prd = AHC_DC;
    su->s0.v_out = AHC_R_STIM_LO;
    su->nStims = 1;
    su->MeasType = AHC_DC;
    su->Vmoa_pk = su->s0.v_out * SetRfn( su->mid_val, MOA_DC_GAIN, &su->RfNdx);

    su->MeasUnits = 'O';        /* non-0 common R3W setup */
    su->Radj = g_sysR3W;
    su->wait = TMR_FILTER_FAST;
    su->samples = AHC_SHORTS_SAMPLES;
    cb->dat.Su1.pole.StimSense = AHC_AT_PRISM_SENSE;
    cb->dat.Su1.pole.MeasSense = AHC_AT_PRISM_SENSE;
    cb->dat.Su1.pole.GuardSense = AHC_AT_PRISM_SENSE;

    Ymode(&cb->dat.Su1.pole,su, hw);
    set_relays( cb, su, hw );

    switch (cb->hdr.TestType)
    {
        case AHC_CONT:
            su->low_val = -HUGE_VAL;
            su->high_val = p->cont.thresh;
        break;

        case AHC_LOWR:
            su->low_val = -HUGE_VAL;
            su->high_val = p->lowr.thresh;
            su->MeasUnits = 'O';   
            su->wait += p->lowr.Wait;
        break;

        case AHC_SHORTS:
            su->low_val = p->shorts.thresh;
            su->high_val = HUGE_VAL;
            su->MeasUnits = 'O';   
            /* shorts has relay change between executes,
                 * so need extra relay settling        
                 */        
            su->wait += TMR_RELAYS + p->shorts.Wait;
            /* add in relay delay since CC relays change while in repeat Execute mode */
        break;
    } 
    return  AHC_OK;
}    

int
su_Apc ( AHC_COMM_BUF *cb, SETUP *su , HWREGS *hw)
{
    AHC_TEST_PARAMS *p = &cb->dat.Su1.param;
    float R;


    su->MeasAlg = SU_R3W;
    R = p->values.Value + g_sysR3W;

/* select Rf, keeping the MOA Voltage Gain Rf/R <= MAX */
//  this should be called with the low_val to get worst case gain

    su->s0.prd = AHC_DC;
    su->s0.v_out = AHC_R_STIM_LO;
    su->nStims = 1;
    su->MeasType = AHC_DC;
    su->Vmoa_pk = su->s0.v_out * SetRfn( R, MOA_DC_GAIN,&su->RfNdx);

    cb->dat.Su1.pole.StimSense = AHC_AT_PRISM_SENSE;
    cb->dat.Su1.pole.MeasSense = AHC_AT_PRISM_SENSE;
    cb->dat.Su1.pole.GuardSense = AHC_AT_PRISM_SENSE;

    Ymode(&cb->dat.Su1.pole,su, hw);
    set_relays( cb, su, hw );

    su->low_val = -HUGE_VAL;
    su->wait += p->apc.Wait;
    su->samples = su->s0.prd;
    su->averaging = (su->MeasOpt.bit.LineRej) ? LINE_SAMPLES()/su->samples : 1; 
    
    return  AHC_OK;
}



int
su_Res ( AHC_COMM_BUF *cb, SETUP *su , HWREGS *hw)
{
    float max_gain;
    float gain;
    AHC_R_PARAMS    *p = &(cb->dat.Su1.param.r);
    
    
    su->nStims = 1;
    su->low_val = p->Low;
    su->high_val = p->High;
    
    if (su->mid_val == 0.0)     // initial setup (not autorange re-setup)
        su->mid_val = p->Value + p->SysResAdjust;


    
    // check incoming component paramters and autorange value for validity
    if (p->Value > p->High || p->Value < p->Low)     // crossed values 
    {
        g_err = AER_DUT_VAL_TOO_LOW;
        return(AHC_ERROR);
    }

    if (su->low_val < AHB_MIN_O  || su->mid_val < AHB_MIN_O)   
    {
        g_err = AER_DUT_VAL_TOO_LOW;
        su->mid_val = AHB_MIN_O;
        return(AHC_ERROR);
    } 
    
    if (su->high_val > AHB_MAX_O || su->mid_val > AHB_MAX_O)       
    {
        g_err = AER_DUT_VAL_TOO_HIGH;
        su->mid_val = AHB_MAX_O;
        return(AHC_ERROR);
    }


    // only fundametal frequencies supported in Shorthnd
    if ( p->Stim0Type == AHC_DEFAULT || p->Stim0Type == AHC_DC)
    {
        su->s0.prd = AHC_DC;
     	su->s0.func = ST_DC;
        su->MeasType = AHC_DC;
        max_gain  = MOA_DC_GAIN;

        if(su->MeasOpt.bit.LineRej)
            su->samples = LINE_SAMPLES();
        else if(su->MeasOpt.bit.Fast)
            su->samples = AHC_SHORTS_SAMPLES;
        else
            su->samples = AHC_R_SAMPLES;
    }
    else
    {
        su->s0.len = p->Stim0Type & 0xffff;
        su->s0.cyc = ((p->Stim0Type & 0xf0000 ) >> 16)+1;
        su->s0.prd = (float) su->s0.len / (float)su->s0.cyc;
		su->s0.func = ST_SINE;
        su->MeasType = AHC_PEAK;
        su->samples = ACsamples (su->s0.len * su->s0.cyc, 1);

        max_gain = MOA_AC_GAIN;
    }
            

    if (p->Stim_v != 0.0 )
        su->s0.v_out = p->Stim_v ;
    else
        su->s0.v_out = (su->mid_val > AHC_R_STIM_THRESH) ? AHC_R_STIM_HI : AHC_R_STIM_LO;
  	

    gain = SetRfn(su->mid_val, max_gain, &su->RfNdx); 
    // Need to setup for midval so we don't have autorange in most cases.
    // must set up Vmoa_pk for the worst case in gain so that the compliance doesn't come in
    // to play inside the range and the meas scale is setup properly -- 
    // Or must setup the feedback res for the low_val comp to 
    // get the worst case gain back
    
      
    if (su->RfNdx == PX_R0 )
    {  
        max_gain = OHM_Rf(su->RfNdx) / su->low_val;
        if (g_PrismHwRev <= 7)   // hard wire the BW limit to help with stim spikes on non DLB boards
            su->MeasOpt.bit.MoaBWlimit = SW_ON;        
        // if projected maximal current above max current then lower stim vltage 
        if ( fabs(su->s0.v_out / su->low_val) > AHC_R_MAX_I)
        {
            su->s0.v_out = su->low_val * AHC_R_MAX_I * -1.0;
            su->MeasOpt.bit.Precise = 1; // force precise to be on; needed for low amp stim
        }
    }
    
    su->Vmoa_pk = su->s0.v_out * max_gain * RNG_HEADROOM;
    
    /* give enough headroom  when we expect line noise */
    if ( p->High  > 10e6  || su->MeasOpt.bit.LineRej  || su->MeasOpt.bit.HiGuard)
        su->Vmoa_pk *= 2.0 ; 

    // RNG_HEADROMM defines the overlap  (bootom and top ) of ranges 
    su->rng_btm = OHM_Rf(su->RfNdx) / (max_gain * RNG_HEADROOM);
    su->rng_top = OHM_Rf(su->RfNdx) /(max_gain /10 / RNG_HEADROOM); 

    su->C_ef =  p->C_ef;  /* Parallel validate components */
    su->R_ef =  p->R_ef;  /* Parallel validate components */
    
    if (su->MeasOpt.bit.Fast)
        su->wait = TMR_FILTER_FAST + (p->Wait);
    else
        su->wait = (2*TMR_FILTER + RES_WAIT(su->mid_val)) + p->Wait;

	// run second stim along with fist- diag code in kernel will make final pole connection 
  	if (p->DiagDualStim)
	{
	 	su->nStims = 2;

		su->s1.len = su->s0.len;
        su->s1.cyc = su->s0.cyc;
        su->s1.prd = su->s0.prd;
		su->s1.func = su->s0.func;
		su->s1.v_out = su->s0.v_out; 
		su->s1.RsNdx = 	PX_R1K; 		// will get changed later
	}

    Ymode(&cb->dat.Su1.pole,su, hw);
  	// fix the second meas source when dual stim is on for Ry Resistors
  	if (p->DiagDualStim && su->MeasOpt.bit.Precise)
    	hw->MeasSource2.src.Hi_In = H_VDIFX1;

    set_relays( cb, su, hw );

    su->MeasAlg = SU_YMODE;
    su->MeasUnits = 0xEA; // Ohm sign
    su->Radj = p->SysResAdjust;
   

   

    su->averaging = p->Averaging;

    return(AHC_OK);
    
}    

int
su_Cap ( AHC_COMM_BUF *cb, SETUP *su , HWREGS *hw)
{
    AHC_C_PARAMS    *p = &(cb->dat.Su1.param.c);

    int len, cyc;
    int  user_prd;      // int == only fundametal freq. supported in SH
    
    su->low_val = p->Low;
    su->high_val = p->High;
    
    if (su->mid_val == 0.0)     // initial setup (not autorange re-setup)
        su->mid_val = p->Value + p->SysCapAdjust;   // Setup value

     // check incoming component paramters and autorange value for validity
    if (p->Value > p->High || p->Value < p->Low)  // crossed values
    {
        g_err = AER_DUT_VAL_TOO_LOW;
        return(AHC_ERROR);
    }

    if (su->low_val <= AHB_MIN_C || su->mid_val <= AHB_MIN_C)   
    {
        g_err = AER_DUT_VAL_TOO_LOW;
        su->mid_val = AHB_MIN_O;
        return(AHC_ERROR);
    } 
    
    if (su->high_val >= AHB_MAX_C || su->mid_val >= AHB_MAX_C)       
    {
        g_err = AER_DUT_VAL_TOO_HIGH;
        su->mid_val = AHB_MAX_O;
        return(AHC_ERROR);
    }

    su->MeasOpt.bit.LineRej = 0; // No line reject for AC 
    su->wait = TMR_FILTER * 2 + p->Wait;  // might get overridden by fastmode (Y-mode only )
   
    su->C_ef =  p->C_ef;  /* Parallel validate components */
    su->R_ef =  p->R_ef;  /* Parallel validate components */

    if ( p->RC_mode )
        su->par_R = p->_R;  // The parallel resistor to the C

    user_prd = AHC_DEFAULT;

    // only fundametal frequencies supported in Shorthnd
    if ( p->Stim0Type != AHC_DEFAULT)
    {
       len =  p->Stim0Type & 0xffff;
       cyc =  ((p->Stim0Type & 0xf0000) >> 16) +1;
       user_prd = len/cyc;
    }

    if ( p->RC_mode != AHC_RC_BRIDGE )
    {
        CapSetup ( user_prd, su->mid_val, p->Stim_v, su, hw);

        if (su->MeasAlg == SU_YMODE)
        {
            Ymode(&cb->dat.Su1.pole,su, hw);
            // Add in the Cap discharge if RF at 1ohm 
            if (hw->RfSelect.dat <= PX_R0)
            {
                // undo the feed-back so we don't discharge the cap hard
                // RF held in su->RfNdx
                hw->RfSelect.dat = PX_ROPEN;
                hw->Squelch = SW_ON;  
                // Discharge time six Tau (Rsquelch * Dutvalue)
                su->CapDsc = 6 * 50.0  * su->mid_val * 1e5 ; /* units of 10us */
                
             }

            if (su->MeasOpt.bit.DigFil )
            {
                if (su->s0.prd >= AHC_AC12Hz )
                    su->DigFil = &LpDf6p20HzTable;
                else if (su->s0.prd >= AHC_AC125Hz )
                    su->DigFil = &LpDf6p200HzTable;
                else if (su->s0.prd >= AHC_AC1250Hz )
                    su->DigFil = &LpDf6p2kHzTable;
            }
              
            if (su->MeasOpt.bit.Fast)
                su->wait = TMR_FILTER_FAST + (p->Wait);

        }
        else if ( su->MeasAlg == SU_CHARGE)
        {   
            // Discharge time six Tau (Rsquelch * Dutvalue)
            su->CapDsc = 6 * 50.0  * su->mid_val * 1e5 ; /* units of 10us */
            su->MeasOpt.bit.MoaBWlimit = SW_ON;  // suppress oscillation @2.5Mhz
            Zmode(&cb->dat.Su1.pole,su, hw);
        }
 
        su->samples = (su->s0.prd == AHC_DC) ? AHC_CHARGE_SAMPLES :
                        ACsamples (su->s0.len * su->s0.cyc, 1);
        
    }
    else  // BRIDGE mode setup
    {
        if (p->Stim0Type == AHC_DEFAULT)
            user_prd = AHC_AC16Khz;

        if (p->Stim0Type > AHC_AC12Khz)
            g_err = AER_BRIDGE_MODE_FREQ;

        if ( ! g_err )
        	BridgeMode( &cb->dat.Su1.pole, user_prd, su , hw);
    }

    set_relays( cb, su, hw );

    su->MeasUnits = 'F';
    su->Ladj = p->SysIndAdjust;
    su->Cadj = p->SysCapAdjust;
    su->averaging = p->Averaging;

    if (g_err)
        return(AHC_ERROR);

    return(AHC_OK);

}    


int
su_Ind ( AHC_COMM_BUF *cb, SETUP *su , HWREGS *hw)
{

    AHC_L_PARAMS    *p = &(cb->dat.Su1.param.l);
    struct tagLacTableYmode *entry;
    float Xl;
    float Z;
    float gain;
    
    su->low_val = p->Low;
    su->high_val = p->High;
    
    if (su->mid_val == 0.0)     // initial setup (not autorange re-setup)
        su->mid_val = p->Value + p->SysIndAdjust;


    // check incoming component paramters and autorange value for validity
    if (p->Value > p->High || p->Value < p->Low)  // crossed values
    {
        g_err = AER_DUT_VAL_TOO_LOW;
        return(AHC_ERROR);
    }

    if (su->low_val <= AHB_MIN_H || su->mid_val <= AHB_MIN_H )   
    {
        g_err = AER_DUT_VAL_TOO_LOW;
        su->mid_val = AHB_MIN_O;
        return(AHC_ERROR);
    } 
    
    if (su->high_val >= AHB_MAX_H || su->mid_val >= AHB_MAX_H)       
    {
        g_err = AER_DUT_VAL_TOO_HIGH;
        su->mid_val = AHB_MAX_O;
        return(AHC_ERROR);
    }
    
    su->MeasType = AHC_RMS;
    su->par_R = p->_R;  // The parasitic series resistor of DUT and wiring
    su->Ladj = p->SysIndAdjust;

    entry = LacTableYmode;
    while (su->mid_val > entry->top_rng )
        entry++;

    if (entry->ACprd < 0 ) 
    {
        g_err = AER_IND_TOO_BIG;
        return AHC_ERROR;
    }

    // only fundametal frequencies supported in Shorthnd
    if ( p->Stim0Type != AHC_DEFAULT)
    {
        su->s0.len = p->Stim0Type & 0xffff;
        su->s0.cyc = ((p->Stim0Type & 0xf0000 ) >> 16)+1;
        su->s0.prd = (float) su->s0.len / (float)su->s0.cyc;
    }
    else
    {
        su->s0.prd = entry->ACprd;
        su->s0.len = su->s0.prd;
        su->s0.cyc = 1;
    }

    su->s0.func = ST_SINE;      // should come from WS
    if (su->s0.prd >= AHC_AC20Khz)
        su->MeasOpt.bit.Precise =1; // force precise to be on; needed for 20Khz

    Xl = (PI2 * AHC_SF * su->mid_val) / su->s0.prd;
    Z = sqrt( Xl*Xl + su->par_R * su->par_R);
    gain = SetRfn( Z, MOA_IND_GAIN, &su->RfNdx);


    // Figure the range-end XL
    // RNG_HEADROMM defines the overlap  (bootom and top ) of ranges 
    su->rng_btm = OHM_Rf(su->RfNdx) / (MOA_IND_GAIN * RNG_HEADROOM);
    su->rng_top = OHM_Rf(su->RfNdx) /(MOA_IND_GAIN /10 / RNG_HEADROOM); 

    /* convert Reactance to Inductance */
    su->rng_top = su->rng_top * su->s0.prd / (PI2 * AHC_SF);
    su->rng_btm = su->rng_btm * su->s0.prd / (PI2 * AHC_SF);
    
    if (su->RfNdx == PX_R0 )
        su->rng_btm = AHB_MIN_H; // very low end of scale using more gain then requested 
        
    if (p->Stim_v != 0.0)
        su->s0.v_out = p->Stim_v;
    else
		su->s0.v_out = AHC_LC_STIM_V;

    if ( su->s0.v_out / Z > AHC_LC_MAX_I)
    {
        su->s0.v_out = AHC_LC_MAX_I * Z;
        su->MeasOpt.bit.Precise =1; // force precise to be on; needed for low amp stim
    }

    su->nStims = 1;
    su->wait = TMR_FILTER*2 + (int)(TCM_L* su->mid_val /OHM_Rf(su->RfNdx) + 0.5) + p->Wait;

    su->Vmoa_pk = su->s0.v_out * gain * RNG_HEADROOM;
    su->C_ef =  p->C_ef;  /* Parallel validate components */
    su->R_ef =  p->R_ef;  /* Parallel validate components */
    Ymode(&cb->dat.Su1.pole,su, hw);

    set_relays( cb, su, hw );

    su->MeasAlg = SU_YMODE;
    su->MeasUnits = 'H';

    su->samples = ACsamples (su->s0.len * su->s0.cyc, 1);
    su->averaging = p->Averaging;

    return(AHC_OK);
    
}    
 
int
su_dio_V ( AHC_COMM_BUF *cb, SETUP *su , HWREGS *hw)
{
    AHC_DIO_V_PARAMS   *p = &(cb->dat.Su1.param.dioV); 
    int   Stim_polarity = 1;   
    int   i;
    float v_dac; 
    float gain;                                     
    
 p->ComplV = 0; // debugging code -- to force the limit to be 1V above high limit;
    
    // depending on the junction type and stim-measure config change the current polarity 
    if ( p->typeZener )    // type is zener voltage drop
    {
       if (p->StimNodeOn == AHC_CATHODE)
                Stim_polarity = -1; 
    }            
    else                   // type is forward diode drop
    {
        if (p->StimNodeOn == AHC_ANODE)
                Stim_polarity = -1; 
    } 
    
    su->MeasOpt.bit.MoaBWlimit = SW_ON;     // Always set the BW limit to protect from oscillationsu->MeasOpt.bit.MoaBWlimit = SW_ON; 
       
     
    su->MeasAlg = SU_ZMODE;            // keyed on in exec routine
    su->s0.v_out = IstimRx (p->Stim * Stim_polarity, AHC_HV_THRESH, &su->s0.RsNdx); 
       
    if (su->mid_val == 0.0) // initial setup 
        su->Vmoa_pk = TV_limits (su, p->High, p->Low);
    else                    // autorange re-setup    
        su->Vmoa_pk = TV_limits (su, su->mid_val, su->mid_val);   
    
    su->s0.prd = AHC_DC;
    su->s0.func = ST_DC;
    su->nStims = 1;
    su->MeasType = AHC_DC; 
    su->high_val = p->High;
    su->low_val = p->Low;
  
    
    Zmode(&cb->dat.Su1.pole,su, hw);  
    
    // fix up items specifc to Diode compliance mode only
    if (! su->Hv_in_use &&  (fabs(su->Vmoa_pk) < COMPLY_DIO09V))
         hw->MoaCmplnc.limit = V_Lim_0_7v;
   
    
    set_relays( cb, su, hw );

    su->MeasUnits = 'V';
        
    su->wait = TMR_FILTER*2 + p->Wait  ;     // allow extra time for MoaComplSlow == ON
    su->sqTime = su->wait;      // squelch at the end of stim at least as long as the wait time
    
    su->averaging = p->Averaging;  
    su->samples = ( su->MeasOpt.bit.Fast) ? AHC_SHORTS_SAMPLES : AHC_DC_SAMPLES; 
     
    return  AHC_OK;
} 


int
su_dio_I ( AHC_COMM_BUF *cb, SETUP *su , HWREGS *hw)
{
    AHC_REV_I_PARAMS   *p = &(cb->dat.Su1.param.revI);
    float I;

    su->s0.RsNdx = PX_R10;  /* always current limit, to prevent welding */
    su->s0.v_out = p->Stim;
    su->s0.prd = AHC_DC;
    su->s0.func = ST_DC;
    su->nStims = 1;
    I = su->high_val = p->High;

    if (p->StimNodeOn == AHC_ANODE)
        su->s0.v_out *= -1.0;

    su->Vmoa_pk = su->s0.v_out * SetRfn( fabs(su->s0.v_out / I),MOA_DC_GAIN, &su->RfNdx); 
    su->MeasType = AHC_DC;
    Ymode(&cb->dat.Su1.pole,su, hw);

    set_relays( cb, su, hw );

    su->MeasAlg =SU_YMODE;
    su->MeasUnits = 'A';
    su->low_val = -HUGE_VAL;
    su->wait = TMR_FILTER*2 + p->Wait;
    su->averaging = p->Averaging;
    su->samples = su->MeasOpt.bit.LineRej ? LINE_SAMPLES() : AHC_DC_SAMPLES;  
   
    return  AHC_OK;
}    

int
su_trn_Beta ( AHC_COMM_BUF *cb, SETUP *su , HWREGS *hw)
{
    /* TYPE    Gnd Node   Stim1 Vce pol   Stim0 Ic pol
   * NPN     base           +              +            
   * PNP     base           -              -            
   * NPN     emitter        +              -            
   * PNP     emitter        -              +            
   * NPN     collector      -              +            
   * PNP     collector      +              -            
   */            
    AHC_BETA_PARAMS   *p = &(cb->dat.Su1.param.beta);   
    float I;

    su->MeasType = AHC_DC;
    su->nStims = 2;

    su->Vmoa_pk = su->s1.v_out = p->Vce;    // not sure if Vmoa applies
    su->low_val = p->Gain;
    su->high_val = HUGE_VAL;
    su->RfNdx = PX_R0; /* 1ohm for minimum Rf */
    g_DutI = I = p->Ic;
    hw->MeasRange1.dat = PX_3V;

    /* pick Rx for desired Ib and 3.0V scale, assuming NPN type
    * pick Rf if emitter or collector, for 3V scale given Ib            
    */            
    if(p->MeasNodeOn == AHC_BASE)
    {
        g_isBase = 1;
        su->s0.v_out = IstimRx(I/su->low_val, 3.0, &su->s0.RsNdx);
      /* pick stim1=su->Vmoa_pk, = Vce-0.8V due to eg base grounded, so Vee=-0.8
         min Vce == 1.0V                */                
      su->Vmoa_pk = su->s1.v_out = su->s1.v_out - 0.8;  // not sure if Vmoa applies
    }
    else /* measure emitter or collector */
    {
        g_isBase = 0;
        /* pick Rs knowing Vrampmax=3V at which point Icc>=DutI desired */
        su->s0.v_out = IstimRx(I, 3.0, &su->s0.RsNdx);

        su->RfNdx = PX_R10;

        if(p->MeasNodeOn == AHC_COLLECTOR)
        {
            g_err = AER_NOT_IMPLEMENTED;  /* !!! doesnt work */
            su->s1.v_out *= -1.0; /* voltage to Vce stim1 is neg */
        }
        else /* measure emitter */
            su->s0.v_out *= -1.0;
    }

    /* pick Ry so I*Ry is < DutVpk so transistor doesnt saturate */            
    IstimRy(I, su->s1.v_out, &su->s1.RsNdx);

    if(p->Transistor == AHC_PNP)
    {
        su->s0.v_out *= -1.0;
        su->s1.v_out *= -1.0;
        su->Vmoa_pk *= -1.0;        // not sure if vmoa applies
    }

    /* VMscale left at default 300 mv */            

    hw->MoaCmplnc.limit =V_Lim_0_7v;
    hw->MoaCompSlow = SW_ON;

    hw->MeasSource1.dat = PX_HI_VDIFX1 | PX_LO_AGND;
    hw->RfSelect.dat = su->RfNdx;
    hw->RxSelect.dat = su->s0.RsNdx;
    hw->RySelect.dat = su->s1.RsNdx;

    /* connect MOA same for all transistor orientations
    *  if(p->beta.MeasNodeOn == AHC_BASE)            
    *   else if(p->beta.MeasNodeOn == AHC_COLLECTOR)            
    *  else if(p->beta.MeasNodeOn == AHC_EMITTER)            
    */            
    hw->Stim0_OutSel.dat = PX_S0_Fd | PX_S0_LOC;
    hw->Stim1_OutSel.dat =  PX_S1_Es;

    if(cb->dat.Su1.pole.GuardSense == AHC_AT_PRISM_SENSE)
        hw->MoaConnect.dat =  PX_GndFs_MOA | PX_IMOA_Ed | PX_Vf_RfRf;
    else
        hw->MoaConnect.dat = PX_GsFs_MOA | PX_IMOA_Ed | PX_Vf_RfRf;

    set_relays( cb, su, hw );

    su->MeasAlg = SU_BETA;
    su->MeasUnits =' '; // Gain is unit less
    /* su->wait = TMR_FILTER*2 + p->beta.Wait; */
    su->wait = p->Wait; /* user wait is after ramped Icc up */
    su->averaging = p->Averaging;  
    
    return  AHC_OK;
} 


int
su_lh_TISV( AHC_COMM_BUF *cb, SETUP *su , HWREGS *hw)
{

    AHC_TISV_PARAMS   *p = &(cb->dat.Su1.param.tisv);
    float max_gain;
    float I;

    if ( p->Stim0Type == AHC_DEFAULT)
    {
        su->s0.prd = AHC_DC;
        su->s0.func = ST_DC;
    }
    else
    {
        su->s0.len = p->Stim0Type & 0xffff;
        su->s0.cyc = ((p->Stim0Type & 0xf0000 ) >> 16)+1;
        su->s0.prd = (float) su->s0.len / (float)su->s0.cyc;
        su->s0.func = ST_SINE;      // should come from WS
    }

    su->s0.v_out = p->Stim0;
    su->high_val = p->High;
    su->low_val = p->Low;

    if (su->mid_val == 0.0)     // initial setup (not autorange re-setup)
        su->mid_val = MAX( fabs(su->high_val), fabs(su->low_val));

    I = su->mid_val;

    if (su->MeasType == AHC_RMS || su->MeasType == AHC_RMS_AC)
        I *= SQRT2;	/* take the rms value up to peak */
    else if (su->MeasType == AHC_PKPK )
        I /= 2.0; 	/* take the pkpk value to pk */


    if (su->s0.func == ST_DC )
        max_gain = MOA_DC_GAIN;
    else
        max_gain = MOA_AC_GAIN;

    su->MeasType = p->MeasType ;


    SetRfn( fabs(su->s0.v_out / I), max_gain, &su->RfNdx); 

    su->Vmoa_pk = su->s0.v_out * max_gain * RNG_HEADROOM;

    if (p->DualStim)
    {
        if ( p->Stim1Type == AHC_DC)
        {
            su->s1.prd = AHC_DC;
            su->s1.func = ST_DC;
        }
        else
        {
            su->s1.len = p->Stim1Type & 0xffff;
            su->s1.cyc = ((p->Stim1Type & 0xf0000 ) >> 16) +1;
            su->s1.prd = (float) su->s1.len / (float) su->s1.cyc;
            su->s1.func = ST_SINE;      // should come from WS
        }
        // need to deal with stim 2 periode 
        su->nStims = 2;
        su->s1.v_out = p->Stim1;
        su->s1.RsNdx = p->Stim1Res;
        su->s1.prd = p->Stim1Type;
        su->s1.v_out = p->Stim1;
    }
    else
        su->nStims = 1;

    Ymode(&cb->dat.Su1.pole,su, hw);
    
    if  (su->MeasType == AHC_RMS_AC )
    {
       hw->MeasCoupleAc =1;
       hw->AcCoupleDsc =1;
       p->Wait += 5500;  // wait 55 ms for cap charge up, then remove the discharge path
    }
    
    set_relays( cb, su, hw );

    su->MeasUnits = 'A';
    su->MeasAlg = SU_YMODE;

    if (su->MeasType == AHC_DC &&  su->s0.prd == AHC_DC)
    {
	if (su->MeasOpt.bit.LineRej)
            su->samples = LINE_SAMPLES();
        else 
            su->samples = (p->Sampling > 8 ) ? p->Sampling : 8;
    }
    else
 	su->samples = ACsamples(su->s0.len * su->s0.cyc, p->Sampling);

    su->averaging = p->Averaging;

    su->rng_top = fabs(su->s0.v_out) / (OHM_Rf(su->RfNdx) / (max_gain * RNG_HEADROOM));
    su->rng_btm = fabs(su->s0.v_out) / (OHM_Rf(su->RfNdx) / (max_gain /10 / RNG_HEADROOM)); 

    su->wait = TMR_VI_FILTER*2 + p->Wait; 
    return  AHC_OK;
}


int
su_lh_TVSI( AHC_COMM_BUF *cb, SETUP *su , HWREGS *hw)
{
    AHC_TVSI_PARAMS    *p = &(cb->dat.Su1.param.tvsi);
                                
 
    if ( p->Stim0Type == AHC_DEFAULT)
    {
        su->s0.prd = AHC_DC;
        su->s0.func = ST_DC;
    }
    else
    {
        su->s0.len = p->Stim0Type & 0xffff;
        su->s0.cyc = ((p->Stim0Type & 0xf0000 ) >> 16) + 1;
        su->s0.prd = (float) su->s0.len / (float) su->s0.cyc;
        su->s0.func = ST_SINE;      // should come from WS
    }

    su->MeasType = p->MeasType;
    su->high_val = p->High;
    su->low_val = p->Low;

    if (su->mid_val == 0.0) // initial setup 
        su->Vmoa_pk = TV_limits (su, su->high_val, su->low_val);
    else                    // autorange re-setup    
        su->Vmoa_pk = TV_limits (su, su->mid_val, su->mid_val); 

    su->s0.v_out = IstimRx (p->Stim0,9.99999, &su->s0.RsNdx) ;


    if (p->DualStim)
    {
        if ( p->Stim1Type == AHC_DEFAULT)
        {
            su->s1.prd = AHC_DC;
            su->s1.func = ST_DC;
        }
        else
        {
            su->s1.len = p->Stim1Type & 0xffff;
            su->s1.cyc = ((p->Stim1Type & 0xf0000 ) >> 16) +1;
            su->s1.prd = (float) su->s1.len / (float) su->s1.cyc;
            su->s1.func = ST_SINE;      // should come from WS
        }
        su->nStims = 2;
        su->s1.v_out = p->Stim1;
        su->s1.RsNdx = p->Stim1Res;
    }
    else
        su->nStims = 1;

    Zmode(&cb->dat.Su1.pole , su , hw);
    
    if  (su->MeasType == AHC_RMS_AC )
    {
       hw->MeasCoupleAc =1;
       hw->AcCoupleDsc =1;
       p->Wait += 5500;  // wait 55 ms for cap charge up, then remove the discharge path
    }
    
    set_relays( cb, su, hw );

    su->MeasUnits = 'V';
    su->MeasAlg = SU_ZMODE;

    if (su->MeasType == AHC_DC &&  su->s0.prd == AHC_DC)
    {
	    if (su->MeasOpt.bit.LineRej)
             su->samples = LINE_SAMPLES();
        else 
             su->samples = (p->Sampling > 8 ) ? p->Sampling : 8;
    }
    else
 	    su->samples = ACsamples(su->s0.len * su->s0.cyc, p->Sampling);


    su->averaging = p->Averaging;

    su->wait = TMR_VI_FILTER*2 + p->Wait; 
    su->sqTime = su->wait;      // squelch at the end of stim at least as long as the wait time
    return  AHC_OK;
}    

int
su_lh_TVSV( AHC_COMM_BUF *cb, SETUP *su , HWREGS *hw)
{ 
    AHC_TVSV_PARAMS   *p = &(cb->dat.Su1.param.tvsv);


    if ( p->Stim0Type == AHC_DEFAULT)
    {
        su->s0.prd = AHC_DC;
        su->s0.func = ST_DC;
    }
    else
    {
        su->s0.len = p->Stim0Type & 0xffff;
        su->s0.cyc = ((p->Stim0Type & 0xf0000 ) >> 16)+1;
        su->s0.prd = (float) su->s0.len / (float) su->s0.cyc;
        su->s0.func = ST_SINE;      // should come from WS
    }

    if (p->DualStim)
    {

        if ( p->Stim1Type == AHC_DEFAULT)
        {
            su->s1.prd = AHC_DC;
            su->s1.func = ST_DC;
        }
        else
        {
            su->s1.len = p->Stim1Type & 0xffff;
            su->s1.cyc = ((p->Stim1Type & 0xf0000 ) >> 16) +1;
            su->s1.prd = (float) su->s1.len / (float) su->s1.cyc;
            su->s1.func = ST_SINE;      // should come from WS
        }

        su->nStims = 2;
        su->s1.v_out = p->Stim1;
        su->s1.RsNdx = p->Stim1Res;
    }
    else
        su->nStims = 1;


    su->s0.RsNdx = p->Stim0Res; // used for both Rx and Rz
    su->s0.v_out = p->Stim0;
    su->MeasType = p->MeasType;
    su->high_val = p->High;
    su->low_val = p->Low;

    if (su->mid_val == 0.0)     // initial setup (not autorange re-setup)
        su->mid_val = MAX( fabs(su->high_val), fabs(su->low_val));

    // Vmoa_pk used  for convenience
    su->Vmoa_pk = TV_limits (su, su->mid_val, 0.0);
    measVMode( p->Meas_In, p->CommonModeV, su, hw);
    stimVMode( &cb->dat.Su1.pole, su, hw );
    
    if  (su->MeasType == AHC_RMS_AC )
    {
       hw->MeasCoupleAc =1;
       hw->AcCoupleDsc =1;
       p->Wait += 5500;  // wait 55 ms for cap charge up, then remove the discharge path
    }
    
    set_relays( cb, su, hw );

    su->MeasAlg = SU_TV;
    su->MeasUnits = 'V';

    su->wait = TMR_VI_FILTER*2 + p->Wait;

   if (su->MeasType == AHC_DC &&  su->s0.prd == AHC_DC)
    {
	if (su->MeasOpt.bit.LineRej)
            su->samples = LINE_SAMPLES();
        else 
            su->samples = (p->Sampling > 8 ) ? p->Sampling : 8;
    }
    else
 	su->samples = ACsamples(su->s0.len * su->s0.cyc, p->Sampling);

   
    su->averaging = p->Averaging;
    return  AHC_OK;
}

int
su_lh_TV( AHC_COMM_BUF *cb, SETUP *su , HWREGS *hw)
{
    float       period;
    AHC_TV_PARAMS   *p = &(cb->dat.Su1.param.tv);

    su->nStims = 0;
    su->MeasType = p->MeasType;
    su->high_val = p->High;
    su->low_val = p->Low;

    if (su->mid_val == 0.0)     // initial setup (not autorange re-setup)
        su->mid_val = MAX( fabs(su->high_val), fabs(su->low_val));

    su->Vmoa_pk = TV_limits (su, su->mid_val, 0.0); // Vmoa_pk used for convenience


    measVMode( p->Meas_In,p->CommonModeV, su, hw);
    
    if  (su->MeasType == AHC_RMS_AC )
    {
       hw->MeasCoupleAc =1;
       hw->AcCoupleDsc =1;
       p->Wait += 5500;  // wait 55 ms for cap charge up, then remove the discharge path
    }
    
    set_relays( cb, su, hw );

    su->MeasAlg = SU_TV;
    su->MeasUnits = 'V';
    su->wait = TMR_VI_FILTER + p->Wait;

    if (su->MeasType == AHC_DC)
    {
     	if (su->MeasOpt.bit.LineRej)
     		su->samples = LINE_SAMPLES();
        else
     		su->samples = (p->Sampling > 8 ) ? p->Sampling : 8;
    }
     else       // ALL AC type measurments
     {
        
        // convert the measure freq. to 10us samples and oversample up to 5 times
        period = 1/ (float) p->Sampling;
        su->samples = (period *  100000 * 5 );
        if (su->samples > MAX_ADC_DMA )
                su->samples = MAX_ADC_DMA;
    }

    su->averaging = p->Averaging;
}    


int
su_CapScn( AHC_COMM_BUF *cb, SETUP *su , HWREGS *hw)
{
    AHC_CAP_SCAN_PARAMS 	*p = &(cb->dat.Su1.param.cscan);

    su->MeasAlg = SU_TV_CAP_SCAN;
    su->s0.RsNdx = su->s1.RsNdx = PX_R0;

    su->MeasType = su->MeasOpt.bit.LineRej ? AHC_PKPK : AHC_RMS;
    su->low_val = p->Capacitance;
    su->high_val = p->Capacitance;


    su->Vmoa_pk = CtoFcapscan(p->Capacitance, p->Stim0Type, su);
    su->s1.v_out = su->Vmoa_pk;
    su->s0.v_out = 0.0; /* stim 0 = DC 0 volts */
    su->nStims = 2;



    measVMode( MEAS_IN_FPOLE, 0, su, hw);
    stimVMode( 0, su , hw);
    hw->Stim1_OutSel.dat = PX_S1_Gd;

    set_relays( cb, su, hw );

    su->MeasUnits = 'V';
    su->low_val = -HUGE_VAL; /* don't care about pass or fail */
    su->high_val = HUGE_VAL;

    su->wait = TMR_VI_FILTER*2 + p->Wait;

    /* if digital filter used then add extra settling time ~1.2ms
   * if (su->HiGuard && (su->s1.prd >= AHC_AC1250Hz))            
   *   su->wait += TMR_DIG_LP_FILTER;            
   */            

    if(su->s1.prd == AHC_DC && !su->MeasOpt.bit.LineRej)
        su->samples = p->Sampling;
    else if(su->s1.prd == AHC_DC && su->MeasOpt.bit.LineRej)
        su->samples = LINE_SAMPLES();
    else if(su->s1.prd > AHC_DC && !su->MeasOpt.bit.LineRej)
        su->samples = ACsamples (su->s1.len *su->s0.cyc, p->Sampling);
    else if(su->s1.prd > AHC_DC && su->MeasOpt.bit.LineRej)
        su->samples = ACsamples (su->s1.len * su->s0.cyc, 1);
    else
    {
        su->samples = AHC_DC_SAMPLES;
    }

    su->averaging = su->MeasOpt.bit.LineRej ? LINE_SAMPLES()/su->samples :
    p->Averaging;

}    


int
no_setup( AHC_COMM_BUF *cb, SETUP *su, HWREGS *hw) { return 0; }    

static void
do_nothing( AHC_COMM_BUF *cb, SETUP *su, HWREGS *hw) { return; }    

float
no_exec(  SETUP *su , AHC_TEST_RESPONSE *rb) { return(0.0);}


// blast the configuration out
static void
set_relays( AHC_HDR_PARAM *hdr, SETUP *su, HWREGS *hw)
{
    // wait for last UnSetup() reeds to open before setting new relays
    TMR0wait ();

    // Only connect the discharge paths to the DUT at first
    if ( hdr->Softconnect)
    {
        HW->SoftConn.dat = PX_SFT_CNCT_ALL;	
        TMR0delay(TMR_SOFTCON);
        hdr->Softconnect =0;
    }

    PX_DAC0_OUT (0.0);  // make sure the DACs are at 0
    PX_DAC1_OUT (0.0);
    hw->Dac0Clk = SW_ON;
    hw->Dac1Clk = SW_ON;
  
  //  HW->Listen = SW_ON;     // measurment probe   
    MemCpy( (void *) HW, hw, sizeof(HWREGS)); 

    /* start the global timer running to time relay settling
     * first execute call of Vmeas will wait on timer    
     */    
    TMR0start (TMR_RELAYS);


}

/*struct f_table from setup.s
This struct def should move into pixi_glo.c  
struct f_table 
{
    int  (*setup)( AHC_COMM_BUF *cb, SETUP *su, HWREGS *hw);
    float(*exec) (  SETUP *su, AHC_TEST_RESPONSE *rb);
    void (*yyyyy)( AHC_COMM_BUF *cb, SETUP *su, HWREGS *hw);
};
*/

struct f_table su_func[] =
{ 
    { su_lh_TV,    ex_tv,   do_nothing }, //AHC_TV       1
    { no_setup,    no_exec, do_nothing }, //AHC_SV       2
    { su_Lo_R,     ex_loR,  do_nothing }, //AHC_CONT     2 
    { su_Lo_R,     ex_loR,  do_nothing }, //AHC_LOWR     3 
    { su_Lo_R,     ex_loR,  do_nothing }, //AHC_SHORTS   4 
    { su_Lo_R,     ex_loR,  do_nothing }, //AHC_OPENS    5 
    { su_Apc,      ex_loR,  do_nothing }, //AHC_APC      6 
    { no_setup,    no_exec, do_nothing }, //AHC_DISCH    7 
    { su_Res,      ex_res,  do_nothing }, //AHC_R        8 
    { su_Cap,      ex_cap,  do_nothing }, //AHC_C        9 
    { su_Ind,      ex_ind,  do_nothing }, //AHC_L        10
    { no_setup,    no_exec, do_nothing }, //AHC_XXXXXX   11
    { su_dio_I,    ex_dio_I,do_nothing }, //AHC_DIO_I    12
    { su_dio_V,    ex_dio_V,do_nothing }, //AHC_DIO_V    13
    { su_trn_Beta, ex_beta, do_nothing }, //AHC_BETA     14
    { su_lh_TISV,  ex_tisv, do_nothing }, //AHC_TISV     15
    { su_lh_TVSI,  ex_tvsi, do_nothing }, //AHC_TVSI     16
    { no_setup,    no_exec, do_nothing }, //AHC_TISI     17
    { su_lh_TVSV,  ex_tv,   do_nothing }, //AHC_TVSV     18
    { su_CapScn,   no_exec, do_nothing }  //AHC_CAP_SCAN 21
};




static void 
init_su_stim( STIM *st)
{
    st->prd = st->v_out = st->dac_v = st->dcoffs = 0.0;
    st->cyc = 1;
}

// this function to be expanded to do all the non test specifc initialization 
 
 
static void
init_su( AHC_COMM_BUF *cb, SETUP *su)
{
    
    MemSet( su, 0, sizeof(SETUP)); 

    su->MeasOpt.dat  = cb->dat.Su1.option; // copy all meas options at once 

    su->averaging = 1;
    su->samples = AHC_DC_SAMPLES;
    
    su->sqTime = TMR_STIM_ZERO; // the default Squelch time after stim is turned off
    
    su->low_val = su->high_val = su->mid_val = su->Vmoa_pk =
    su->Radj = su->Ladj = su->Cadj = su->par_R = (float) 0.0;
    
    
    su->MeasUnits = ' ';
    
    /* stim setup data */
    init_su_stim( &su->s0);
    init_su_stim( &su->s1);
    
}



/*****************************************************************************
 *  The purpose of Setup() is to process the communication buffer and
 *  1. setup the test hardware for the 1st measurement.
 *  2. start a relay settling timer of ~0.8ms.
 *  3. return the setup data in TI format used by Execute() and UnSetup().
 *
 *  The communications buffer is processed to do the following:
 *  1. To put an intermediate data structure (SETUP) layer between user
 *     inputs and remaining software that stays relatively constant.
 *  2. Communications buffer inputs, used by Execute(), and UnSetup(),
 *     are transferred from 1 wait state memory to 0 wait state memory.
 *  3. The communications buffer inputs are released so that the Test
 *     Exec, running on the PC, can enter the parameters for the next
 *     test into the communications buffer while the current test is
 *     is executing (a possible future PC pipe-lining feature).
 */


int    /* returns AHC_OK or AHC_ERROR */
Setup( AHC_COMM_BUF *cb , SETUP *su , HWREGS *hw, int re_setup )
{
    
    int     TestType;
    
    if (! re_setup)
        init_su(cb, su);
    else
    {
        // make sure stims are off
        Dac1Ctrl->up = Dac0Ctrl->up = 0;
        // wait for stim of a prev. (autorange ) measurment to terminate
        while ( Dac0Ctrl->delta || Dac1Ctrl->delta);
    }

    TestType = cb->hdr.TestType;

    // Here goes the init for the HW register structure 
    MemSet (hw, 0, sizeof(HWREGS)); 
    // Non Zero defaults 
    hw->AdcClk = SW_ON;
    hw->MeasRange2.scale.atten = ATTEN_100 ; // 100V scale
    hw->MeasRange1.scale.atten = ATTEN_100 ; // 100V scale
    hw->MeasSource1.dat = hw->MeasSource2.dat = PX_HI_AGND|PX_LO_AGND;
    hw->Stim0HfComp230Khz = SW_ON;
    hw->Stim1HfComp230Khz = SW_ON;
    hw->AcCtrl = HW->AcCtrl;	/* save current AC outlet status */
    

    /* setup the hardware for the 1st measurement */    

    // execute the setup phase    
    su_func[TestType].setup(cb , su, hw );

    if (g_err != 0 )
        return AHC_ERROR;
    return AHC_OK;
}

int    /* returns AHC_OK or AHC_ERROR */
store_exec( AHC_COMM_BUF *cb, SETUP *su , HWREGS *hw)
{
    set_relays( &cb->hdr, su, hw );
    Execute ( &cb->hdr, &cb->resp, su, hw, NULL,0);
    return AHC_OK;
}    

/*************************************************************************
 *  Given a pointer to the setup data, the purpose of UnSetup() is to
 * 1. Discharge large DUT caps using DC charge rate measurement.
 * 2. In TV tests > 3v, wait ~3ms for the DUT to be disconnected
 *    and the backplane capacitance to be discharged by the test
 *    hardware.
 * 3. Reset test hardware setup.
 */

int    /* returns AHC_OK or AHC_ERROR */
       /* clear setup after measurement */
UnSetup (  )
{
    // in case Stims where not turned off yet
    Dac1Ctrl->up = Dac0Ctrl->up = 0;


    // wait out the termination of stim
    while ( Dac0Ctrl->delta || Dac1Ctrl->delta);
                                                       
//     HW->Listen = SW_ON;         // measurment probe                                          
    TMR0wait (); // delay for stim settling to zero V, timer set in Exec()
    BoardInit();  /* reset all relays */

    /* start the global timer running to time relay opening
     * wait on timer in next Setup/hwConfig before setting relays    
     */    

    TMR0start(TMR_RELAYS_OPEN);

    return AHC_OK;
}

