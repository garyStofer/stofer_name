/* File: main.c
 * $Revision: 1.3 $
 * Gary Stofer
 *
 * Main PIXI control loop, initialization functions, Host-PC support functions
 * Target: TI 320C31 DSP processor, compiler TI C30 C compiler version 4.6+
 *
 *
 */


#include <math.h>       /* for sqrt() and HUGE_VAL */
#include <string.h>     /* for NULL */
#include <setjmp.h>
#include "util.h"       /* for MAX() and PI */
#include "prismapi.h"    /* for communications buffer definition */
#include "pixi_reg.h"   /* for PIXI register definitions */
#include "int3.h"       /* for INT3 ISR interface definition */
#include "setup.h"      /* for SETUP structure definition */
#include "tmr.h"        /* for TMR_RELAYS def */
#include "wavtable.h"   /* for TIMER1_ISR_VERS definition */
#include "execute.h"    /* for execute prototype definitions */

#include "pixi_glo.e"

#include "setup.p" 

extern void MemSet( void *, int, int);     // From IEEE.asm  -- faster then lib function
extern void MemCpy( void *, void *, int); // From IEEE.asm  -- faster then lib function


// global for longjump out of int3.c file 
jmp_buf mainenv;       /* buffer to store context for longjmp */

/*************************************************************************
 * BoardInit - reset regs and set compliance
 */
void BoardInit(void)
{
    int i,j;
    unsigned ac_status;
    
    STIM_ISR_OFF();
    
    // Prism Reset NOTE:  IMPORTANT !!
    // When executing a prism reset as below the RAM behind the registers does not get cleared
    // therefore we can restore items such as the AC control by simply re-writing itself, 
    // This also can cause much confusion when looking at the *HW structure in between an 
    // UnSetup() and set_relays() where *HW gets memcpy'ed. 
    
    //The following work around is neccessary to make sure we are disconnecting the remote Gs first
    // before Fs is removed. Otherwise there is a potential for sending Vmoa to the rail while it is
    // still connected to the DUT. This causes an over current situation (spike >1A ) between E and G
    
    if (g_PrismHwRev <= 7 && HW->MoaConnect.bit.Moa_p_In == M_p_GS )
    {
        HW->MoaConnect.bit.Moa_p_In  = M_p_AGND ; // Program to local sense first before disconnecting 
        TMR0delay (TMR_RELAYS_OPEN);
    }
    
    PXregOut (PX_REG_RESET, PX_ALL);   	   /* clear all PIXI registers, Note: RAMback is not cleared */
    // alternate form of reset via memset for debugging  -- also clears register readback ram
//  memset(HW, 0, sizeof(HWREGS));
    HW->AcCtrl = HW->AcCtrl;               /* restore status after reset, see note above */
    HW->MoaCmplnc.limit = V_Lim_0_7v;      /* default compliance level */
    HW->SampleClkSel = PX_INTRNL_CLK; 
    
    // THis has to be rev specific to brds with direct Squelch connection.
   if (g_PrismHwRev  > 7 )
    {
       HW->SqArm = HW->Squelch = 1;           // depends on ECO to wire K100 to MoaInvIn
       HW->MoaCompSlow = 1;   // to get the comp cap discharged as  well
    }

    /* for the Msig output, so it doesn't float up/down */
    HW->MeasSource1.dat = PX_HI_AGND|PX_LO_AGND;
    HW->MeasRange1.dat = PX_3V;

}
// ADC_TRIM sets up and executes a TV measurment on the 100V range with the inputs conneced to 
// analog ground inside the PRISM. It figures out the ADC offset at zero Volt input and saves this
// value in the global g_adc_offset. Later during Vmeas this value gets subtracted from the ADC-values
// for all measurments.
// ADC_TRIM is beeing called as part of the SysParamInit call from the PC, which in term is beeing
// called as part of the boot_tsr function which cheks if the prism is responding. This happens 
// once per program run as initialed out of the RUN interpeter loop. It also gets called out of the
// Setup Save menu item and in various other places. -- Use Setup/Save for debugging of this code 
// since it doesn't cause a Prism image reload because of a timeout when called from boot_tsr. 

static void
Auto_ADC_Trim ( void )
{
    AHC_TV_PARAMS *p = &CB->dat.Su1.param.tv;
	float V;

    float scale_gain ;
    	union {
		struct MeasOpt bit;
		unsigned long dat;
	} option;


   
    CB->hdr.Softconnect =0;
    CB->hdr.KeepStim = 0;
    CB->hdr.TestType = AHC_TV;

    option.dat = 0;
    option.bit.LineRej = 1;
    CB->dat.Su1.option = option.dat;
    CB->dat.Su1.pole.StimSense = AHC_AT_PRISM_SENSE;
    CB->dat.Su1.pole.MeasSense = AHC_AT_PRISM_SENSE;
    CB->dat.Su1.pole.GuardSense = AHC_AT_DR_SENSE;
    p->High = 50.0;  // place the scale input to highests scale i.e. 10 K to gnd  
    p->Low =  -50.0;  
    p->MeasType = AHC_DC;
    p->Meas_In= MEAS_IN_FPOLE;     
    p->Wait = 1;
    p->ACcoupleTime = 0;
    p->Averaging = 1;
    p->Sampling = 1;   // using line-reject      

    g_adc_offset = 0; 
    /* Setup for TVSV */    
    Setup( CB, &SwSetup, &HwSetup,0);
	// Connect the Hi input to analog ground  -- Low input already at GND by MEASI_IN_FPOLE
    HW->MeasSource1.src.Hi_In = H_AGND;
    
    StartWaveTable(&SwSetup);
    V = Vmeas( &SwSetup);

       
    scale_gain = PX_ADC_3V_MULT * ADC_RNG(HW->MeasRange1.dat);
    g_adc_offset = V / scale_gain;      // divide the voltage by the scale factor to find the ADC offset bit value 
    
    
    // limit to a max of 70 counts.
    
    if (g_adc_offset > 70 )
        g_adc_offset = 70;
    else if ( g_adc_offset < -70 )
        g_adc_offset = -70;
             
    CB->resp.result = C3XtoIEEE (V / scale_gain);
    CB->resp.MeasUnits = ' ';

    UnSetup( );

	
}


static void
SysParamIni ( AHC_COMM_BUF *cb )
{
    AHC_SYS_PARAMS   *p = &(cb->dat.Su1.param.sys_params);

    g_sysLineFreq = (float) p->LineFreq;
    g_sysR 	= p->sysR;
    g_sysR3W = p->sysR3W;
    g_sysCbp = p->sysCbp;
    g_sysL 	= p->sysL; 
    g_PrismHwRev = p->PrismHwRev;
}


/***************************************************************************
 * InitSinTable
 * called only once on power-up
 * init 6000 pt wave table data with one cycle sine
 * init 8 point (12.5 kHz) tables used in bridge mode
 */
void
InitFixedSinTable(void)
{
    register int k;
    register float xf, yf;

    asm (" AND 0FFFh, ST; set GIE = 0");    /* disable interrupts */

    /* init 8000 pt wave table data with one cycle sine, normalized to 1V */
    xf = PI2/(float)AHC_AC12Hz;
    for(k=0, yf=0.0; k < AHC_AC12Hz;  k++, yf+=xf)
        wav_tabl_A[k] = sin(yf) * PX_DAC_10V_BITS;

    /* init 6000 pt wave table data with one cycle sine, normalized to 1V */
    xf = PI2/(float)AHC_AC16Hz;
    for(k=0, yf=0.0; k < AHC_AC16Hz;  k++, yf+=xf)
        wav_tabl_B[k] = sin(yf) * PX_DAC_10V_BITS;

    // make sine and co-sine look up table for bridge mode, so we don't have 
    // to compute sine and cosine factors each time in bridgeVmeas
    for(k=0 ; k < AHC_AC16Khz;  k++)
    {
        g_sin6[k] = sin( k * PI2/AHC_AC16Khz); /* real part */
        g_cos6[k] = cos( k * PI2/AHC_AC16Khz); /* imag part */
    }

    asm (" OR 2000h, ST; set GIE = 1");    /* enable interrupts */
}



/*************************************************************************
 * TrimSetup
 */
static void 
PhaseTrimSetup(void )
{
    AHC_TVSV_PARAMS *p = &CB->dat.Su1.param.tvsv;

    CB->hdr.Softconnect =0;
    CB->hdr.KeepStim = 0;
    CB->hdr.TestType = AHC_TVSV;

    CB->dat.Su1.option = 0;
    CB->dat.Su1.pole.StimSense = AHC_AT_DR_SENSE;
    CB->dat.Su1.pole.MeasSense = AHC_AT_DR_SENSE;
    CB->dat.Su1.pole.GuardSense = AHC_AT_DR_SENSE;

    p->High = .2;    
    p->Low =  -.2;  
    p->CommonModeV = 0;
    p->MeasType = AHC_RMS;
    p->DualStim = 1;
    p->Stim0Type= AHC_AC16Khz;
    p->Stim0Res= PX_R0; 
    p->Stim0 = -AHC_LC_STIM_V;
    p->Stim1Type= AHC_AC16Khz;
    p->Stim1Res= PX_R0;     
    p->Stim1 = AHC_LC_STIM_V;
    p->Meas_In= MEAS_IN_FPOLE;
    p->Wait = 0;
    p->ACcoupleTime = 0;
    p->Averaging = 1;
    p->Sampling = 5;            // changed later

    /* Setup for TVSV */    
    Setup( CB, &SwSetup, &HwSetup,0);

    /* force unnormal TVSV setup for auto phase  */
    HW->Stim0HfComp230Khz = 0;
    HW->Stim1HfComp230Khz = 0;
    // no connection from either stim , changed later
    HW->Stim1_OutSel.dat =0;
    HW->Stim0_OutSel.dat = 0;
    
    CB->resp.result = -99.99; // in case we abort somewhere along the line
    CB->resp.MeasUnits = ' '; 



}

static AC_Trim_reset( void) // resets the pk_factor table to all  hadrd coded values, 
{							// so Diags can measure flatness of Stim and measure filters
	int ACperiod;
	float g_acpk_factor;

	for (ACperiod = 0;	ACperiod < AHC_AC1250Hz;ACperiod++ )
	{
		if (ACperiod <=5)
            g_acpk_factor= 1.075;
        else if (ACperiod == 6)
            g_acpk_factor= 1.054;
        else if (ACperiod == 7)
            g_acpk_factor= 1.042;
        else if (ACperiod == 8)
            g_acpk_factor= 1.032;
        else if (ACperiod == 9)
            g_acpk_factor= 1.025;
        else if (ACperiod < 15)
            g_acpk_factor= 1.0100 + (.0024 * (15-ACperiod));
        else if (ACperiod < 20)
            g_acpk_factor= 1.0052 + (.00096 * (20-ACperiod));
        else if (ACperiod < 30)
            g_acpk_factor= 1.0025 + (.00027 * (30-ACperiod));
        else if (ACperiod < 40)
            g_acpk_factor= 1.0015 + (.0001 * (40-ACperiod));
        else if (ACperiod < 50)
            g_acpk_factor= 1.0009 + (.00006 * (50-ACperiod));
        else if (ACperiod < 60)
            g_acpk_factor= 1.0006 + (.00003 * (60-ACperiod));
        else if (ACperiod < 70)
            g_acpk_factor= 1.0004 + (.00002 * (70-ACperiod));
        else if (ACperiod <= 80)
            g_acpk_factor= (1.0003 + (.00001 * (80-ACperiod)));

		s0_pk_factor[ACperiod] = g_acpk_factor;
		s1_pk_factor[ACperiod] = g_acpk_factor;
 	}
}
  

// Calibrates the ADC error for the precalculated AC stims 
static void 
AutoACTrim(void )
{
    int i,j;
    float V;
    STIM *st;
    float *pk_fct;


    AHC_TVSV_PARAMS *p = &CB->dat.Su1.param.tvsv;

    CB->hdr.Softconnect =0;
    CB->hdr.KeepStim = 0;
    CB->hdr.TestType = AHC_TVSV;

    CB->dat.Su1.option = 0;
    CB->dat.Su1.pole.StimSense = AHC_AT_PRISM_SENSE;
    CB->dat.Su1.pole.MeasSense = AHC_AT_PRISM_SENSE;
    CB->dat.Su1.pole.GuardSense = AHC_AT_DR_SENSE;
    p->High = .2;    
    p->Low =  -.2;  
    p->CommonModeV = 0;
    p->MeasType = AHC_RMS;
    p->DualStim = 1;
    p->Stim0Type= AHC_AC125Hz;      // So we use a Pk_fact of 1.0 for this cal !! IMPORTANT !!
    p->Stim0Res= PX_R0; 
    p->Stim0 = AHC_LC_STIM_V;
    p->Stim1Type= AHC_AC125Hz;
    p->Stim1Res= PX_R0;     
    p->Stim1 = AHC_LC_STIM_V;
    p->Meas_In= MEAS_IN_EPOLE;      // Will switch between Ed and Es during measure
    p->Wait = 0;
    p->ACcoupleTime = 0;
    p->Averaging = 1;
    p->Sampling = 2;       // Cycls or at least 800us  


    /* Setup for TVSV */    
    Setup( CB, &SwSetup, &HwSetup,0);

    for (j = 0; j < 2 ; j++ )   // for both stims
    {
        if (j == 0 )
        {
            st = &SwSetup.s0;
            pk_fct = s0_pk_factor;
        }
        else
        {
           st = &SwSetup.s1;
           pk_fct = s1_pk_factor;
           HW->MeasSource1.dat = PX_HI_ES | PX_LO_AGND;
           TMR0start (TMR_RELAYS);
        }

        for (i= 5 ; i <=80  ; i++ )    // calibrate stims from 1.25Khz to 20 Khz
        {
            st->len = st->prd = i;
            SwSetup.samples = ACsamples(st->len , p->Sampling);
            StartWaveTable(&SwSetup);
            V = Vmeas( &SwSetup);
            pk_fct[i] = AHC_LC_STIM_V / (SQRT2 * V);
        }
    }
    UnSetup( );
}

/************************************************************************
 * AutoPhaseTrim  trims phase offset of Stim1
 */


void
check_phase( SETUP *su, int adc_delay, float *rad, float *deg, int cycles )
{
    float rms,dc,av0,C,S; 
    int samples = su->samples;

    // 1250 == max sampling number of samples for buffer size  in Bridgemeas
    if ( cycles > 1250 )
        cycles = 1250;

    su->samples = cycles * su->s0.prd;
    BridgeVmeas( 4, adc_delay, su, &av0, &dc, &rms, &S, &C );  
    *rad = atan( C/S );
    *deg = *rad/PI2*360;
    su->samples = samples;
}    

/* 
 Measure the required phase offset for stim1 to be exactly in sunc with stim 0
 This is done by connecting the Stim to be examined and the volt meter to the F pole. 
 Then we let the stim run and measure phase relative to the ADC clock. The ADC 
 clock has been alinged with S0 in the previeous AutoDealayTimePerRx() to within 
 30ns.  

 We measure phase for S1 and keep the  found value in radians for later compensation 
 when generating a precise wavetable. Stim1 is examined at 200mv ( 4V at DAC) out
 put voltage.

 */
static float
AutoPhaseTrim(SETUP *su)
{
    float rad,deg;

    deg = 99.9;

    // connect Stim 1 to the measure pole 
    HW->Stim1_OutSel.dat = PX_S1_Fd;
    HW->Stim0_OutSel.dat = 0;                    // Stim0 not connected

    InitSineTable( &su->s1, Dac1Ctrl,  0.0);     // Run with 0.0 phase trim to find it
    HW->MeasSource1.src.Hi_In=H_FD; 
    TMR0delay (TMR_RELAYS);
    check_phase( su, g_adc_delay, &g_stim1_trim, &deg, 1250 );
    
    if ( g_err )
        return deg; 

    // connect Stim 0 to the measure pole 
    HW->Stim1_OutSel.dat = 0;                    // Stim1 not connected 
    HW->Stim0_OutSel.dat = PX_S0_Fd;             // Stim0 to Fd

    InitSineTable( &su->s0, Dac0Ctrl,  0.0);     // Run with 0.0 phase trim to find it
    HW->MeasSource1.src.Hi_In=H_FD; 
    TMR0delay (TMR_RELAYS);

    check_phase( su, g_adc_delay, &g_stim0_trim, &deg, 1250 );
    InitSineTable( &su->s0, Dac0Ctrl,  g_stim0_trim);    
    check_phase( su, g_adc_delay, &rad, &deg, 1250 );
    g_stim0_trim += rad;
    InitSineTable( &su->s0, Dac0Ctrl, g_stim0_trim);    
    check_phase( su, g_adc_delay, &rad, &deg, 1250 );
    g_stim0_trim += rad;


    deg = fabs(g_stim0_trim - g_stim1_trim );
    deg = deg / PI2 * 360;                       // in degrees
    CB->resp.result = C3XtoIEEE(deg);            // in degrees
    // could not trim 
    return deg;
}



// AutoDelayTrim  trims measure clock delay setting
// rough delay 30ns equals 0.180deg at 16.6Khz
static void
AutoDelayTrim(SETUP *su)
{
    int min_trim,i,end;
    float rms,dc,av0,S,C, minv = 9999.9;
    int m_delay;
    float *fp, *f;
    float avg;
    int avg_sample;
    int start_delay = 1780; // == 54 uS
    float deg, rad;


    // only connect Stim 1 
    HW->Stim1_OutSel.bit.Fd = SW_ON;
    TMR0delay (TMR_RELAYS);

    // start with 0.0 deg trim on Stim1
    InitSineTable( &su->s1, Dac1Ctrl, 0.0);


    // temp float arry to hold result for each measured 30ns step
    // make arry the max size and then fill it just where we sweeping 
    f = (float* ) malloc(DELAY80us * sizeof(float));

    i = min_trim = 0;

    // start 5us below expected delay
    start_delay -= (DELAY10us / 2); 
    fp = f + start_delay;
    for (m_delay = start_delay; m_delay < DELAY80us; m_delay++ )
    {
        if ( BridgeVmeas( 3, m_delay, su, &av0, &dc, &rms,&S,&C) != 0)
            break;  

        // detect when the cosine is changing sign. == 0 deg
        *fp++ = C;

        // roughly find the zero crossing 
        if (C >= 0.0)
        {
            // if the last step was also below zero
            if (min_trim == m_delay - 1 )
                i++;

            min_trim = m_delay;

            // after n consecutive readings on the negative side
            if (i == 20 )
               break;
        }
    }

    end = m_delay;
    m_delay -= 40;
    if (m_delay < 0 )
		m_delay = 0;

    // find the exact mimimum in the stored data 
    avg_sample = 7; // has to be an odd number to get a midpoint 
    for ( fp = f + m_delay; m_delay < end - avg_sample; m_delay++, fp++)
    {
        // linear average of n_samples (This is around the 0 crossing )
        avg = 0.0;
        for (i =0; i < avg_sample ;i++ )
	        avg += *(fp + i);

        avg = fabs (avg / avg_sample);

	    if ( avg < minv )
        {
             minv = avg;
             min_trim = m_delay + avg_sample/2; // report the midpoint
        }    
    }

    g_adc_delay = min_trim;
    free(f);
}


/****************************************************
 *  AutoTrim()  measure on-board stim phase offset, measure delay, & line freq
 *              if cannot trim stim1 phase sufficiently then set g_err error
 */
static void
AutoTrim( void)
{
    int i,j;
    float trim_val;
   
    AutoACTrim();
    if (g_err )
	    return; 
      
    PhaseTrimSetup( );
    AutoDelayTrim(&SwSetup);  /* measure delay trim */

    if (! g_err)     // e.g. AER_NO_DMA_ADC_CLK
    {                
       trim_val = AutoPhaseTrim(&SwSetup);
      
       if ( ! g_err  )
       {
            if ( trim_val > 5.0 )
                g_err = AER_NO_PHASE_TRIM; 
       }
       
    }

    UnSetup( );


}


static int
c_mem_test( void )
{
  int i;
  int *cb;
  int mem_err = 0;
  int pat1[] = {0x55555555,0xaaaaaaaa };

    cb = (int *) &comm_buf;
    MemSet (cb, 0, sizeof(AHC_COMM_BUF)); 
    for (i = 0;i < sizeof(AHC_COMM_BUF); i++)
        *cb++ = pat1[i % 2];

    cb = (int *) &comm_buf;
    for (i = 0;i < sizeof(AHC_COMM_BUF); i++)
    {
		if (*cb++ != pat1[i % 2])
            mem_err++;
    }
    
    if (mem_err )
        return(AER_COMM_MEM_FAIL);
    else
        return(0);

    
}    

static int
m_mem_test( void )
{
  int i;
  int *cb;
  int mem_err = 0;
  int pat1[] = {0xaaaaaaaa, 0x55555555 };

    cb = (int *) 0x20000;   // upper half of main memory 
    MemSet (cb, 0, 0xffff); 
    for (i = 0;i < 0xffff; i++)
        *cb++ = pat1[i % 2];

    cb = (int *) 0x20000;   // upper half of main memory 
    for (i = 0;i < 0xffff; i++)
    {
		if (*cb++ != pat1[i % 2])
            mem_err++;
    }
    
    if (mem_err )
        return(AER_MAIN_MEM_FAIL);
    else
        return(0);
    
}    

// Don't initialize or else it will be reset each time c_int00 is running.
// Initialized to 0 by the initial image load
int reset_cnt;
/****************************************************
 *  main - loop forever loop forever loop forever loop forever loop
 */
main()
{
    reset_cnt++;
    asm (" AND   0h, IE; clear all CPU and DMA interrupts ");

    g_adc_offset = g_PrismHwRev = g_err = 0;
    g_err = m_mem_test();
    if (!g_err)
        g_err = c_mem_test();

    if (!g_err)
    {
        CB = &comm_buf;	// init Cb ptr
        CB->resp.sw_rev_num = C3XtoIEEE (PRISM_SW_REV);

        ISRLoadOnChip();                  /* copy isr code to on-chip ram */
        InitFixedSinTable();              /* fill sin wavetables */
        BoardInit();

        asm (" OR 0100h, IE; Enable CPU TINT0 ");
        asm (" OR 2800h, ST; set GIE = 1");    /* enable interrupts + cache */
        asm (" OR 0108h, IE; Enable CPU INT3 for PC i/o, CPU TINT0 for delay");
    }

    if (g_err)
        CB->resp.ahcerrno = g_err;

    CB->resp.pass_fail = AHC_PASS;

    // Start-up complete -- indicate to PC failures or pass 
    INT3done = 0;    
    PX_PCdone();   

    if(setjmp(mainenv)) /* return point if test aborted */
    {
        BoardInit();
        asm (" OR 0108h, IE; Enable CPU INT3 for PC i/o, CPU TINT0 for delay");
        asm (" OR 2800h, ST; set GIE = 1");    /* enable interrupts + cache */
    }


    for (;;)    // main poll loop
    {
        INT3done = 0;     /* done servicing PC request */
        PX_PCdone();      /* send initialization DONE interrupt/trigger to PC */


        while (!INT3done)
            ;      /* wait for a PC request */

        PX_INT3clr (INT3done);    /* clear INT3 interrupt from PC */


        CB->resp.ahcerrno = g_err = 0;   /* initialize error indicators */
        CB->resp.pass_fail = AHC_OK;     /* initialize return value */

        switch (CB->hdr.ExeType) /* dispatch function */
        {
			case AHC_AC_TRIM_RESET:
				AC_Trim_reset( );
				break;

            case AHC_AUTO_TRIM:
			  	AutoTrim( );
                break;
            
            case AHC_SYSPARAM:
                /* save communications buffer global test data */
                IEEEtoC3Xar(CB->dat.Su1.param.flt_arry.flt, FLT_ARRY_SZ-1); 
                SysParamIni (CB); 
                Auto_ADC_Trim();
                break;

            case AHC_ADCTRIM:
                /* do the ADC trim only -- used in Diags */
                Auto_ADC_Trim();
                break;


            case AHC_SETUP:
                IEEEtoC3Xar(CB->dat.Su1.param.flt_arry.flt, FLT_ARRY_SZ-1); 
                Setup (CB, &SwSetup ,&HwSetup,0);
                break;

            case AHC_EXECUTE:
                Execute (CB, &SwSetup, &HwSetup, NULL,0);
                break;

            case AHC_UNSETUP:
                UnSetup ();
                break;

            case AHC_SETUP_EXEC:
                IEEEtoC3Xar(CB->dat.Su1.param.flt_arry.flt, FLT_ARRY_SZ-1); 
                Setup (CB, &SwSetup ,&HwSetup,0);
                Execute(CB, &SwSetup, &HwSetup, NULL,0);
                break;

           

            case AHC_SAVE_SETUP:
                MemCpy( &CB->dat.SuHw.sw, &SwSetup, sizeof( SETUP ));
                MemCpy( &CB->dat.SuHw.hw, &HwSetup, sizeof( HWREGS ));
                break;

            case AHC_STORE_EXEC:
                store_exec( CB, &CB->dat.SuHw.sw, &CB->dat.SuHw.hw);
                break;

            case AHC_COMM_TEST:
                c_mem_test;
                break;
                
            case AHC_MAIN_TEST:
                m_mem_test;
                break;   
                
            case AHC_TMR_START:
                TMR0start ( CB->dat.Su1.param.dly.wait);    
                break;   
                  
             case AHC_DELAY:
                TMR0delay(CB->dat.Su1.param.dly.wait);
                break; 
                   
            case AHC_TMR_WAIT:
                TMR0wait();
                break;  
                
            case AHC_TMR_STOP:
                TMR0Stop();
                break;    
                
            default:  /* invalid test type received, should never happen */
            g_err = AER_INVALID_TEST_TYPE;
        }

        if (g_err) /* a fatal error occurred somewhere along the line */
        {
            CB->resp.ahcerrno = g_err;
            CB->resp.pass_fail = AHC_ERROR;
        }
    } /* end of forever */
} 

