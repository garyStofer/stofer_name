/* File: int3.c - INT3 & Timer 0 interrupt service routines
 * $Revision: 1.1 $
 * Gary Stofer
 */

#include <setjmp.h>
#include <dma30.h>      /* for on-chip DMA register defintions */
#include "prismapi.h"    /* for communications buffer definition */
#include "ahc_bnds.h"   /* for parameter bounds */
#include "pixi_reg.h"   /* for PIXI register definitions */
#include "setup.h"      /* for SETUP structure definition */
#include "tmr.h"        /* for timer definitions */
#include "util.h"       /* for MAX() */
#include "wavtable.h"   /* for cont_stims */

#include "pixi_glo.e"

extern int g_err;  /* global error number */
extern jmp_buf mainenv;

int INT3done;      /* TRUE = PC request pending */
int TINT0done =1;     /* TRUE = Timer 0 interrupt/init to 1 for startup wait_for timer */
int int02done=0;
int int03done=0;
int int04done=0;
int int05done=0;
int int06done=0;
int int09done=0;
int int0Adone=0;
int int0Bdone=0;


/*
 * The next three assembly language instructions tell the linker to
 * place the address of the interrupt service routine in the vector
 * table at the beginning of main memory.
 *
 * NOTE watch out for -o optimizer corrupting code with inline asm
 * directives don't use -o with inline asm code to be safe.
 */

asm("  .sect  \".int02\"");  /* Locate next statement in vector table.  */
asm("  .word  _c_int02 ");   /* Inserts vector to interrupt routine.    */
asm("  .text           ");   /* Put rest of code in ".text" section.    */

void c_int02()  /* INT1 - not used (ADC busy??) */
{
    ++int02done;
    return;
}


asm("  .sect  \".int03\"");  /* Locate next statement in vector table.  */
asm("  .word  _c_int03 ");   /* Inserts vector to interrupt routine.    */
asm("  .text           ");   /* Put rest of code in ".text" section.    */

void c_int03()  /* INT2 - unused (external trigger)*/
{
    ++int03done;
    return;
}



asm("  .sect  \".int04\"");  /* Locate next statement in vector table.  */
asm("  .word  _c_int04 ");   /* Inserts vector to interrupt routine.    */
asm("  .text           ");   /* Put rest of code in ".text" section.    */

void c_int04()  /* INT3 - PC Interrupt Service Routine */
{
    if (INT3done)
        if (CB->hdr.ExeType != AHC_UNSETUP)
            g_err = AER_PC_OVRD;    /* PC request override (>1 at a time)
                                 * no error if Unsetup occurs since may be    
                                 * an abort condition    
                                 */    
    else /* is abort condition so longjmp back to main */
        longjmp(mainenv, AHC_ABORT);


    INT3done = 1;
    ++int04done;              /* for debugging */
}

asm("  .sect  \".int05\"");  /* Locate next statement in vector table.  */
asm("  .word  _c_int05 ");   /* Inserts vector to interrupt routine.    */
asm("  .text           ");   /* Put rest of code in ".text" section.    */

void c_int05()  /* XINT0 - unused */
{
    ++int05done;
    return;
}


asm("  .sect  \".int06\"");  /* Locate next statement in vector table.  */
asm("  .word  _c_int06 ");   /* Inserts vector to interrupt routine.    */
asm("  .text           ");   /* Put rest of code in ".text" section.    */

void c_int06()  /* RINT0 - unused */
{
    ++int06done;
    return;
}


/* int07+08 reserved on C31 - no 2nd serial port */


asm("  .sect  \".int09\"");  /* Locate next statement in vector table.  */
asm("  .word  _c_int09 ");   /* Inserts vector to interrupt routine.    */
asm("  .text           ");   /* Put rest of code in ".text" section.    */

void c_int09()  /* Timer 0 Interrupt Service Routine */
{
    ++TINT0done;
    ++int09done;
}


asm("  .sect  \".int0a\"");  /* Locate next statement in vector table.  */
asm("  .word  _c_int0a ");   /* Inserts vector to interrupt routine.    */
asm("  .text           ");   /* Put rest of code in ".text" section.    */

void c_int0a()  /* TINT1 - unused */
{
    ++int0Adone;
    return;
}


asm("  .sect  \".int0b\"");  /* Locate next statement in vector table.  */
asm("  .word  _c_int0b ");   /* Inserts vector to interrupt routine.    */
asm("  .text           ");   /* Put rest of code in ".text" section.    */

void c_int0b()  /* DMA interrupt, reset dma regs for another loop */
{
    ++int0Bdone;
    g_dma_ctr -= MAX_ADC_DMA;

    if(g_dma_ctr <= 0) /* done with dma xfers */
    {
        g_dma_ctr = 0;
        return;
    }

    /* set up DMA control so reads from ADC and writes to memory array
     * inc write dest addr, read ADC on irq    
     */    
    DMA_ADDR->_gctrl._intval = INCDST | SYNC1 | TC | TCINT;
    DMA_ADDR->destination = g_dma_dest;

    if(g_dma_ctr > MAX_ADC_DMA)
        DMA_ADDR->transfer_counter =  MAX_ADC_DMA;
    else
        DMA_ADDR->transfer_counter =  g_dma_ctr;

    DMA_ADDR->_gctrl._intval |= START3;

    return;
}


