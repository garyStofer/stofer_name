// VPCIO.cpp - main module for VxD VPCIO			 $Revision: 1.2 $		 Gary Stofer
/*    	  
Functional description:
This VXD's purpose is to virtualize the PCI pcio hardware resources to the Virtual machine where
the 16bit dos devicedriver pcio.exe runs in. In order to accomplish this this VXD has to first detect 
which VM requests the hardware, then it has to reflect interrupts into that Virtual machine and map
the physical address range for the memory mapped IO to a virtual address space in the <1Mb space for 
that VM. Once a VM has connection to the HW further requests to connect to the HW by other VM's 
have to be denied until the VM holding the harware exits's, is beeing killed or otherwise ceases to 
exist. Nothe that this driver is purposly written so that it only supports a single instance of the 
IO card. This makes it so that only a single instance of the 18xx can run at a time. 

The following is a list of resorces this VXD deals with:

IO space of PCI: 	Used to get status and control the PCI aspects of the 9050 chip.
Memory space of PCI:Mapped to virtual address space in VM owning the HW 
Interrupt of PCI : Trapped in the VXD and reflected to the VM owning the HW. Also checks the card
				   to see if it interrupted, otherwise returns FALSE indicating to the system that
				   it should call the next handler. (sharing of interrupts)
Virtual IO 		 : Used to cennext wityh PCIO.exe, only visible in VM's

"Sequence of execution"
Upon loading of this deviedriver it gets called via it's entry point "OnSysDynamicDeviceInit(). This 
function scans the address space from C800 to efff, and then B000 to B7ff in search of a unassigned 
page of memory in the lower 1Mb address space. When an available 4kb slot is found it hooks 
the IO address of 0x300 for all subsequent VM's.
The next step in the initalization comes when the ConfigMG in windows sends a onPNPNewDevNode message 
to this driver requesting it to register a OnConfig() with it. Tyhe OnConfig() function the gets a 
start message in which the VXD makes arrangements to hook the interrupt given to this device. 

When a VM starts up and launches pcio.exe it makes a call to read from IO 0x300. The VXD has trapped        
this call and the port handler gains execution. It responds to the pcio.exe by sending back the page
addrress of the virtual low 1Mb address and actually mapping the physical PCI address space to it. It      
also sets the HWlock by assigning a the VM handle to the OwnerVM var.  With the memory mapped to
the specific VM in which pcio requested the HW and the Owner handle in place the interrupt service
routine knows to which VM the interrrupt is to reflect to the pcio is now free to do it's thing. 
When the VM holding the lock exits, either from a normal or forced exit the Owner VM gets unassigned 
and the resource becomes available for an other VM.
Should a second instance of the 18xx be started while the HW is already given away the VXD will not 
virtualize the Physicale address to the low 1Mb space and cause the pcio.exe ro read all 0xffff from the 
memort mapped space, indicating that there is now HW to talk to forcing it to go into SW only mode.

	  
 */  
// Begin of driver
#define DEVICE_MAIN
#include "../../include/vpcio.h"
Declare_Virtual_Device(VPCIO)
#undef DEVICE_MAIN
	
#define PCI_ENUM_FUNC_GET_DEVICE_INFO   0
#define PCI_ENUM_FUNC_SET_DEVICE_INFO   1

#define PLX_9050_STAT_REG 0x4c
#define PLX_9050_CTRL_REG 0x50
#define PLX_9050SW_RESET_BIT 0x40000000	
#define PLX_9050_INT1_ENA  0x43 

#define VIRT_PORT 0x300


#define PAGENUM(p)  (((ULONG)(p)) >> 12)
#define PAGEOFF(p)  (((ULONG)(p)) & 0xFFF)
#define PAGEBASE(p) (((ULONG)(p)) & ~0xFFF)
#define _NPAGES_(p, k)  ((PAGENUM((char*)p+(k-1)) - PAGENUM(p)) + 1)

// This driver only supports one instance of hardware and keeps one device context
static 	unsigned short Unit =0;	
static DEV_CTX *pDevCtx = NULL;  
static VpcioPort *p_Vport = NULL; 
static unsigned char vHwPg = 0;	    // The following vars are globals since they have to be reached by unrelated classes
static VMHANDLE OwnerVM = NULL;	    // the handle of the DOS VM who has the hardware
static DWORD	OwnerProc = 0;      // the process handel of the windows proc who has the hardware
static unsigned SwInt = 0;          // the number of the virtualized SW interrupt
static DOS_REGS DREGS;

// the EEprom stuff
static WORD EepromReadWord(UINT EpromConReg, UINT EpromAddr); 
static BOOL EepromWriteWord(UINT EpromConReg, UINT EpromAddr, WORD val); 

VpcioVM::VpcioVM(VMHANDLE hVM) : VVirtualMachine(hVM)  
{ /* Class Constructor 	*/
} 

VOID VpcioVM::OnDestroyVM()
{ 	
	dprintf("On VM Destroy");
    if ( pDevCtx != NULL )
    {
	    if ( getHandle() == OwnerVM )
	    {
		    OwnerVM = NULL; 
		    SwInt = 0;                                                                                                            
		    dprintf("hardware resources released due to VM_destroy");
	    }
    }
}  

VpcioInt::VpcioInt(int IRQ, DEV_CTX *ctx) :VSharedHardwareInt(IRQ, 0,0,0)
{
	m_pDevCtx = ctx;
	dprintf("Constructor for IRQ class virtualizing IRQ %d ", IRQ);
} 

BOOL VpcioInt::OnSharedHardwareInt(VMHANDLE hVM)
{	
	unsigned char Int_stat;	
	unsigned long pci_ctrl;	

	// check our card to see if it interrupted, bit 0x4 is Int1 status bit

	Int_stat = _inp( m_pDevCtx->IoBase + PLX_9050_STAT_REG) & 0x4; 
	if ( Int_stat )
	{ 
       	if ( OwnerVM == NULL )
		{	
			// Need to EAT the interrupt and make it go away since we can't assert it into a VM 
			// and send EOI too
			dprintf("Got an Interrupt but nobody owned the HW so I ate it ");
			pci_ctrl = _inpd( m_pDevCtx->IoBase + PLX_9050_CTRL_REG );	
			_outpd( pDevCtx->IoBase + PLX_9050_CTRL_REG, pci_ctrl | PLX_9050SW_RESET_BIT);
			_outpd( pDevCtx->IoBase + PLX_9050_CTRL_REG, pci_ctrl );

			sendPhysicalEOI(); 
		}
		else
			assert(OwnerVM);	

		return(TRUE);
	} 

	return(FALSE);
}

VOID VpcioInt::OnVirtualMask(VMHANDLE hVM, BOOL masked)
{	
	if ( ! masked )
		physicalUnmask(); 	
	else // This WM has masked the interrupt 
	{
		// maybe follow up with a Software reset to the card ??
	}

}	


/*  VOID VpcioInt::OnVirtualIRET(VMHANDLE hVM)	 { }   */

VOID VpcioInt::OnVirtualEOI(VMHANDLE hVM)
{
	sendPhysicalEOI(); 
	deassert(hVM);
}


// --------------------------------------------------------------------------------------------
VpcioThread::VpcioThread(THREADHANDLE hThread) : VThread(hThread) 
{ /* Class Constructor */
}

BOOL VpcioDevice::OnCreateVM(VMHANDLE hVM)
{	
	// dprintf("on VMCeate hVM = %x", hVM);
	return TRUE;
}

BOOL VpcioDevice::OnSysDynamicDeviceInit()
{  	
	unsigned char page;

	// for loop to search for a free page addreess between 0xc8 to 0xef then 0xb0 to 0xb7
	// if emm386 was used in config.sys a range must be excluded there with the "X=c800-c8ff" or
	// similar statement.

	vHwPg = 0;
	for ( page = 0xc8; page < 0xf0; page++ )
	{  
		if ( Assign_Device_V86_Pages( page, 1, 0, 0) )
		{
			vHwPg = page;
			break;
		}
	}												

	if ( vHwPg == 0 )
	{
		for ( page = 0xb0; page < 0xb8; page++ )
		{  
			if ( Assign_Device_V86_Pages( page, 1, 0, 0) )
			{
				vHwPg = page;
				break;
			}
		}
	}

	if ( vHwPg == 0 )
	{
		dprintf("Could not find a free HW page in low memory to vitualize PCIO HW into");
		return(FALSE);
	}


	if ( ( p_Vport = new VpcioPort(VIRT_PORT) )== NULL )
	{
		dprintf("Could not allocate V_port class");
		return(FALSE);
	}	

	if ( ! p_Vport->hook() )
	{
		dprintf("Vpcio could not hook Port address 0x300");
		return(FALSE);
	}

	return TRUE;
}

BOOL VpcioDevice::OnSysDynamicDeviceExit()
{
	dprintf("OnSysDynamic Driver Exit "); 
	if ( vHwPg != 0 )
	{	dprintf("Deassigning the virtual HW page  %x ", vHwPg);
		if ( !DeAssign_Device_V86_Pages(vHwPg, 1, 0, 0) )
			dprintf(" failed to de-assignepage %x ", vHwPg); 
	}

	p_Vport->unhook();
	delete p_Vport;					  

	return TRUE;
}			   

//********************************************************************************/
//********************************************************************************/
// function:        initialises allocated recources     
// called by:           configuration manager
// return value:        CR_SUCCESS, CR_FAILURE, CR_DEFAULT
DEBUG_CONFIG_NAMES	
 
void  OnConfigStop ( )
{	 
	unsigned long  pci_ctrl;
  
	// issue a SW reset to the PCI card
	// double writes to give some extra time
	// dprintf(" -- Issuing SW reset to pcio ");
	
	if (pDevCtx != NULL ) 
	{
		pci_ctrl = _inpd( pDevCtx->IoBase + PLX_9050_CTRL_REG );	
		_outpd( pDevCtx->IoBase + PLX_9050_CTRL_REG, pci_ctrl | PLX_9050SW_RESET_BIT);
		_outpd( pDevCtx->IoBase + PLX_9050_CTRL_REG, pci_ctrl | PLX_9050SW_RESET_BIT);
		_outpd( pDevCtx->IoBase + PLX_9050_CTRL_REG, pci_ctrl );
		// disbale interrupts at the pci interface
		_outpd( pDevCtx->IoBase + PLX_9050_STAT_REG, 0 );

		// unhoock the interrupt and destroy it's obj
		if ( pDevCtx->pVpcioInt != NULL )
		{  
			pDevCtx->pVpcioInt->unhook();
			delete pDevCtx->pVpcioInt;
			pDevCtx->pVpcioInt = NULL;
		} 

		if (pDevCtx->MemBaseLinear)
		{
			LinPageUnLock( PAGENUM(pDevCtx->MemBaseLinear),1,0);
			PageDecommit( PAGENUM(pDevCtx->MemBaseLinear),1, 0 );
			pDevCtx->MemBaseLinear = 0;
		   
	 	}

	}	
}

CONFIGRET CM_HANDLER OnConfigure(CONFIGFUNC cf, SUBCONFIGFUNC scf, DEVNODE devnode, DWORD refdata, ULONG flags)
{		

	CONFIGRET cr;
	CMCONFIG config;
	unsigned long dat0;
	unsigned long port;	 
	unsigned short DevId;  
	unsigned long  pci_ctrl;

if ( cf < NUM_CONFIG_COMMANDS )
	dprintf("V_PCIO: Config_handler msg %d: %s\n", cf, lpszConfigName[cf]);
else
	dprintf("OnConfig called invalid msg number %d\n", cf);	
 
	switch ( cf )
	{
	case CONFIG_START:
		{
			cr = CONFIGMG_Get_Alloc_Log_Conf(&config, devnode, CM_GET_ALLOC_LOG_CONF_ALLOC);
			if ( ! (cr == CR_SUCCESS  || cr == CR_DEFAULT) )
				return(cr);

			if ( config.wNumIOPorts < 1 ||
				 config.wNumIRQs != 1 ||
				 config.wNumMemWindows != 1 )
			{
				dprintf("Failing CONFIG_START for PCIO, did not get expected resources");
				return( CR_FAILURE);
			}

			// The following is a workaround for the 9050's chips problems of decoding the local config reg. space
			// when aligned at 0x80. When Configmg proc\vides such an addr. the chip doesn't decode for reads
			// To work around this we allocate via BAR3 a IO space of 256 bytes which will be allocated on a page
			// boundry. Then we copy the contents of BAR3 to BAR1 and keep the page aligned address in the device
			// context for use by other components of the driver.

			CONFIGMG_Call_Enumerator_Function( devnode,PCI_ENUM_FUNC_GET_DEVICE_INFO,
				0x2, &DevId, sizeof(DevId), 0);

			if ( config.wIOPortBase[0] & 0x80 && DevId == 0x9050 )	     // the port space is not page aligned, the 9050 
			{	 
				if ( config.wNumIOPorts != 2 )
				{ 
					nprintf("Pcio: Need page aligned IO space for 9050 chip");
					return(CR_FAILURE);
				}
				else
				{	 
					// copy BAR3 to BAR1 so that the device does a proper decode
					pDevCtx->IoBase = port = config.wIOPortBase[1];
					CONFIGMG_Call_Enumerator_Function( devnode,
						PCI_ENUM_FUNC_SET_DEVICE_INFO, 0x14, &port, sizeof(port), 0);
				}
			}
			else
				pDevCtx->IoBase = config.wIOPortBase[0];   
			// end of workaround

			// storing the device resources in the device context
			pDevCtx->Irq = config.bIRQRegisters[0];
			pDevCtx->MemBase = config.dMemBase[0];
			pDevCtx->MemSize = config.dMemLength[0]; 
			
			// mapping the hardware addres to global W32 space
			pDevCtx->MemBaseLinear = (ULONG) PageReserve( PR_SYSTEM, 1, PR_FIXED );
			PageCommitPhys(	PAGENUM(pDevCtx->MemBaseLinear), 1, PAGENUM(pDevCtx->MemBase), 
									 PC_INCR | PC_WRITEABLE | PC_USER );		
			LinPageLock(PAGENUM(pDevCtx->MemBaseLinear), 1, 0);
			dprintf("Physical memory mapped to linear addr =  %lx\n",pDevCtx->MemBaseLinear);



			// Fix up the interrupt enable setting in the EEprom to DISABLE so we don't 
			// get interrupts on power on of the board
			// other eeprom seetings might go here
		 	
		/*	   Disable for now until AOI's code does this as well      */
		//	if (EepromReadWord(PLX_9050_CTRL_REG, 0x2f) != 0)
		//		EepromWriteWord(PLX_9050_CTRL_REG, 0x2f, 0x0);	 
		 
		 	 
			dprintf("IRQ    : %d\n",pDevCtx->Irq);
			dprintf("IOBASE0 : %3.3Xh\n",pDevCtx->IoBase);	 
			dprintf("IOSize0 : %3.3Xh\n",config.wIOPortLength[0]);
			dprintf("MemBase : %x\n",pDevCtx->MemBase);
			dprintf("Memlenght : %x\n",pDevCtx->MemSize);  
		  	
			// creating interrupt class instance so we can hook  the interrrupt and reflect it to 
			// our VM
			pDevCtx->pVpcioInt = new VpcioInt(pDevCtx->Irq, pDevCtx);
			
			if ( pDevCtx->pVpcioInt == NULL )
				return (CR_OUT_OF_MEMORY );

			// issue a SW reset to the PCI card
			// double writes to give some extra time
			// dprintf("Issuing SW reset to pcio ");
			pci_ctrl = _inpd( pDevCtx->IoBase + PLX_9050_CTRL_REG );	
			_outpd( pDevCtx->IoBase + PLX_9050_CTRL_REG, pci_ctrl | PLX_9050SW_RESET_BIT);
			_outpd( pDevCtx->IoBase + PLX_9050_CTRL_REG, pci_ctrl | PLX_9050SW_RESET_BIT);
			_outpd( pDevCtx->IoBase + PLX_9050_CTRL_REG, pci_ctrl ); 
			// Enable interrupts at the PCI interface 
			_outpd( pDevCtx->IoBase + PLX_9050_STAT_REG, PLX_9050_INT1_ENA );

			/*	Enable this to print out the eeprom contents of the board
			WORD dta,dta2;
			int i;
			  
			for (i = 0;i <=0x30 ;i+=2 )
			{
			  	dta = EepromReadWord(PLX_9050_CTRL_REG, i);	
				dta2 = EepromReadWord(PLX_9050_CTRL_REG, i+1);
				dprintf( "EEPROM addr %2.2x = %4.4x:%4.4x \n", i*2, dta,dta2);	
			}
			*/

			if ( !pDevCtx->pVpcioInt->hook() )
			{
				dprintf("IRQ was not hooked");
				delete pDevCtx->pVpcioInt;
				return CR_CANT_SHARE_IRQ;
			}
			else
			{	
				pDevCtx->pVpcioInt->physicalUnmask();  
				pDevCtx->pVpcioInt->sendPhysicalEOI(); 
				dprintf("IRQ is now hooked ");
				return(CR_SUCCESS);
			}

			break ;
		}	  

	case CONFIG_TEST:
		if (pDevCtx != NULL )
		{
	        if ( OwnerVM != NULL ||OwnerProc != 0 )
		    {
			    dprintf("Failing ConfigTest: Hardware currently in use");  
			    return(CR_FAILURE);
		    }	
		}
		else
			return(CR_SUCCESS);
		break;

	case CONFIG_STOP:
		{	 
			OnConfigStop();
			return CR_SUCCESS;  
		} 
		 
		case CONFIG_REMOVE:
		{	
			OnConfigStop();
			Unit--;
			// destroy the one and only device context
			delete pDevCtx;							   
			pDevCtx = NULL;
			return CR_SUCCESS;  
		}
	default:
		return CR_DEFAULT;
	}

    return CR_DEFAULT;

}


CONFIGRET VpcioDevice::OnPnpNewDevnode(DEVNODE devNode, DWORD loadType)
{
	dprintf(" OnPnP new devnode : %xi - Loadtype %d", devNode, loadType);
	if ( loadType == DLVXD_LOAD_DEVLOADER )
	{
		if ( Unit == 0 )	// only support a single pcio card		
		{
			Unit++;
			if ( (pDevCtx = new  DEV_CTX) == NULL )
				return(CR_FAILURE);	  

			pDevCtx->pVpcioInt = NULL;
			pDevCtx->MemBaseLinear = 0;
		    
		    OwnerProc = 0;
            OwnerVM = NULL;	 

            // could be done in OnSysDynamicDeviceInit
 			if (!VEvent::initEvents())
				return CR_FAILURE;// fatal error
			
			return CONFIGMG_Register_Device_Driver(devNode, 
				OnConfigure, (unsigned long)pDevCtx, CM_REGISTER_DEVICE_DRIVER_REMOVABLE | CM_REGISTER_DEVICE_DRIVER_DISABLEABLE);
		}
		else
			return CR_FAILURE;
	}

	return CR_DEFAULT;
}

DWORD VpcioDevice::OnW32DeviceIoControl(PIOCTLPARAMS p)
{
	CONFIGRET status = DEVIOCTL_NOERROR; 
	IOCTL_GET_HW * io_dta;
    VSemaphore* pSema;
	MyVMEvent* pEvent;
	DOS_REGS * Dregs;

  	*p->dioc_bytesret = 0;   // returns are done via the in buffer

	switch ( p->dioc_IOCtlCode )
	{		 									  
		case DIOC_OPEN:   // would make sense to fail this if no device instance is present 
            break;  

            
		case DIOC_CLOSEHANDLE: 
		case IOCTL_V_PCIO_FREE_HW:

            
            if( pDevCtx != NULL )
            {
        	    dprintf("W32DIOC Close Handle or FREE_HW called\n");

        	    if (p->dioc_ppdb == OwnerProc)
			    {
			        dprintf("W32DIOC release the Owner Process\n");
				    OwnerProc = 0;
                }
			}
	
		  	break;

 		case IOCTL_V_PCIO_GET_SWINT:
			if ( p->dioc_cbInBuf < sizeof( DOS_REGS) )
				return DEVIOCTL_ERROR_INVALID_ARG;
			
 			Dregs =  (DOS_REGS *)(p->dioc_InBuf);
 			Dregs->x.ax = 0;
	
 		    if (OwnerVM )
				    Dregs->x.ax = SwInt;
          
			break;

 	   	case IOCTL_V_PCIO_LW_CALL: 
			if ( p->dioc_cbInBuf < sizeof( DOS_REGS) )
				return DEVIOCTL_ERROR_INVALID_ARG;	

			Dregs =  (DOS_REGS *)(p->dioc_InBuf);  
			// Have to copy this to pagelocked space for the event handler 
			memcpy( &DREGS, Dregs, sizeof(DOS_REGS));

            if (pDevCtx == NULL)
			    return DEVIOCTL_ERROR_NO_18XX_VM;

			if( OwnerVM == NULL || SwInt == 0 )	// if there is no running Z18xx VM
				return DEVIOCTL_ERROR_NO_18XX_VM;
	
		   //dprintf("W32DIOC call SW_int %d in -- Owner VM = %lx\n", SwInt, OwnerVM); 
		   	if ( pEvent = new MyVMEvent(OwnerVM, &DREGS) )		 // Events don't have to be deleted unless never called
			{	
				if (pEvent->pSema = pSema = new VSemaphore(0) )	// setup sync object
				{
					pEvent->call();	 			// call or schedule the VM event, returns async.
		  			pSema->wait(BLOCK_SVC_INTS);// Wait for the event to be processed -- the event handler signals 
					delete pSema;
		  	   	}
				else
					delete( pEvent);  
				// Copy it back to W32_DeviceIoBuffer
				memcpy( Dregs, &DREGS, sizeof(DOS_REGS));		
		   	}	
			break;

        case IOCTL_V_PCIO_GET_VERSION:
            if ( p->dioc_cbInBuf < sizeof( IOCTL_GET_HW) )
            {  
                dprintf("W32DIOC Get revision-- aborted  \n" );
                return DEVIOCTL_ERROR_INVALID_ARG;
            }

            io_dta =  (IOCTL_GET_HW *)(p->dioc_InBuf);
            io_dta->Err_code = 0;
            io_dta->Revision = VPCIO_Major << 16 | VPCIO_Minor;
            dprintf("W32DIOC Get revision called Rev: = %x\n", io_dta->Revision);
            break;

	    case IOCTL_V_PCIO_GET_HW:
			if ( p->dioc_cbInBuf < sizeof( IOCTL_GET_HW) )
				return DEVIOCTL_ERROR_INVALID_ARG;
            
            io_dta =  (IOCTL_GET_HW *)(p->dioc_InBuf);

            if (pDevCtx == NULL )
            {
                dprintf("W32DIOC Get Hardware failed -- No hardware instance\n");
                io_dta->Err_code = DEVIOCTL_ERROR_NoHwInst;
                return DEVIOCTL_ERROR_NoHwInst;
            }
            
			if (OwnerProc == 0  && OwnerVM == NULL )     // if not connected 
			{
				OwnerProc = p->dioc_ppdb;	

				io_dta->HW_mem_base = (PVOID) pDevCtx->MemBaseLinear;  
				io_dta->Err_code =0 ; 
				dprintf("W32DIOC Get Memmap  lin addr =  %lx\n",pDevCtx->MemBaseLinear);
			}
			else
			{
				io_dta->Err_code = status = DEVIOCTL_ERROR_18xxInUse;
                if (OwnerVM)
                
                    dprintf("W32DIOC Get Hardware failed -- Already in use by DOS VM %x\n", OwnerVM);
                else
				    dprintf("W32DIOC Get Hardware failed -- Already in use by process 0x%x\n",OwnerProc);
			}
			break;

	
		default:
			dprintf("W32DIOC IO_CTRL called %ld but not handled\n",p->dioc_IOCtlCode);
	 } 
     
     return status;
}

VpcioPort::VpcioPort( DWORD port_n) : VIOPort(port_n)
{
	// initialize other class members, if any
}


DWORD VpcioPort::handler(VMHANDLE hVM,DWORD port,CLIENT_STRUCT* pRegs,DWORD iotype,DWORD outdata)
{  
	if (OwnerVM != NULL)
		Resume_VM( OwnerVM);

	switch ( iotype )
	{
	case BYTE_INPUT:
		dprintf(" Handelr intercepted at %x a byte read", port);  
							 
		// failure of sequence, has not gotten a device address, can not map
		if (pDevCtx == NULL)
			return( 0xff);
			

		// The first VM who calls the IO port with a read is assigned the harware 
		// Ownership gets released when the VM which holds the HW gets destroyed
		if ( OwnerVM == NULL && OwnerProc == 0)
		{
			OwnerVM = hVM;	
			// map the Physical HW address trough to the virtual address for this VM only
			if ( ! PhysIntoV86(pDevCtx->MemBase >> 12, hVM, vHwPg, 1,0) )
				dprintf("Phys into V86 failed");			  			
			else 
				dprintf("Phys address  %x into V86VM at  page 0x%x succeeded ", pDevCtx->MemBase, vHwPg);

			// create a VM instance so we can intercept the disapperance of the CVM
			// to release the hardware should the rug get pulled from under it
			new  VpcioVM(hVM);

		}
		else
        {
            if( OwnerVM )
			    dprintf("Hardware already assigned to DOS VM %x ", OwnerVM);
            else
			    dprintf("Hardware already assigned to Windows Process 0x%x\n",OwnerProc);

        }
		return vHwPg;	// always return the page number to the caller 


	case BYTE_OUTPUT: 
		SwInt = outdata& 0xff;
		dprintf("Porthandler intercepted at %x a byte write -- SW int =0x%x", port, SwInt );
		break;
	}

	return(0);

}
 
MyVMEvent::MyVMEvent(VMHANDLE hVM, PVOID ref_dta) 
          : VPriorityVMEvent(hVM,CUR_RUN_VM_BOOST,ref_dta, 1000, PEF_TIME_OUT | PEF_WAIT_NOT_CRIT )
{
}
	
VOID MyVMEvent::handler(VMHANDLE hVM, CLIENT_STRUCT* pRegs, PVOID refData,BOOL bTimeOut)
{	
	// (now running in the context of specified VM)
	CLIENT_STRUCT saveRegs;
	VMHANDLE hcurr =  Get_Cur_VM_Handle();

   //	dprintf(">>> This is executed in the context of the Z18xx VM "); 
     dprintf(">>> VMhandle 0x%lx -- refData %ld -- timeout %d Curr VM_handle 0x%lx", hVM, refData, bTimeOut, hcurr);	   

	if (bTimeOut || hVM != hcurr) 
	{
		dprintf("The call to Z18xx timed out after 500ms -- Z18xx is set to Always suspend in Background");
 // set the error condition in the refdata struct   	
   		pSema->signal();
		return;	
	}
		
	Save_Client_State(&saveRegs);
  				                      
	//Begin_Nest_V86_Exec();
	Begin_Nest_Exec();

	pRegs->CRS.Client_EAX = ((DOS_REGS *)refData)->e.eax;
	pRegs->CRS.Client_EBX = ((DOS_REGS *)refData)->e.ebx;
	pRegs->CRS.Client_ECX = ((DOS_REGS *)refData)->e.ecx; 
	pRegs->CRS.Client_EDX = ((DOS_REGS *)refData)->e.edx;
   	pRegs->CRS.Client_ESI = ((DOS_REGS *)refData)->e.esi;
	pRegs->CRS.Client_EDI = ((DOS_REGS *)refData)->e.edi;
	pRegs->CRS.Client_EBP = ((DOS_REGS *)refData)->e.ebp;

	Exec_Int(SwInt);
	 
	((DOS_REGS *)refData)->e.eax = pRegs->CRS.Client_EAX; 
	((DOS_REGS *)refData)->e.ebx = pRegs->CRS.Client_EBX; 
	((DOS_REGS *)refData)->e.ecx = pRegs->CRS.Client_ECX; 
	((DOS_REGS *)refData)->e.edx = pRegs->CRS.Client_EDX; 
	((DOS_REGS *)refData)->e.esi = pRegs->CRS.Client_ESI;
	((DOS_REGS *)refData)->e.edi = pRegs->CRS.Client_EDI;
	((DOS_REGS *)refData)->e.ebp = pRegs->CRS.Client_EBP;
	End_Nest_Exec();		
  	
	Restore_Client_State(&saveRegs); 

	//dprintf(">>Returned eax 0x%lx", ((DOS_REGS *)refData)->e.eax );
	//dprintf(">>Returned ebx 0x%lx", ((DOS_REGS *)refData)->e.ebx );
	//dprintf(">>Returned ecx 0x%lx", ((DOS_REGS *)refData)->e.ecx ); 
	// dprintf(">>Returned edx 0x%lx", ((DOS_REGS *)refData)->e.edx );	  
		
	pSema->signal();  // indicate to the waiting thread that the handler has executed
	

}


#ifdef eepromcode
///////////////////////////////////  eeprom stuff   //////////////
 // EEPROM constant 
#define EE_ADDR_MASK 0x003f // for combining addresses with instructions  (WORD addresses)
#define EE_CMD_LEN 9 // bits in instructions 
#define EE_READ 0x0180 // 01 1000 0000 read instruction 
#define EE_WRITE 0x0140 // 01 0100 0000 write instruction 
#define EE_WREN 0x0130 // 01 0011 0000 write enable instruction 
#define EE_WDS 0x0100 // 01 0000 0000 write disable instruction 
#define EE_PREN 0x0130 // 01 0011 0000 protect enable instruction 
#define EE_PRCLEAR 0x0177 // 01 1111 1111 clear protect register instr
// EEPROM Functions 
		  
static BOOL EepromSendCmd(UINT cmd, UINT EpromConReg); 
static BOOL EepromClock(UINT EpromConReg);
 
void
WriteRtrDword(UINT EpromConReg, DWORD regval)
{
   _outpd( pDevCtx->IoBase+ EpromConReg, regval );
}

DWORD
ReadRtrDword( UINT EpromConReg )
{  
	return ( _inpd (pDevCtx->IoBase+ EpromConReg) );
}	


///////////////////////////////////////////////////////////////////////////// 
static WORD 
EepromReadWord(UINT EpromConReg, UINT EpromAddr) 	// (Word addresses)
{ // Return a word from National Semiconductor's NMC93S06/NMC93S46 EEPROM 
	WORD acc = 0x0; 
	UINT i; 
	EepromSendCmd(EE_READ | (EpromAddr & EE_ADDR_MASK), EpromConReg); 
	for ( i = 0; i < 16; i++ )
	{ // Get word from EEPROM - one bit at a time 
		acc <<= 1; 
		EepromClock(EpromConReg); 
		if ( ReadRtrDword(EpromConReg) & 0x08000000 ) 
		   acc |= 0x0001; 
	} 
	return acc; 
}
////////////////////////////////////////////////////////////////////////// 
static BOOL 
EepromWriteWord(UINT EpromConReg, UINT EpromAddr, WORD val)  // (WORD addresses )  
{ // Write a word to National Semiconductor's NMC93S06/NMC93S46 EEPROM 
	UINT i; 
	DWORD regval; 
	EepromSendCmd(EE_WREN, EpromConReg); // Write enable 
	EepromSendCmd(EE_WRITE | (EpromAddr & EE_ADDR_MASK), EpromConReg); 
	regval = ReadRtrDword(EpromConReg) & ~0x04000000; // Pre-clear data bit 
	for( i = 16; i ; i-- )
	{ // Write word to EEPROM - one bit at a time 
		WriteRtrDword(EpromConReg, regval|((val & 0x8000)? 0x04000000: 0x0)); 
		EepromClock(EpromConReg); 
		val <<= 1; 
	} 
	// Activate chip's status mechanism: deselect and reselect 
	WriteRtrDword(EpromConReg, regval & ~0x02000000); // Deselect 
	WriteRtrDword(EpromConReg, regval); // Reselect 
	// Poll chip status until write-cycle completes (or times out) 
	// (Timeout counter is uncalibrated and somewhat arbitrary!) 
	for( i = 8000; !(ReadRtrDword(EpromConReg) & 0x08000000); i-- )
	{ 
		if ( i ) 
			continue; 
		// Timeout! 
		dprintf("EepromWriteWord(): Busy timeout EEPROM addr:0x%2.2x\n", 
			EpromAddr); 
		return FALSE; 
	} 
	EepromSendCmd(EE_WDS, EpromConReg); // Write disable 
	return TRUE; 
}
///////////////////////////////////////////////////////////////////////////// 
static BOOL 
EepromSendCmd(UINT cmd, UINT EpromConReg) 
{ // Send a command to National Semiconductor's NMC93S06/NMC93S46 EEPROM 
	UINT i; 
	DWORD regval; 
	regval = ReadRtrDword(EpromConReg); 
	regval |= 0x02000000; // Chip select TRUE 
	regval &= ~0x05000000; // Clear instruction and clock bits 
	// Toggle EEPROM's chip select (to get it out of Shift Register Mode) 
	WriteRtrDword(EpromConReg, regval & ~0x02000000); // Chip select FALSE 
	WriteRtrDword(EpromConReg, regval); 
	for ( i = 0; i < EE_CMD_LEN; i++ )
	{ // Send instruction - one bit at a time 
		regval &= ~0x04000000; // Pre-clear the instruction bit 
		// Set up one instruction bit 
		regval |= (cmd & (0x01 << (EE_CMD_LEN-1)))? 0x04000000: 0x00000000; 
		WriteRtrDword (EpromConReg, regval); 
		EepromClock(EpromConReg); 
		cmd <<= 1; // Align next instruction bit 
	} 
	return TRUE; 
}
///////////////////////////////////////////////////////////////////////////// 
static BOOL 
EepromClock(UINT EpromConReg) 
{ // Send clocking sequence to Nat Sem's NMC93S06/NMC93S46 EEPROM 
	DWORD regval; 
	regval = ReadRtrDword(EpromConReg); 
	WriteRtrDword(EpromConReg, regval & ~0x01000000); // Clock low 
	WriteRtrDword(EpromConReg, regval | 0x01000000); // Clock high 
	return TRUE; 
}




#endif